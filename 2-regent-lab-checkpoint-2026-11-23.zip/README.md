# Regent Lab school production checkpoint

Checkpoint date: 2026-11-22, reliability update 2026-11-22c.

This package is the deployed school app, not the isolated pilot.

- Administrator app: https://aali-alt.github.io/regent-lab/
- Teacher QR destination: https://aali-alt.github.io/regent-lab/?mode=teacher&sync=ris-regent-lab-sync-2026
- School backend health: https://regent-lab-backend.a-ali-896.workers.dev/health
- Frontend cutover: https://github.com/aali-alt/regent-lab/commit/966b94ecb3382e83889197f91765f5b074255e9f

## Contents

`index.html` is the exact HTML downloaded from the published original URL. GitHub Pages serves it with CRLF line endings and a final newline. Removing only those transport line-ending differences matches the committed editor buffer.

`secure-client.mjs` is byte-identical to the client served by the school backend. `secure-backend/` contains the readable server source, Firebase rules, dependency lock and emulator tests. `school-public-config.json` is the public Firebase web configuration, not a service-account credential.

`deploy-workers/` contains the live Cloudflare Workers backend deployment: the exact compiled `worker.mjs` bundle, its `wrangler.toml` (assets binding and nightly Cron Trigger), and the `public/` static files it serves. `school-backend-deployed.zip` is the exact uploaded Workers deployment folder. `deployment/` is the legacy Cloudflare Pages upload folder retained for rollback; the Pages project still runs it but receives no traffic. `build-school.mjs` rebuilds the backend bundle; its output was compared byte-for-byte with the deployed worker.

`verification/` contains test logs, dependency audit captures, and selected screenshots. It contains only verification fixtures and the labeled deployment test, not real teacher records.

No live passwords, private keys, production database exports or bootstrap account-creation scripts are included. Local-only fixture passwords appear in emulator tests and must never be used for school accounts.

## Sign-in and teacher accounts

The school administrator username is `admin`. Its password is supplied separately through secure storage and is not recoverable from these files.

Teachers select their name and enter their individual password. Add teachers in System Settings, below School Branding. An existing teacher's password field is write-only; enter a new password and press Save password to change it. Disabling a teacher keeps their historical requests.

The deployment-verification teacher has been disabled. Its labeled test request remains in history. Its one-unit stock deduction was compensated by a separate +1 audit entry, preserving the original approval record.

## Reliability update 2026-11-22b

- Mobile inventory cards now show specification, measurement unit, expiry and a clear low-stock badge.
- Sync status panel updates its "Last Cloud Sync" time from the live authenticated session instead of staying on "Never".
- Audit times render in Cairo local time.
- An empty teacher selector explains that the administrator adds teachers in System Settings.
- Approved requisitions can be reversed with a recorded reason: stock is restored exactly once, linked classroom loans close, the laboratory period frees, and the original approval stays in history. Restored stock returns to the exact batches it was deducted from, so expiry and lot provenance are never fabricated; legacy movements recorded before batch tracking restore into an explicitly labeled unallocated batch instead of a guessed one.
- Inventory items can track separate stock batches with different expiry dates; consumption uses the earliest expiry first and the item total always equals its batch sum.
- Backup at 2026-11-22b ran only while an administrator session was open; update 2026-11-22c below adds the unattended nightly checkpoint.

## Reliability update 2026-11-22c

- The backend moved from Cloudflare Pages Functions to a Cloudflare Workers static-assets deployment at https://regent-lab-backend.a-ali-896.workers.dev . Only the internal backend URL changed; the public app URL and teacher QR links are unchanged. The Pages project remains deployed with the previous backend as an instant rollback path (rollback = revert the frontend to the Pages URL).
- Unattended backup: a Cron Trigger runs every night at 22:00 UTC (00:00 Cairo in winter, 01:00 in summer) and writes a server-side recovery snapshot labeled `system-scheduler`, verified with real scheduled fires against the school database before the daily schedule was set. The session-triggered JSON download and snapshot remain as a fallback while the app is open. Snapshots stay same-database recovery checkpoints, not an independent offsite disaster backup; an offsite copy (for example Cloudflare R2) was not enabled because activating R2 requires a billing checkout on the Cloudflare account.
- Honest failure reporting: a snapshot failure the scheduler can catch (database error, the 900KB dataset guard) writes a visible audit entry and the invocation is marked failed. A hard platform stop (for example exceeding the free plan's 10 ms CPU limit) can terminate the run before any audit write; that failure shows as a failed invocation in Cloudflare metrics, and the app's backup card turns red with an overdue warning when the newest checkpoint is older than 36 hours, so a silently missed night is visible in the app.
- The backup card now distinguishes the automatic nightly checkpoint (with its latest timestamp and scheduled label) from the session fallback, and labels each snapshot in the list as scheduled or session.
- The UI and outage test harnesses now read the backend origin from the packaged `index.html` instead of a hardcoded address, so a backend URL change cannot silently invalidate them.

## Reproduce the tests

Requirements: Node 22 or later, Java 21 or later, and Chrome. The UI test defaults to `/usr/bin/google-chrome`; adjust the path for another installation.

```sh
cd secure-backend
npm ci
npm test
npm run test:emulator
npm run test:ui
npm run test:load
npm run test:outage
```

All test writes target local `demo-regent-lab` emulators. The UI suite reads the packaged production `index.html`, replaces only its endpoints and asset delivery for local testing, bundles the same client, and blocks all external browser traffic. Never point the test suite at a school project.

Fresh checkpoint results (2026-11-22c): 55 unit/security/crypto/restore tests passed, 13 Firestore/Auth integration tests passed (including that recovery snapshots stay backend-only even for the administrator's client), the bounded load check passed, the backend-outage browser check passed, and the actual Chrome UI suite passed. The UI suite includes teacher creation and password reset, old-password rejection, fresh teacher login and booking, admin approval with live teacher updates, inventory changes, loans and returns, loss handling, recurring schedules, backup export, repeated restore, stale-write rejection, requisition reversal with batch-provenance restoration, QR settings and print-stage rendering. The load check covers a maximum-size admin patch (150 inventory records in one patch), 25 concurrent teacher submissions and approvals, a duplicate-approval flood, a full-dataset server snapshot and 25 concurrent loan returns, all staying consistent. The outage check loads the real app in Chrome with the transaction server unreachable and verifies it explains the situation, rejects sign-in gracefully and stays interactive. Expected guard rejections appear in logs as 409 responses.

Separately, live school checks passed for fresh administrator login at the exact original URL, teacher dropdown/password login, request submission, separate-session admin approval, live teacher approval status, the generated QR destination, and verification-account disable/stock compensation.

This is not a claim that every feature, physical printer, browser or device has been tested. Production restore was not exercised against the school database. Restore was exercised in isolated emulators, including repeat restores, already-open sessions, later saves, tampered/incomplete backups and preservation of accounts/audit history.

## Build and host

After `npm ci` in `secure-backend/`, run from this package's root:

```sh
node build-school.mjs
```

The worker is guarded to Firebase project `regent-lab` and frontend origin `https://aali-alt.github.io`. It requires `FIREBASE_SERVICE_ACCOUNT` as an encrypted host secret containing the intended school service-account JSON. Never commit that value or put it into browser code. Do not substitute the pilot project or pilot accounts.

See `OPERATIONS.md` for backups, limits, cache behavior and rollback. `MANIFEST.sha256` records the packaged file hashes.
