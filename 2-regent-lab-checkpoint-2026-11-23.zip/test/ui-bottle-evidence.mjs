// Bottle-flow visual evidence against the Firebase emulator (demo project only).
// Produces screenshots + DB assertions for: two identified containers with
// different volumes/locations, cabinet filtering by effective bottle location,
// explicit selected-container dispense (loan) and return preserving totals,
// and mobile modal usability. Never touches production.
import {publicDirectoryEntry} from '../auth-broker.mjs';
import {createPasswordVerifier} from '../auth-broker.mjs';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import {createServer} from 'node:http';
import {createRequire} from 'node:module';
import {build} from 'esbuild';
import {chromium} from 'playwright-core';
import {initializeApp} from 'firebase-admin/app';
import {getAuth} from 'firebase-admin/auth';
import {getFirestore} from 'firebase-admin/firestore';
import {FirestoreRepository} from '../firebase-repository.mjs';
import {createHandler} from '../http-handler.mjs';

assert.match(process.env.FIRESTORE_EMULATOR_HOST || '', /^127\.0\.0\.1:/);
assert.match(process.env.FIREBASE_AUTH_EMULATOR_HOST || '', /^127\.0\.0\.1:/);

const require = createRequire(import.meta.url), dir = path.resolve('..');
const app = initializeApp({projectId: 'demo-regent-lab'}, 'ui-bottle-evidence');
const db = getFirestore(app), auth = getAuth(app);
const shotDir = path.join(dir, 'verification');
const shot = async (page, name) => { await page.screenshot({path: path.join(shotDir, name), fullPage: false}); console.log('SHOT', name); };

let browser, apiServer, siteServer;
try {
  await fetch('http://' + process.env.FIRESTORE_EMULATOR_HOST + '/emulator/v1/projects/demo-regent-lab/databases/(default)/documents', {method: 'DELETE'});
  const source = await fs.readFile(path.join(dir, 'index.html'), 'utf8').then(v => v.replace(/\r\n/g, '\n'));
  const expression = source.match(/const DEFAULT_STATE = ([\s\S]+?);\n\n        function loadLocalState/)[1];
  const state = vm.runInNewContext('(' + expression + ')');
  const clean = value => Array.isArray(value) ? value.map(clean) : value && typeof value === 'object' ? Object.fromEntries(Object.entries(value).filter(([key]) => !/password|secret|credential/i.test(key)).map(([key, val]) => [key, clean(val)])) : value;
  state.settings = clean(state.settings); state.settings.teachers = [{name: 'Teacher One'}];
  await db.doc('regent_v2_settings/main').set({...state.settings, version: 1});
  for (const kind of ['inventory', 'cabinets', 'logs']) for (const row of state[kind]) await db.doc('regent_v2_' + kind + '/' + row.id).set({...row, version: 1, ...(kind === 'inventory' ? {qty: 10} : {})});
  for (const account of [{uid: 'ui_admin', name: 'admin', role: 'admin'}, {uid: 'ui_teacher', name: 'Teacher One', role: 'teacher'}]) {
    const login = account.uid + '@demo.invalid';
    try { await auth.deleteUser(account.uid); } catch {}
    await auth.createUser({uid: account.uid, email: login, password: 'Local-ui-fixture-only-2026'});
    await auth.setCustomUserClaims(account.uid, {sessionVersion: 1});
    await db.doc('regent_v2_accounts/' + account.uid).set({...account, login, disabled: false, sessionVersion: 1, validAfter: 0});
    await db.doc('regent_v2_directory/' + account.uid).set(publicDirectoryEntry(account));
  }

  await build({entryPoints: [path.join(dir, 'secure-client.mjs')], outfile: path.join(dir, 'ui-client.bundle.js'), format: 'iife', globalName: 'RegentSecureReview', bundle: true, platform: 'browser', plugins: [{name: 'local-firebase-sdk', setup(builder) {builder.onResolve({filter: /^https:\/\/www\.gstatic\.com\/firebasejs\/.*\/firebase-(app|auth|firestore)\.js$/}, args => ({path: require.resolve('firebase/' + args.path.match(/firebase-(app|auth|firestore)\.js$/)[1])}));}}]});
  const backendOrigin = (source.match(/const SECURE_BACKEND_URL = "(https:\/\/[^"]+)";/))?.[1];
  assert.ok(backendOrigin, 'packaged index.html must declare SECURE_BACKEND_URL');
  let html = source.replace(/import \{createSecureClient\} from "https:\/\/[^"]+\/client\/secure-client\.mjs";/, 'const {createSecureClient}=window.RegentSecureReview;').replace(`const SECURE_BACKEND_URL = "${backendOrigin}";`, 'const SECURE_BACKEND_URL = "http://127.0.0.1:8787";').replace('testEmulators: false', 'testEmulators: true').replace(/regent-lab\.firebaseapp\.com/g, 'demo-regent-lab.firebaseapp.com').replace('projectId: "regent-lab"', 'projectId: "demo-regent-lab"');
  html = html.replace('<script type="module">', '<script src="/ui-client.bundle.js"></script><script type="module">');
  html = html.replace(/<script\b[^>]*src=["']https:\/\/cdn.tailwindcss.com["'][^>]*><\/script>/, () => '<script>' + require('node:fs').readFileSync(path.join(dir, 'tailwind.js'), 'utf8') + '</script>').replace(/<script\b[^>]*src=["'][^"']*qrcode.min.js["'][^>]*><\/script>/, () => '<script>' + require('node:fs').readFileSync(path.join(dir, 'qrcode.js'), 'utf8') + '</script>');
  html = html.replaceAll(backendOrigin + '/', '/').replace(/<script\b[^>]*src=["']\/(tailwind|qrcode)\.js["'][^>]*><\/script>/g, (_, name) => '<script>' + require('node:fs').readFileSync(path.join(dir, name + '.js'), 'utf8') + '</script>');
  html = html.replace('</head>', '<style>*,*::before,*::after{animation:none!important;transition:none!important}</style></head>');
  await fs.writeFile(path.join(dir, 'ui-emulator-preview.html'), html);

  apiServer = createServer(createHandler({repo: new FirestoreRepository(db), auth, passwordVerifier: createPasswordVerifier({apiKey: 'local-test-api-key', projectId: 'demo-regent-lab', emulatorHost: process.env.FIREBASE_AUTH_EMULATOR_HOST}), allowedOrigin: 'http://127.0.0.1:4173', allowLocalDevelopment: true}));
  await new Promise(r => apiServer.listen(8787, '127.0.0.1', r));
  siteServer = createServer(async (req, res) => {let file = req.url.startsWith('/ui-client.bundle.js') ? 'ui-client.bundle.js' : req.url.startsWith('/assets/') ? req.url.slice(1).split('?')[0] : 'ui-emulator-preview.html'; if (!/^[a-zA-Z0-9_./-]+$/.test(file) || file.includes('..')) {res.statusCode = 404; return res.end();} res.setHeader('Content-Type', file.endsWith('.js') ? 'application/javascript' : file.endsWith('.css') ? 'text/css' : file.endsWith('.woff2') ? 'font/woff2' : 'text/html'); try {res.end(await fs.readFile(path.join(dir, file)));} catch {res.statusCode = 404; res.end();}});
  await new Promise(r => siteServer.listen(4173, '127.0.0.1', r));

  browser = await chromium.launch({executablePath: '/usr/bin/google-chrome', headless: true, args: ['--no-sandbox']});
  const context = await browser.newContext({viewport: {width: 1440, height: 1000}});
  await context.route('**/*', route => new URL(route.request().url()).hostname === '127.0.0.1' ? route.continue() : route.abort());
  const errors = [];
  const admin = await context.newPage();
  admin.on('pageerror', err => errors.push(err.message));
  admin.on('response', async response => {if (response.url().startsWith('http://127.0.0.1:8787/') && response.status() >= 400) console.log('API failure', response.status(), response.url().split('8787')[1], await response.text());});
  await admin.goto('http://127.0.0.1:4173/');
  await admin.locator('#admin-login-user').fill('ui_admin@demo.invalid');
  await admin.locator('#admin-login-pass').fill('Local-ui-fixture-only-2026');
  await admin.locator('#admin-login-pass').press('Enter');
  await admin.locator('#admin-login-gate').waitFor({state: 'hidden', timeout: 20000});
  console.log('PASS: admin signed in on emulator build');

  const legacyItemId = state.inventory[0].id;
  const cab1 = state.cabinets[0].code, cab2 = state.cabinets[1].code;

  // 0. Create a NEW volume-unit (mL) chemical item; legacy bottle-count items stay untouched.
  await admin.evaluate(() => window.openInventoryModal());
  await admin.locator('#inv-name-en').fill('Ethanol 96%');
  await admin.locator('#inv-name-ar').fill('إيثانول ٩٦٪');
  await admin.locator('#inv-code').fill('CHM-900');
  const cat = await admin.locator('#inv-category option').evaluateAll(options => options.find(o => o.value && /chem/i.test(o.textContent))?.value || options.find(o => o.value)?.value);
  await admin.locator('#inv-category').selectOption(cat);
  await admin.locator('#inv-cabinet').selectOption(cab1);
  const mlUnit = await admin.locator('#inv-unit option').evaluateAll(options => {const o = options.find(o => /mL/.test(o.textContent) || /mL/.test(o.value)); return o && o.value;});
  assert.ok(mlUnit, 'mL unit must exist');
  await admin.locator('#inv-unit').selectOption(mlUnit);
  await admin.locator('#inv-min-qty').fill('200');
  await admin.locator('#inv-batches-toggle').check();
  await admin.locator('#inv-batch-rows .inv-batch-row').first().waitFor();
  const row1 = admin.locator('#inv-batch-rows .inv-batch-row').nth(0);
  await row1.locator('.batch-label').fill('Bottle A');
  await row1.locator('.batch-qty').fill('300');
  await row1.locator('.batch-capacity').fill('500');
  await row1.locator('.batch-expiry').fill('2027-06-15');
  await row1.locator('.batch-opened').fill('2026-09-01');
  await row1.locator('.batch-cabinet').selectOption(cab1);
  await row1.locator('.batch-shelf').fill('Shelf 1');
  await admin.getByRole('button', {name: /Add Bottle \/ Batch/}).click();
  const row2 = admin.locator('#inv-batch-rows .inv-batch-row').nth(1);
  await row2.locator('.batch-label').fill('Bottle B');
  await row2.locator('.batch-capacity').fill('500');
  await row2.locator('.batch-expiry').fill('2028-01-31');
  await row2.locator('.batch-cabinet').selectOption(cab2);
  await row2.locator('.batch-shelf').fill('Shelf 2');
  // 0a. Negative check: remaining 600 mL in a 500 mL bottle must be rejected, nothing saved.
  await row2.locator('.batch-qty').fill('600');
  await admin.locator('#inventory-modal form').evaluate(form => form.requestSubmit());
  await admin.getByText('A bottle cannot hold more than its capacity', {exact: false}).waitFor({state: 'visible', timeout: 10000});
  assert.equal(await admin.locator('#inventory-modal').isVisible(), true);
  let created = (await db.collection('regent_v2_inventory').get()).docs.map(d => d.data()).find(i => i.code === 'CHM-900');
  assert.equal(created, undefined);
  await shot(admin, '2026-11-23-bottle-00-overcapacity-rejected.png');
  console.log('PASS: remaining > capacity rejected client-side before save');
  await row2.locator('.batch-qty').fill('500');
  assert.equal(await admin.locator('#inv-qty').inputValue(), '800');
  await shot(admin, '2026-11-23-bottle-01-editor.png');
  await admin.locator('#inventory-modal form').evaluate(form => form.requestSubmit());
  await admin.locator('#inventory-modal').waitFor({state: 'hidden'});
  let itemId;
  for (let tries = 0; tries < 40; tries++) {created = (await db.collection('regent_v2_inventory').get()).docs.map(d => ({docId: d.id, ...d.data()})).find(i => i.code === 'CHM-900'); if (created) break; await new Promise(r => setTimeout(r, 100));}
  assert.ok(created, 'CHM-900 created');
  itemId = created.docId;
  assert.equal(created.unit, mlUnit);
  async function stock(expected) {for (let tries = 0; tries < 40; tries++) {if ((await db.doc('regent_v2_inventory/' + itemId).get()).data().qty === expected) return; await new Promise(r => setTimeout(r, 100));} assert.equal((await db.doc('regent_v2_inventory/' + itemId).get()).data().qty, expected);}
  async function batches() {return (await db.doc('regent_v2_inventory/' + itemId).get()).data().batches;}
  await stock(800);
  let b = await batches();
  assert.equal(b.length, 2);
  assert.equal(b[0].label, 'Bottle A'); assert.equal(Number(b[0].qty), 300); assert.equal(Number(b[0].capacity), 500); assert.equal(b[0].cabinetCode, cab1); assert.equal(b[0].shelf, 'Shelf 1');
  assert.equal(b[1].label, 'Bottle B'); assert.equal(Number(b[1].qty), 500); assert.equal(Number(b[1].capacity), 500); assert.equal(b[1].cabinetCode, cab2); assert.equal(b[1].shelf, 'Shelf 2');
  const batchA = b[0].id, batchB = b[1].id;
  console.log('PASS: new mL item with two identified containers (A 300/500 in ' + cab1 + ', B 500/500 in ' + cab2 + '); ids', batchA, batchB);
  // Legacy bottle-count item keeps its unit and unconfirmed wording - not silently relabeled.
  const legacy = (await db.doc('regent_v2_inventory/' + legacyItemId).get()).data();
  assert.match(legacy.unit, /Bottle/);
  console.log('PASS: legacy item unit unchanged (' + legacy.unit + '), no silent mL relabel');

  // 2. Item detail card shows both containers.
  await admin.evaluate(id => window.openItemDetail(id), itemId);
  await admin.locator('#item-detail-modal').getByText('Bottle A', {exact: false}).waitFor({state: 'visible', timeout: 10000});
  await admin.locator('#item-detail-modal').getByText('Bottle B', {exact: false}).waitFor();
  await shot(admin, '2026-11-23-bottle-02-item-card.png');
  await admin.evaluate(() => window.closeModal('item-detail-modal'));

  // 3. Cabinet cards filter by effective bottle location.
  await admin.evaluate(code => window.openCabinetDetail(code), cab1);
  await admin.locator('#cabinet-detail-modal').getByText('Ethanol 96%', {exact: false}).waitFor({state: 'visible', timeout: 10000});
  const cab1Card = await admin.locator('#cabinet-detail-modal').innerText();
  assert.match(cab1Card, /1 of 2/, 'cab1 card shows partial bottle count');
  assert.match(cab1Card, /300/, 'cab1 card shows Bottle A remaining only');
  await shot(admin, '2026-11-23-bottle-03-cabinet-' + cab1 + '.png');
  await admin.evaluate(() => window.closeModal('cabinet-detail-modal'));
  await admin.evaluate(code => window.openCabinetDetail(code), cab2);
  await admin.locator('#cabinet-detail-modal').getByText('Ethanol 96%', {exact: false}).waitFor({state: 'visible', timeout: 10000});
  const cab2Card = await admin.locator('#cabinet-detail-modal').innerText();
  assert.match(cab2Card, /1 of 2/, 'cab2 card shows partial bottle count');
  assert.match(cab2Card, /500/, 'cab2 card shows Bottle B remaining only');
  await shot(admin, '2026-11-23-bottle-04-cabinet-' + cab2 + '.png');
  await admin.evaluate(() => window.closeModal('cabinet-detail-modal'));
  console.log('PASS: cabinet cards filtered by effective bottle location; ' + cab1 + ' shows Bottle A, ' + cab2 + ' shows Bottle B');

  // 4. Explicit selected-container dispense (manual loan from Bottle B) and return.
  await admin.evaluate(() => window.openModal('loan-modal'));
  await admin.locator('#loan-teacher').selectOption('Teacher One');
  const cls = await admin.locator('#loan-class option').evaluateAll(options => options.find(o => o.value)?.value);
  if (cls) await admin.locator('#loan-class').selectOption(cls);
  await admin.locator('#loan-due-date').fill('2026-11-24');
  await admin.locator('#loan-item-select').selectOption(itemId);
  await admin.locator('#loan-batch-wrap').waitFor({state: 'visible', timeout: 10000});
  const bottleBOption = await admin.locator('#loan-batch-select option').evaluateAll(options => {const o = options.find(o => o.textContent.includes('Bottle B')); return o && o.value;});
  assert.ok(bottleBOption, 'loan batch picker must offer Bottle B');
  await admin.locator('#loan-batch-select').selectOption(bottleBOption);
  await shot(admin, '2026-11-23-bottle-05-loan-picker.png');
  await admin.locator('#loan-qty').fill('100');
  await admin.locator('#loan-modal form').evaluate(form => form.requestSubmit());
  await admin.locator('#loan-modal').waitFor({state: 'hidden'});
  await stock(700);
  b = await batches();
  assert.equal(Number(b[0].qty), 300); assert.equal(Number(b[1].qty), 400);
  const loans = (await db.collection('regent_v2_loans').get()).docs.filter(d => !d.data()._meta);
  const loan = loans.find(d => d.data().status === 'active');
  const alloc = (loan.data().batchAllocations || [])[0] || {};
  assert.equal(alloc.batchId, batchB);
  assert.equal(Number(alloc.qty), 100);
  assert.equal(Number(loan.data().qty), 100);
  console.log('PASS: dispense of 100 mL consumed the explicitly selected Bottle B only (300 + 400 = 700); loan batchAllocations records', alloc.batchId);

  await admin.evaluate(id => window.returnTeacherLoan(id), loan.id);
  await stock(800);
  b = await batches();
  assert.equal(Number(b[0].qty), 300); assert.equal(Number(b[1].qty), 500);
  console.log('PASS: return restored the exact 100 mL to Bottle B (300 + 500 = 800); totals preserved');

  // 5. Mobile modal usability (iPhone-class viewport).
  const mobile = await browser.newContext({viewport: {width: 390, height: 844}, isMobile: true, hasTouch: true});
  await mobile.route('**/*', route => new URL(route.request().url()).hostname === '127.0.0.1' ? route.continue() : route.abort());
  const mpage = await mobile.newPage();
  mpage.on('pageerror', err => errors.push(err.message));
  await mpage.goto('http://127.0.0.1:4173/');
  await mpage.locator('#admin-login-user').fill('ui_admin@demo.invalid');
  await mpage.locator('#admin-login-pass').fill('Local-ui-fixture-only-2026');
  await mpage.locator('#admin-login-pass').press('Enter');
  await mpage.locator('#admin-login-gate').waitFor({state: 'hidden', timeout: 20000});
  await mpage.evaluate(id => window.openItemDetail(id), itemId);
  await mpage.locator('#item-detail-modal').getByText('Bottle A', {exact: false}).waitFor({state: 'visible', timeout: 10000});
  await shot(mpage, '2026-11-23-bottle-06-mobile-item-card.png');
  await mpage.evaluate(() => window.closeModal('item-detail-modal'));
  await mpage.evaluate(code => window.openCabinetDetail(code), cab2);
  await mpage.locator('#cabinet-detail-modal').getByText('Ethanol 96%', {exact: false}).waitFor({state: 'visible', timeout: 10000});
  await shot(mpage, '2026-11-23-bottle-07-mobile-cabinet.png');
  console.log('PASS: mobile viewport renders item and cabinet cards');

  assert.deepEqual(errors, []);
  console.log('ALL BOTTLE EVIDENCE CHECKS PASSED');
} finally {
  if (browser) await browser.close();
  if (apiServer) apiServer.close();
  if (siteServer) siteServer.close();
}
