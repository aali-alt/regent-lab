// Backend-outage check in real Chrome: with the transaction server unreachable,
// the app must load, say so, reject sign-in gracefully and stay interactive.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createServer} from 'node:http';
import {createRequire} from 'node:module';
import {build} from 'esbuild';
import {chromium} from 'playwright-core';
assert.match(process.env.FIRESTORE_EMULATOR_HOST||'',/^127\.0\.0\.1:/);
const require=createRequire(import.meta.url),dir=path.resolve('..');
let browser,siteServer;
try{
  const source=await fs.readFile(path.join(dir,'index.html'),'utf8').then(value=>value.replace(/\r\n/g,'\n'));
  await build({entryPoints:[path.join(dir,'secure-client.mjs')],outfile:path.join(dir,'ui-client.bundle.js'),format:'iife',globalName:'RegentSecureReview',bundle:true,platform:'browser',plugins:[{name:'local-firebase-sdk',setup(builder){builder.onResolve({filter:/^https:\/\/www\.gstatic\.com\/firebasejs\/.*\/firebase-(app|auth|firestore)\.js$/},args=>({path:require.resolve('firebase/'+args.path.match(/firebase-(app|auth|firestore)\.js$/)[1])}));}}]});
  const backendOrigin=(source.match(/const SECURE_BACKEND_URL = "(https:\/\/[^"]+)";/))?.[1];
  assert.ok(backendOrigin,'packaged index.html must declare SECURE_BACKEND_URL');
  let html=source.replace(/import \{createSecureClient\} from "https:\/\/[^"]+\/client\/secure-client\.mjs";/,'const {createSecureClient}=window.RegentSecureReview;').replace(`const SECURE_BACKEND_URL = "${backendOrigin}";`,'const SECURE_BACKEND_URL = "http://127.0.0.1:59998";').replace('testEmulators: false','testEmulators: true').replace(/regent-lab\.firebaseapp\.com/g,'demo-regent-lab.firebaseapp.com').replace('projectId: "regent-lab"','projectId: "demo-regent-lab"');
  html=html.replace('<script type="module">','<script src="/ui-client.bundle.js"></script><script type="module">');
  html=html.replace(/<script\b[^>]*src=["']https:\/\/cdn.tailwindcss.com["'][^>]*><\/script>/,()=>'<script>'+require('node:fs').readFileSync(path.join(dir,'tailwind.js'),'utf8')+'</script>').replace(/<script\b[^>]*src=["'][^"']*qrcode.min.js["'][^>]*><\/script>/,()=>'<script>'+require('node:fs').readFileSync(path.join(dir,'qrcode.js'),'utf8')+'</script>');
  html=html.replaceAll(backendOrigin+'/','/').replace(/<script\b[^>]*src=["']\/(tailwind|qrcode)\.js["'][^>]*><\/script>/g,(_,name)=>'<script>'+require('node:fs').readFileSync(path.join(dir,name+'.js'),'utf8')+'</script>');
  await fs.writeFile(path.join(dir,'ui-outage-preview.html'),html);
  siteServer=createServer(async(req,res)=>{let file=req.url.startsWith('/ui-client.bundle.js')?'ui-client.bundle.js':req.url.startsWith('/assets/')?req.url.slice(1).split('?')[0]:'ui-outage-preview.html';if(!/^[a-zA-Z0-9_./-]+$/.test(file)||file.includes('..')){res.statusCode=404;return res.end();}res.setHeader('Content-Type',file.endsWith('.js')?'application/javascript':file.endsWith('.css')?'text/css':file.endsWith('.woff2')?'font/woff2':'text/html');try{res.end(await fs.readFile(path.join(dir,file)));}catch{res.statusCode=404;res.end();}});
  await new Promise(r=>siteServer.listen(4174,'127.0.0.1',r));
  browser=await chromium.launch({executablePath:'/usr/bin/google-chrome',headless:true,args:['--no-sandbox']});
  const context=await browser.newContext();
  await context.route('**/*',route=>new URL(route.request().url()).hostname==='127.0.0.1'?route.continue():route.abort());
  const page=await context.newPage();const errors=[];page.on('pageerror',err=>errors.push(err.message));
  await page.goto('http://127.0.0.1:4174/');
  await page.waitForFunction(()=>[...document.querySelectorAll('.sync-status-label')].some(el=>/setup required/i.test(el.textContent)),null,{timeout:25000});
  console.log('OUTAGE: page loads and reports that secure sign-in setup is required while the backend is down.');
  await page.locator('#admin-login-user').fill('admin');
  await page.locator('#admin-login-pass').fill('outage-fixture-password');
  await page.locator('#admin-login-pass').press('Enter');
  await page.waitForFunction(()=>/not available|failed|retry/i.test(document.getElementById('toast-container')?.innerText||''),null,{timeout:25000});
  console.log('OUTAGE: sign-in attempt fails with a visible, non-technical message instead of hanging.');
  await page.evaluate(()=>window.switchTab('inventory'));
  assert.equal(await page.locator('#tab-inventory').isVisible(),true);
  assert.deepEqual(errors,[]);
  console.log('OUTAGE PASS: backend-down app loads, explains itself, rejects sign-in gracefully and stays interactive. No uncaught page errors.');
}finally{if(browser)await browser.close();if(siteServer)await new Promise(r=>siteServer.close(r));}
