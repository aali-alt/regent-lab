// Bounded load check against the Firestore emulator: the documented maximum
// admin patch, concurrent teacher submissions and approvals, a duplicate-action
// flood, a full-dataset snapshot, and concurrent loan returns must all stay consistent.
import {initializeApp,deleteApp} from 'firebase-admin/app';
import {getFirestore} from 'firebase-admin/firestore';
import assert from 'node:assert/strict';
import {FirestoreRepository} from '../firebase-repository.mjs';
import {createRequisition,decideRequisition,applyAdminChanges,createSnapshot,returnLoan} from '../domain.mjs';
assert.match(process.env.FIRESTORE_EMULATOR_HOST||'',/^127\.0\.0\.1:/);
const app=initializeApp({projectId:'demo-regent-lab'},'load');
const db=getFirestore(app);
const repo=new FirestoreRepository(db);
await fetch('http://'+process.env.FIRESTORE_EMULATOR_HOST+'/emulator/v1/projects/demo-regent-lab/databases/(default)/documents',{method:'DELETE'});
const admin={uid:'admin1',role:'admin',name:'Lab Admin'};
await db.doc('regent_v2_settings/main').set({labs:['Lab 1'],periods:['Period 1'],version:1});
const t0=Date.now();
const seed=Array.from({length:150},(_,i)=>({kind:'inventory',id:'item-'+i,expectedVersion:0,value:{id:'item-'+i,nameEn:'Load Item '+i,unit:'pcs',qty:20}}));
await applyAdminChanges(repo,admin,{changes:seed},'seed');
console.log('LOAD seed: 150 inventory records in one maximum-size admin patch took',Date.now()-t0,'ms');
const reqs=Array.from({length:25},(_,t)=>({id:'load-req-'+t,usageMode:'outside-lab',date:'2026-11-25',returnDate:'2026-11-26',period:'Period 1',experiment:'Load session '+t,grade:'Grade 7',subject:'Biology',items:[0,1,2,3].map(j=>({itemId:'item-'+(t*4+j),qty:7}))}));
const t1=Date.now();
await Promise.all(reqs.map((r,t)=>createRequisition(repo,{uid:'teacher'+(t%5),name:'Teacher '+(t%5),role:'teacher'},r,'c'+t)));
console.log('LOAD submissions: 25 concurrent teacher requests (100 item lines) took',Date.now()-t1,'ms');
const t2=Date.now();
await Promise.all(reqs.map((r,t)=>decideRequisition(repo,admin,{requestId:r.id,decision:'approved'},'a'+t)));
console.log('LOAD approvals: 25 concurrent approvals took',Date.now()-t2,'ms');
for(let t=0;t<25;t++)for(let j=0;j<4;j++){
  const snap=await db.doc('regent_v2_inventory/item-'+(t*4+j)).get();
  assert.equal(snap.data().qty,13,'item-'+(t*4+j));
}
const loans=(await db.collection('regent_v2_loans').get()).docs.filter(d=>!d.data()._meta);
assert.equal(loans.length,100);
await Promise.all(Array.from({length:10},(_,i)=>decideRequisition(repo,admin,{requestId:'load-req-0',decision:'approved'},'dup'+i)));
assert.equal((await db.doc('regent_v2_inventory/item-0').get()).data().qty,13,'duplicate approval flood must deduct once');
const t3=Date.now();
const snap=await createSnapshot(repo,admin,'snap-load');
console.log('LOAD snapshot: full-dataset server snapshot took',Date.now()-t3,'ms');
assert.equal(snap.snapshot.counts.inventory,150);
const t4=Date.now();
await Promise.all(loans.slice(0,25).map((d,i)=>returnLoan(repo,admin,{loanId:d.id},'ret'+i)));
console.log('LOAD returns: 25 concurrent loan returns took',Date.now()-t4,'ms');
const returned=loans.slice(0,25).map(d=>d.data());
for(const loan of returned){const doc=await db.doc('regent_v2_inventory/'+loan.itemId).get();}
console.log('LOAD total elapsed:',Date.now()-t0,'ms');
await deleteApp(app);
console.log('LOAD PASS: maximum patch, concurrent submissions/approvals, duplicate-approval flood, full snapshot and concurrent returns all stayed consistent.');
