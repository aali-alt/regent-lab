# Operations and recovery

## Current deployment

The frontend is published on the original GitHub Pages path. Since reliability update 2026-11-22c the backend runs as a Cloudflare Workers static-assets deployment named `regent-lab-backend` at https://regent-lab-backend.a-ali-896.workers.dev and uses Firebase project `regent-lab`. The previous Cloudflare Pages backend project remains deployed with the same code (minus the scheduler) as a rollback target but receives no traffic. The build does not configure billing, upgrades or provider-managed backups; the Workers free plan covers the current usage. Review the hosting and database plans before increasing capacity.

A Cron Trigger on the Worker runs every night at 22:00 UTC (00:00 Cairo in winter, 01:00 in summer) and writes a recovery snapshot labeled `system-scheduler`. The encrypted `FIREBASE_SERVICE_ACCOUNT` secret is set identically on the Worker. The assets binding runs with `run_worker_first = true` so asset responses keep the same CORS and nosniff headers the Pages worker added.

The legacy application document was retained unchanged. The secure app uses separate `regent_v2_` collections. Protected authentication accounts are not stored in ordinary application exports.

## Cache behavior

GitHub Pages serves the HTML with a ten-minute cache lifetime. A browser that opened the old page immediately before rollout may briefly retain it. Refresh the page; a cache-busting release query also works. Both a fresh password login on the exact bare original URL and the generated teacher QR URL were verified after rollout.

## Backup and restore

Use Official Reports & Exports to save an application JSON backup before important changes. Three backup paths exist: (a) an unattended nightly snapshot written by the backend Cron Trigger and labeled `system-scheduler`; (b) while an administrator session is open, a daily full JSON download plus an extra snapshot; (c) manual JSON export at any time. Snapshots live in the same protected database (newest 30 kept), are listed on the backup card with scheduled/session labels, and restore after confirmation. They are same-database recovery checkpoints, not a provider-managed or offsite disaster backup; no offsite copy exists unless the administrator stores one. An offsite copy through Cloudflare R2 was considered and not enabled because activating R2 requires completing a billing checkout on the Cloudflare account, even within its free tier.

Failure reporting is honest in both directions: a snapshot failure the scheduler can catch (database error, the 900KB dataset guard) writes a visible in-app audit entry and the cron invocation is marked failed. A hard platform stop, such as exceeding the Workers free plan 10 ms CPU limit, can terminate the run before any audit entry is written; such a failure appears only as a failed invocation in Cloudflare metrics, and the backup card turns red with an overdue warning when the newest checkpoint is older than 36 hours. No ongoing monitoring service is configured by these files.

The JSON contains the application datasets, not administrator or teacher passwords. Restore preserves protected accounts and existing audit history, validates the backup structure, rejects stale or incomplete inputs, and records its operation. It is a replacement of application datasets, so review the backup and take a fresh export first. Repeated restores, live-session refresh and a subsequent save were tested locally. Do not test destructive restoration on the live school merely to repeat those checks.

## Limits and capacity

The code accepts up to 100 distinct requisition items and 150 changes in an ordinary admin patch. Ordinary bodies are limited to 512 KiB; complete restore bodies are limited to 4 MiB. These are validation limits, not a guarantee that every body of that size will complete within the hosting platform's CPU or usage limits. The Workers free plan allows 100,000 requests per day and 10 ms of CPU time per invocation; current school usage is far below the request cap, and the nightly snapshot fit within the CPU cap at the current dataset size, but a much larger dataset could exceed it - see the overdue warning under Backup and restore for how that would surface.

The app listens to permitted collections in real time. Large histories and many open sessions consume more reads and requests. Review the vendors' current quotas before expanding use or retaining a large history. This checkpoint is not an unlimited-capacity or outage-free promise.

Login attempts are rate limited. The public directory deliberately exposes only teacher display names and opaque selectors, preserving name-dropdown login. Password checks and private login-address lookups happen on the backend. Disabled teachers cannot sign in and are removed from the active public selector list.

## Rollback

This package preserves a matched frontend, backend, client, rules and dependency lock. Use the complete matched checkpoint to recover from a later code regression. The pre-cutover frontend remains in Git history, but it is not a safe shortcut for restoring client-side passwords or legacy open database access.

Backend rollback from Workers to Pages: the Pages project `regent-lab-backend` still runs the previous backend build. Revert the frontend `index.html` to the commit that references `https://regent-lab-backend.pages.dev` (or replace the Workers URL with the Pages URL and redeploy) and the app returns to the Pages backend immediately; the nightly scheduled snapshots stop until a scheduler-capable backend is restored. Both backends share the same Firebase database, so no data migration is involved either way.

Before changing the live backend or rules, save an application export and record the existing revision. Do not overwrite another person's concurrent changes, delete protected accounts or assume a code rollback should also roll back their data.

## Dependency audit capture

The included audit captures report zero production advisories and zero high/critical advisories overall. Fourteen moderate advisories remain in development-only Firebase CLI dependencies. This describes the captured audit, not a guarantee about future advisories.

## Security administration

Service-account credentials belong only in the host's encrypted secret store. Rotate or revoke a key only after identifying its exact ID and confirming it is not the active deployment credential. This source package contains no service-account JSON and performs no key deletion or API enablement automatically.
