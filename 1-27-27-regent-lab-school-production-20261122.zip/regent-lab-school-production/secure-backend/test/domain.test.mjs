import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequisition,decideRequisition,applyAdminChanges,cleanSettings,returnLoan,issueManualLoan} from '../domain.mjs';
class MemoryRepo {
  constructor(){this.rows=new Map();this.queue=Promise.resolve();}
  now(){return '2026-11-22T10:00:00.000Z';}
  set(kind,id,value){this.rows.set(kind+'/'+id,structuredClone(value));}
  get(kind,id){return structuredClone(this.rows.get(kind+'/'+id)||null);}
  transaction(fn){
    const run=this.queue.then(async()=>{
      const draft=new Map(structuredClone([...this.rows]));
      const tx={preload:async()=>{},list:async k=>[...draft.entries()].filter(([key])=>key.startsWith(k+'/')).map(([,v])=>structuredClone(v)),get:async(k,id)=>structuredClone(draft.get(k+'/'+id)||null),
        set:(k,id,v)=>draft.set(k+'/'+id,structuredClone(v)),delete:(k,id)=>draft.delete(k+'/'+id),
        findActiveBooking:async slot=>[...draft.entries()].filter(([k])=>k.startsWith('bookings/')).map(([,v])=>v).find(v=>v.date===slot.date&&v.period===slot.period&&v.lab===slot.lab)||null};
      const out=await fn(tx);this.rows=draft;return out;
    });this.queue=run.catch(()=>{});return run;
  }
}
const teacher={uid:'t1',name:'Teacher One',role:'teacher'},admin={uid:'a1',name:'Lab Admin',role:'admin'};
const setup=()=>{const r=new MemoryRepo();r.set('inventory','i1',{id:'i1',nameEn:'Beaker',qty:10,unit:'pcs',version:1});r.set('settings','main',{labs:['Lab 1'],periods:['Period 1']});return r;};
const req=(id='r1')=>({id,usageMode:'in-lab',date:'2026-11-22',period:'Period 1',lab:'Lab 1',experiment:'Microscopy',grade:'Grade 7',subject:'Biology',items:[{itemId:'i1',qty:3}]});
test('teacher request belongs to authenticated identity and does not deduct stock before approval',async()=>{const r=setup();const out=await createRequisition(r,teacher,{...req(),teacherName:'forged',status:'approved'},'c1');assert.equal(out.request.teacherUid,'t1');assert.equal(out.request.teacherName,'Teacher One');assert.equal(out.request.status,'pending');assert.equal(r.get('inventory','i1').qty,10);});
test('teacher cannot mutate inventory or approve requests',async()=>{const r=setup();await assert.rejects(()=>applyAdminChanges(r,teacher,{changes:[]},'c1'),{code:'FORBIDDEN'});await assert.rejects(()=>decideRequisition(r,teacher,{requestId:'r1',decision:'approved'},'c2'),{code:'FORBIDDEN'});});
test('simultaneous teacher phones retain different requests',async()=>{const r=setup();await Promise.all([createRequisition(r,teacher,{...req('r1'),usageMode:'outside-lab'},'c1'),createRequisition(r,{...teacher,uid:'t2'},{...req('r2'),usageMode:'outside-lab'},'c2')]);assert.ok(r.get('requests','r1'));assert.ok(r.get('requests','r2'));});
test('one laboratory period cannot be booked twice concurrently',async()=>{const r=setup();const out=await Promise.allSettled([createRequisition(r,teacher,req('r1'),'c1'),createRequisition(r,{...teacher,uid:'t2'},req('r2'),'c2')]);assert.equal(out.filter(x=>x.status==='fulfilled').length,1);assert.equal(out.find(x=>x.status==='rejected').reason.code,'BOOKING_CONFLICT');});
test('duplicate approval deducts stock once',async()=>{const r=setup();await createRequisition(r,teacher,req(),'c1');await Promise.all([decideRequisition(r,admin,{requestId:'r1',decision:'approved'},'a1'),decideRequisition(r,admin,{requestId:'r1',decision:'approved'},'a2')]);assert.equal(r.get('inventory','i1').qty,7);});
test('approval rejects insufficient stock and rolls back the complete operation',async()=>{const r=setup();await createRequisition(r,teacher,req(),'c1');r.set('inventory','i1',{id:'i1',qty:1,version:2});await assert.rejects(()=>decideRequisition(r,admin,{requestId:'r1',decision:'approved'},'a1'),{code:'INSUFFICIENT_STOCK'});assert.equal(r.get('requests','r1').status,'pending');assert.equal(r.get('inventory','i1').qty,1);});
test('same idempotency key cannot change content',async()=>{const r=setup();await createRequisition(r,teacher,req(),'c1');await assert.rejects(()=>createRequisition(r,teacher,{...req(),experiment:'Changed'},'c1'),{code:'IDEMPOTENCY_CONFLICT'});});
test('stale device changes cannot overwrite a newer record',async()=>{const r=setup();await applyAdminChanges(r,admin,{changes:[{kind:'inventory',id:'i1',expectedVersion:1,value:{id:'i1',qty:8}}]},'a1');await assert.rejects(()=>applyAdminChanges(r,admin,{changes:[{kind:'inventory',id:'i1',expectedVersion:1,value:{id:'i1',qty:9}}]},'a2'),{code:'STALE_WRITE'});assert.equal(r.get('inventory','i1').qty,8);});
test('disjoint concurrent record edits both persist',async()=>{const r=setup();await Promise.all([applyAdminChanges(r,admin,{changes:[{kind:'cabinets',id:'c1',expectedVersion:0,value:{id:'c1',nameEn:'Cabinet'}}]},'a1'),applyAdminChanges(r,admin,{changes:[{kind:'cabinets',id:'c2',expectedVersion:0,value:{id:'c2',nameEn:'Cabinet 2'}}]},'a2')]);assert.ok(r.get('cabinets','c1'));assert.ok(r.get('cabinets','c2'));});
test('negative stock, invalid dates and duplicate items rejected',async()=>{const r=setup();await assert.rejects(()=>applyAdminChanges(r,admin,{changes:[{kind:'inventory',id:'i1',expectedVersion:1,value:{qty:-1}}]},'a1'),{code:'NEGATIVE_STOCK'});await assert.rejects(()=>createRequisition(r,teacher,{...req(),date:'2026-02-30'},'c1'),{code:'INVALID_DATE'});await assert.rejects(()=>createRequisition(r,teacher,{...req(),items:[{itemId:'i1',qty:1},{itemId:'i1',qty:1}]},'c2'),{code:'DUPLICATE_ITEM'});});
test('passwords and secret fields never enter synced settings',()=>{const out=cleanSettings({schoolName:'Regent',adminPassword:'test-only',teachers:[{name:'Teacher',password:'test-only'}],nested:{privateKey:'test-only'}});assert.deepEqual(out,{schoolName:'Regent',teachers:[{name:'Teacher'}],nested:{}});});
test('weekend policy remains owner-configured, not silently assumed',async()=>{const r=setup();r.set('settings','main',{labs:['Lab 1'],periods:['Period 1'],allowedWeekdays:[0,1,2,3,4]});await assert.rejects(()=>createRequisition(r,teacher,{...req(),date:'2026-11-21'},'c1'),{code:'CLOSED_DAY'});});
test('unauthenticated calls are rejected',async()=>{const r=setup();await assert.rejects(()=>createRequisition(r,null,req(),'c1'),{code:'UNAUTHENTICATED'});});
test('classroom loans are issued and returned exactly once',async()=>{const r=setup();const out=await issueManualLoan(r,admin,{itemId:'i1',qty:2,teacherName:'Teacher One',classRoom:'Grade 7',dueDate:'2026-11-23'},'a1');assert.equal(r.get('inventory','i1').qty,8);await Promise.all([returnLoan(r,admin,{loanId:out.loan.id},'a2'),returnLoan(r,admin,{loanId:out.loan.id},'a3')]);assert.equal(r.get('inventory','i1').qty,10);});
test('rejecting a pending lab request frees the laboratory period without changing stock',async()=>{const r=setup();await createRequisition(r,teacher,req(),'c1');await decideRequisition(r,admin,{requestId:'r1',decision:'rejected'},'a1');await createRequisition(r,teacher,req('r2'),'c2');assert.equal(r.get('inventory','i1').qty,10);});
const slot=(id='s1')=>({id,lab:'Lab 1',day:'Sunday',period:'Period 1',weekDate:'2026-11-22',recurrence:'weekly',skippedDates:[]});
test('overlapping recurring schedule slots are rejected',async()=>{const r=setup();r.set('scheduleSlots','s1',{...slot(),version:1});await assert.rejects(()=>applyAdminChanges(r,admin,{changes:[{kind:'scheduleSlots',id:'s2',expectedVersion:0,value:slot('s2')}]},'a1'),{code:'BOOKING_CONFLICT'});assert.equal(r.get('scheduleSlots','s2'),null);});
test('calendar weekday mismatches do not silently book a different day',async()=>{const r=setup();await assert.rejects(()=>applyAdminChanges(r,admin,{changes:[{kind:'scheduleSlots',id:'s1',expectedVersion:0,value:{...slot(),day:'Monday'}}]},'a1'),{code:'INVALID_WEEKDAY'});});
test('manual slot cannot override an existing teacher requisition',async()=>{const r=setup();await createRequisition(r,teacher,req(),'c1');await assert.rejects(()=>applyAdminChanges(r,admin,{changes:[{kind:'scheduleSlots',id:'s1',expectedVersion:0,value:slot()}]},'a1'),{code:'BOOKING_CONFLICT'});});
test('teacher-supplied markup is rejected before saving',async()=>{const r=setup();await assert.rejects(()=>createRequisition(r,teacher,{...req(),experiment:'<img src=x onerror=alert(1)>'},'c1'),{code:'INVALID_TEXT'});assert.equal(r.get('requests','r1'),null);});
test('loss with partial loan return restocks only the undamaged amount, once',async()=>{const {recordLoss}=await import('../domain.mjs');const r=setup();const {loan}=await issueManualLoan(r,admin,{itemId:'i1',qty:4,teacherName:'Teacher One',classRoom:'Grade 7',dueDate:'2026-11-23'},'a1');const payload={itemId:'i1',qty:1,reason:'Breakage',linkedLoanId:loan.id};await recordLoss(r,admin,payload,'a2');await recordLoss(r,admin,payload,'a2');assert.equal(r.get('inventory','i1').qty,9);assert.equal(r.get('loans',loan.id).status,'returned');});
test('loss larger than available stock is rejected instead of silently clamped',async()=>{const {recordLoss}=await import('../domain.mjs');const r=setup();await assert.rejects(()=>recordLoss(r,admin,{itemId:'i1',qty:11,reason:'Breakage'},'a1'),{code:'INSUFFICIENT_STOCK'});assert.equal(r.get('inventory','i1').qty,10);});
test('reversing an approved lab request restores stock once, frees the period and records the reason',async()=>{
  const {reverseRequisition}=await import('../domain.mjs');
  const r=setup();await createRequisition(r,teacher,req(),'c1');await decideRequisition(r,admin,{requestId:'r1',decision:'approved'},'a1');
  assert.equal(r.get('inventory','i1').qty,7);
  const out=await reverseRequisition(r,admin,{requestId:'r1',reason:'Teacher cancelled the lesson'},'v1');
  assert.equal(r.get('inventory','i1').qty,10);
  assert.equal(out.request.reversed,true);assert.equal(out.request.status,'approved');assert.equal(out.request.reversalReason,'Teacher cancelled the lesson');
  const again=await reverseRequisition(r,admin,{requestId:'r1',reason:'Teacher cancelled the lesson'},'v2');
  assert.equal(again.alreadyApplied,true);assert.equal(r.get('inventory','i1').qty,10);
  assert.ok([...r.rows.keys()].some(k=>k.startsWith('logs/')));
  const next=await createRequisition(r,teacher,req('r2'),'c3');assert.ok(next.request.id==='r2');
});
test('only approved requests can be reversed and a reason is required',async()=>{
  const {reverseRequisition}=await import('../domain.mjs');
  const r=setup();await createRequisition(r,teacher,req(),'c1');
  await assert.rejects(()=>reverseRequisition(r,admin,{requestId:'r1',reason:'too early'},'v1'),{code:'NOT_APPROVED'});
  await decideRequisition(r,admin,{requestId:'r1',decision:'approved'},'a1');
  await assert.rejects(()=>reverseRequisition(r,admin,{requestId:'r1',reason:''},'v2'),{code:'INVALID_TEXT'});
  await assert.rejects(()=>reverseRequisition(r,teacher,{requestId:'r1',reason:'teacher attempt'},'v3'),{code:'FORBIDDEN'});
});
test('reversing an outside-lab request closes the active loan and restocks exactly once',async()=>{
  const {reverseRequisition}=await import('../domain.mjs');
  const r=setup();
  await createRequisition(r,teacher,{...req('r9'),usageMode:'outside-lab',returnDate:'2026-11-25'},'c9');
  await decideRequisition(r,admin,{requestId:'r9',decision:'approved'},'a9');
  assert.equal(r.get('inventory','i1').qty,7);
  const loan=[...r.rows.entries()].find(([k])=>k.startsWith('loans/'))[1];
  assert.equal(loan.status,'active');
  await reverseRequisition(r,admin,{requestId:'r9',reason:'Classroom session cancelled'},'v9');
  assert.equal(r.get('inventory','i1').qty,10);
  assert.equal([...r.rows.entries()].find(([k])=>k.startsWith('loans/'))[1].status,'returned');
});
test('reversal after an ordinary loan return does not add stock again',async()=>{
  const {reverseRequisition}=await import('../domain.mjs');
  const r=setup();
  await createRequisition(r,teacher,{...req('r8'),usageMode:'outside-lab',returnDate:'2026-11-25'},'c8');
  await decideRequisition(r,admin,{requestId:'r8',decision:'approved'},'a8');
  const loanId=[...r.rows.keys()].find(k=>k.startsWith('loans/')).split('/')[1];
  await returnLoan(r,admin,{loanId},'a7');
  assert.equal(r.get('inventory','i1').qty,10);
  await reverseRequisition(r,admin,{requestId:'r8',reason:'Record correction'},'v8');
  assert.equal(r.get('inventory','i1').qty,10);
  assert.equal(r.get('requests','r8').reversed,true);
});
test('batch stock deducts the earliest expiry first and keeps the total consistent',async()=>{
  const r=setup();
  await applyAdminChanges(r,admin,{changes:[{kind:'inventory',id:'i1',expectedVersion:1,value:{id:'i1',nameEn:'Beaker',unit:'pcs',batches:[{id:'b1',qty:4,expiry:'2027-01-01'},{id:'b2',qty:6,expiry:'2028-06-01'}]}}]},'b1');
  let item=r.get('inventory','i1');assert.equal(item.qty,10);
  await createRequisition(r,teacher,{...req(),items:[{itemId:'i1',qty:5}]},'c1');
  await decideRequisition(r,admin,{requestId:'r1',decision:'approved'},'a1');
  item=r.get('inventory','i1');assert.equal(item.qty,5);
  assert.deepEqual(item.batches,[{id:'b2',qty:5,expiry:'2028-06-01'}]);
});
test('batch totals and identifiers are validated on admin writes',async()=>{
  const r=setup();
  await assert.rejects(()=>applyAdminChanges(r,admin,{changes:[{kind:'inventory',id:'i1',expectedVersion:1,value:{id:'i1',batches:[{qty:2,expiry:'2027-13-40'}]}}]},'b1'),{code:'INVALID_DATE'});
  await assert.rejects(()=>applyAdminChanges(r,admin,{changes:[{kind:'inventory',id:'i1',expectedVersion:1,value:{id:'i1',batches:[{qty:0}]}}]},'b2'),{code:'INVALID_QUANTITY'});
  await assert.rejects(()=>applyAdminChanges(r,admin,{changes:[{kind:'inventory',id:'i1',expectedVersion:1,value:{id:'i1',batches:[{id:'x',qty:1},{id:'x',qty:1}]}}]},'b3'),{code:'INVALID_BATCHES'});
  const out=await applyAdminChanges(r,admin,{changes:[{kind:'inventory',id:'i1',expectedVersion:1,value:{id:'i1',qty:99,batches:[{qty:3,expiry:'2027-01-01'}]}}]},'b4');
  assert.equal(out.changes[0].value.qty,3);
});
test('clearing batches returns the item to plain quantity tracking',async()=>{
  const r=setup();
  await applyAdminChanges(r,admin,{changes:[{kind:'inventory',id:'i1',expectedVersion:1,value:{id:'i1',nameEn:'Beaker',batches:[{id:'b1',qty:4,expiry:'2027-01-01'}]}}]},'b1');
  let item=r.get('inventory','i1');assert.equal(item.qty,4);
  await applyAdminChanges(r,admin,{changes:[{kind:'inventory',id:'i1',expectedVersion:item.version,value:{...item,qty:9,batches:[]}}]},'b2');
  item=r.get('inventory','i1');assert.equal(item.qty,9);assert.equal(item.batches,undefined);
  const {loan}=await issueManualLoan(r,admin,{itemId:'i1',qty:2,teacherName:'Teacher One',classRoom:'Grade 7',dueDate:'2026-11-23'},'b5');
  await returnLoan(r,admin,{loanId:loan.id},'b6');
  assert.equal(r.get('inventory','i1').qty,9);
});
test('loan returns restore the exact batches the stock came from, not a fresher batch',async()=>{
  const r=setup();
  await applyAdminChanges(r,admin,{changes:[{kind:'inventory',id:'i1',expectedVersion:1,value:{id:'i1',nameEn:'Beaker',unit:'pcs',batches:[{id:'old',qty:4,expiry:'2026-12-01'},{id:'fresh',qty:6,expiry:'2029-01-01'}]}}]},'b1');
  const {loan}=await issueManualLoan(r,admin,{itemId:'i1',qty:5,teacherName:'Teacher One',classRoom:'Grade 7',dueDate:'2026-11-23'},'b2');
  assert.deepEqual(loan.batchAllocations,[{batchId:'old',qty:4,expiry:'2026-12-01'},{batchId:'fresh',qty:1,expiry:'2029-01-01'}]);
  assert.deepEqual(r.get('inventory','i1').batches,[{id:'fresh',qty:5,expiry:'2029-01-01'}]);
  await returnLoan(r,admin,{loanId:loan.id},'b3');
  const item=r.get('inventory','i1');
  assert.equal(item.qty,10);
  assert.deepEqual(item.batches.find(b=>b.id==='old'),{id:'old',qty:4,expiry:'2026-12-01'});
  assert.equal(item.batches.find(b=>b.id==='fresh').qty,6);
});
test('reversal restores the batches recorded at approval',async()=>{
  const {reverseRequisition}=await import('../domain.mjs');
  const r=setup();
  await applyAdminChanges(r,admin,{changes:[{kind:'inventory',id:'i1',expectedVersion:1,value:{id:'i1',nameEn:'Beaker',unit:'pcs',batches:[{id:'old',qty:4,expiry:'2026-12-01'},{id:'fresh',qty:6,expiry:'2029-01-01'}]}}]},'b1');
  await createRequisition(r,teacher,{...req(),items:[{itemId:'i1',qty:5}]},'c1');
  await decideRequisition(r,admin,{requestId:'r1',decision:'approved'},'a1');
  assert.deepEqual(r.get('requests','r1').batchAllocations,[{itemId:'i1',batchId:'old',qty:4,expiry:'2026-12-01'},{itemId:'i1',batchId:'fresh',qty:1,expiry:'2029-01-01'}]);
  await reverseRequisition(r,admin,{requestId:'r1',reason:'Session cancelled'},'v1');
  const item=r.get('inventory','i1');
  assert.equal(item.qty,10);
  assert.deepEqual(item.batches.find(b=>b.id==='old'),{id:'old',qty:4,expiry:'2026-12-01'});
  assert.equal(item.batches.find(b=>b.id==='fresh').qty,6);
});
test('legacy loan without recorded provenance restocks to an explicit unallocated batch',async()=>{
  const r=setup();
  await applyAdminChanges(r,admin,{changes:[{kind:'inventory',id:'i1',expectedVersion:1,value:{id:'i1',nameEn:'Beaker',unit:'pcs',batches:[{id:'fresh',qty:6,expiry:'2029-01-01'}]}}]},'b1');
  r.set('loans','legacy1',{id:'legacy1',itemId:'i1',itemName:'Beaker',qty:2,status:'active',teacherName:'Teacher One',version:1});
  await returnLoan(r,admin,{loanId:'legacy1'},'b2');
  const item=r.get('inventory','i1');
  assert.equal(item.qty,8);
  assert.deepEqual(item.batches.find(b=>b.id==='batch_unallocated'),{id:'batch_unallocated',qty:2,expiry:''});
  assert.equal(item.batches.find(b=>b.id==='fresh').qty,6);
});
test('partial loss of a loan consumes earliest-expiry provenance and returns the rest to source batches',async()=>{
  const {recordLoss}=await import('../domain.mjs');
  const r=setup();
  await applyAdminChanges(r,admin,{changes:[{kind:'inventory',id:'i1',expectedVersion:1,value:{id:'i1',nameEn:'Beaker',unit:'pcs',batches:[{id:'old',qty:4,expiry:'2026-12-01'},{id:'fresh',qty:6,expiry:'2029-01-01'}]}}]},'b1');
  const {loan}=await issueManualLoan(r,admin,{itemId:'i1',qty:5,teacherName:'Teacher One',classRoom:'Grade 7',dueDate:'2026-11-23'},'b2');
  await recordLoss(r,admin,{itemId:'i1',qty:2,reason:'Breakage',linkedLoanId:loan.id},'b3');
  const item=r.get('inventory','i1');
  assert.equal(item.qty,8);
  assert.deepEqual(item.batches.find(b=>b.id==='old'),{id:'old',qty:2,expiry:'2026-12-01'});
  assert.equal(item.batches.find(b=>b.id==='fresh').qty,6);
});
test('server snapshots capture a consistent dataset, respect retention and stay admin-only',async()=>{
  const {createSnapshot,listSnapshots,loadSnapshot}=await import('../domain.mjs');
  const r=setup();
  await assert.rejects(()=>createSnapshot(r,teacher,'s0'),{code:'FORBIDDEN'});
  const first=await createSnapshot(r,admin,'s1');
  assert.equal(first.snapshot.counts.inventory,1);
  const listed=await listSnapshots(r,admin);
  assert.equal(listed.snapshots.length,1);
  const loaded=await loadSnapshot(r,admin,first.snapshot.id);
  assert.equal(loaded.data.inventory[0].id,'i1');assert.equal(loaded.data.inventory[0]._revision,undefined);
  for(let i=0;i<35;i++)await createSnapshot(r,admin,'sx'+i);
  assert.equal((await listSnapshots(r,admin)).snapshots.length,30);
  await assert.rejects(()=>loadSnapshot(r,admin,'snap_missing'),{code:'NOT_FOUND'});
});
