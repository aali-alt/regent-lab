import test,{after,before} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {initializeApp,deleteApp} from 'firebase-admin/app';
import {getFirestore} from 'firebase-admin/firestore';
import {getAuth} from 'firebase-admin/auth';
import {initializeTestEnvironment,assertFails,assertSucceeds} from '@firebase/rules-unit-testing';
import {doc,getDoc,setDoc,collection,query,where,getDocs} from 'firebase/firestore';
import {FirestoreRepository} from '../firebase-repository.mjs';
import {createRequisition,decideRequisition,applyAdminChanges,returnLoan} from '../domain.mjs';
const enabled=!!process.env.FIRESTORE_EMULATOR_HOST;
const projectId='demo-regent-lab';
let app,db,repo,env;
const admin={uid:'admin1',role:'admin',name:'Lab Admin'},teacher={uid:'teacher1',role:'teacher',name:'Teacher One'};
const request=(id,date='2026-11-22')=>({id,date,usageMode:'in-lab',lab:'Lab 1',period:'Period 1',experiment:'Microscopy',grade:'Grade 7',subject:'Biology',items:[{itemId:'beaker',qty:3}]});
before(async()=>{if(!enabled)return;assert.match(process.env.FIRESTORE_EMULATOR_HOST,/^(127\.0\.0\.1|localhost):/);app=initializeApp({projectId},'integration');db=getFirestore(app);repo=new FirestoreRepository(db);env=await initializeTestEnvironment({projectId,firestore:{rules:await readFile(new URL('../firestore.review.rules',import.meta.url),'utf8')}});});
after(async()=>{if(env)await env.cleanup();if(app)await deleteApp(app);});
async function seed(){await env.clearFirestore();await db.doc('regent_v2_inventory/beaker').set({id:'beaker',nameEn:'Beaker',unit:'pcs',qty:10,version:1});await db.doc('regent_v2_settings/main').set({labs:['Lab 1'],periods:['Period 1']});for(const a of [admin,teacher,{uid:'teacher2',role:'teacher',name:'Teacher Two'}])await db.doc('regent_v2_accounts/'+a.uid).set({...a,disabled:false,validAfter:0,sessionVersion:1});}
const integration=(name,fn)=>test(name,{skip:!enabled},fn);
integration('Firestore: concurrent requests for one slot have exactly one winner',async()=>{await seed();const results=await Promise.allSettled([createRequisition(repo,teacher,request('r1'),'c1'),createRequisition(repo,{...teacher,uid:'teacher2'},request('r2'),'c2')]);assert.equal(results.filter(x=>x.status==='fulfilled').length,1);assert.equal(results.find(x=>x.status==='rejected').reason.code,'BOOKING_CONFLICT');});
integration('Firestore: disjoint requests both persist and duplicate approval is atomic',async()=>{await seed();await Promise.all([createRequisition(repo,teacher,request('r1'),'c1'),createRequisition(repo,{...teacher,uid:'teacher2'},request('r2','2026-11-23'),'c2')]);assert.equal((await db.collection('regent_v2_requests').get()).size,2);await Promise.all([decideRequisition(repo,admin,{requestId:'r1',decision:'approved'},'a1'),decideRequisition(repo,admin,{requestId:'r1',decision:'approved'},'a2')]);assert.equal((await db.doc('regent_v2_inventory/beaker').get()).data().qty,7);});
integration('Firestore: teacher booking and admin recurring slot cannot race past each other',async()=>{await seed();const results=await Promise.allSettled([createRequisition(repo,teacher,request('r1'),'c1'),applyAdminChanges(repo,admin,{changes:[{kind:'scheduleSlots',id:'s1',expectedVersion:0,value:{id:'s1',lab:'Lab 1',period:'Period 1',day:'Sunday',weekDate:'2026-11-22',recurrence:'weekly'}}]},'a1')]);assert.equal(results.filter(x=>x.status==='fulfilled').length,1);assert.equal(results.find(x=>x.status==='rejected').reason.code,'BOOKING_CONFLICT');});
integration('Rules: unauthenticated clients cannot read inventory, legacy documents, or write requests',async()=>{await seed();const client=env.unauthenticatedContext().firestore();await assertFails(getDoc(doc(client,'regent_v2_inventory/beaker')));await assertFails(getDoc(doc(client,'regent_lab_data/main_state')));await assertFails(setDoc(doc(client,'regent_v2_requests/forged'),{teacherUid:'teacher1',status:'approved'}));});
integration('Rules: teacher can read own requests only and cannot write stock',async()=>{await seed();await createRequisition(repo,teacher,request('r1'),'c1');await createRequisition(repo,{...teacher,uid:'teacher2'},request('r2','2026-11-23'),'c2');const client=env.authenticatedContext('teacher1',{auth_time:100,sessionVersion:1}).firestore();await assertSucceeds(getDoc(doc(client,'regent_v2_requests/r1')));await assertFails(getDoc(doc(client,'regent_v2_requests/r2')));await assertSucceeds(getDocs(query(collection(client,'regent_v2_requests'),where('teacherUid','==','teacher1'))));await assertFails(getDocs(collection(client,'regent_v2_requests')));await assertFails(setDoc(doc(client,'regent_v2_inventory/beaker'),{qty:100}));});
integration('Rules: admin can read all requests but cannot bypass the transaction server',async()=>{await seed();const client=env.authenticatedContext('admin1',{auth_time:100,sessionVersion:1}).firestore();await assertSucceeds(getDocs(collection(client,'regent_v2_requests')));await assertFails(setDoc(doc(client,'regent_v2_inventory/beaker'),{qty:-1}));});
integration('Rules: disabled accounts and pre-reset sessions lose access immediately',async()=>{await seed();const old=env.authenticatedContext('teacher1',{auth_time:100,sessionVersion:1}).firestore();await assertSucceeds(getDoc(doc(old,'regent_v2_inventory/beaker')));await db.doc('regent_v2_accounts/teacher1').update({sessionVersion:2});await assertFails(getDoc(doc(old,'regent_v2_inventory/beaker')));const fresh=env.authenticatedContext('teacher1',{auth_time:101,sessionVersion:2}).firestore();await assertSucceeds(getDoc(doc(fresh,'regent_v2_inventory/beaker')));await db.doc('regent_v2_accounts/teacher1').update({disabled:true});await assertFails(getDoc(doc(fresh,'regent_v2_inventory/beaker')));});

import {restPlatform} from '../rest-platform.mjs';
import {createHandler} from '../http-handler.mjs';
import {createServer} from 'node:http';
const platform=enabled?restPlatform({projectId,apiKey:'local-test-api-key',emulatorFirestore:process.env.FIRESTORE_EMULATOR_HOST,emulatorAuth:process.env.FIREBASE_AUTH_EMULATOR_HOST}):null;
const restRepo=enabled?new FirestoreRepository(platform.db):null;
integration('REST adapter: serialized transactions preserve requests and idempotent stock decisions',async()=>{await seed();await Promise.all([createRequisition(restRepo,teacher,request('rr1'),'rc1'),createRequisition(restRepo,{...teacher,uid:'teacher2'},request('rr2','2026-11-23'),'rc2')]);await Promise.all([decideRequisition(restRepo,admin,{requestId:'rr1',decision:'approved'},'ra1'),decideRequisition(restRepo,admin,{requestId:'rr1',decision:'approved'},'ra2')]);assert.equal((await db.doc('regent_v2_inventory/beaker').get()).data().qty,7);assert.equal((await db.collection('regent_v2_requests').get()).size,2);});
integration('REST adapter: recurring-slot race is rejected atomically',async()=>{await seed();const results=await Promise.allSettled([createRequisition(restRepo,teacher,request('rr1'),'rc1'),applyAdminChanges(restRepo,admin,{changes:[{kind:'scheduleSlots',id:'rs1',expectedVersion:0,value:{id:'rs1',lab:'Lab 1',period:'Period 1',day:'Sunday',weekDate:'2026-11-22',recurrence:'weekly'}}]},'ra1')]);assert.equal(results.filter(r=>r.status==='fulfilled').length,1);assert.equal(results.find(r=>r.status==='rejected').reason.code,'BOOKING_CONFLICT');});
integration('Real HTTP/Auth emulator: admin-managed teacher passwords, role checks, revocation, and safe directory',async()=>{
  await seed();
  const auth=getAuth(app);
  try{await auth.deleteUser('admin1');}catch{}
  await auth.createUser({uid:'admin1',email:'admin@demo.invalid',password:'Local-emulator-only-2026',displayName:'Lab Admin'});
  await auth.setCustomUserClaims('admin1',{sessionVersion:1});
  const origin='https://aali-alt.github.io';
  const server=createServer(createHandler({repo:restRepo,auth:platform.auth,allowedOrigin:origin}));
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const base='http://127.0.0.1:'+server.address().port;
  const login=async(email,password)=>{const res=await fetch('http://'+process.env.FIREBASE_AUTH_EMULATOR_HOST+'/identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=local-test-api-key',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password,returnSecureToken:true})});const out=await res.json();assert.equal(res.status,200,JSON.stringify(out));return out.idToken;};
  const post=async(path,token,value,command='http1',from=origin)=>{const res=await fetch(base+path,{method:'POST',headers:{Origin:from,'Content-Type':'application/json','X-Command-ID':command,...(token?{Authorization:'Bearer '+token}:{})},body:JSON.stringify(value)});return {status:res.status,body:await res.json()};};
  try{
    const adminToken=await login('admin@demo.invalid','Local-emulator-only-2026');
    const missing=await post('/admin/accounts/create','',{name:'Teacher X',password:'Local-teacher-only-2026'});assert.equal(missing.status,401);
    const wrongOrigin=await post('/admin/accounts/create',adminToken,{name:'Teacher X',password:'Local-teacher-only-2026'},'x1','https://wrong.invalid');assert.equal(wrongOrigin.status,403);
    const created=await post('/admin/accounts/create',adminToken,{name:'Teacher X',password:'Local-teacher-only-2026'},'create1');assert.equal(created.status,201,JSON.stringify(created.body));
    const duplicate=await post('/admin/accounts/create',adminToken,{name:'Teacher X',password:'Local-teacher-only-2026'},'create1');assert.equal(duplicate.status,200);assert.equal(duplicate.body.account.uid,created.body.account.uid);
    const {uid,login:email}=created.body.account;
    let teacherToken=await login(email,'Local-teacher-only-2026');
    const denied=await post('/admin/accounts/create',teacherToken,{name:'Teacher Y',password:'Local-teacher-only-2026'},'create2');assert.equal(denied.status,403);
    const reset=await post('/admin/accounts/password',adminToken,{uid,password:'Local-replacement-only-2026'},'reset1');assert.equal(reset.status,200,JSON.stringify(reset.body));
    const oldSession=await fetch(base+'/me',{headers:{Authorization:'Bearer '+teacherToken}});assert.equal(oldSession.status,401);
    teacherToken=await login(email,'Local-replacement-only-2026');
    const newSession=await fetch(base+'/me',{headers:{Authorization:'Bearer '+teacherToken}});assert.equal(newSession.status,200);
    const directory=await(await fetch(base+'/directory')).json();const entry=directory.accounts.find(a=>a.uid===uid);assert.deepEqual(Object.keys(entry).sort(),['login','name','role','uid']);
    const profile=(await db.doc('regent_v2_accounts/'+uid).get()).data();assert.equal('password'in profile,false);
    const disabled=await post('/admin/accounts/disable',adminToken,{uid},'disable1');assert.equal(disabled.status,200);
    const disabledSession=await fetch(base+'/me',{headers:{Authorization:'Bearer '+teacherToken}});assert.ok([401,403].includes(disabledSession.status));
  }finally{await new Promise(resolve=>server.close(resolve));}
});
