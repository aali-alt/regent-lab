import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import {createServer} from 'node:http';
import {createRequire} from 'node:module';
import {build} from 'esbuild';
import {chromium} from 'playwright-core';
import {initializeApp,deleteApp} from 'firebase-admin/app';
import {getAuth} from 'firebase-admin/auth';
import {getFirestore} from 'firebase-admin/firestore';
import {FirestoreRepository} from '../firebase-repository.mjs';
import {createHandler} from '../http-handler.mjs';
assert.match(process.env.FIRESTORE_EMULATOR_HOST||'',/^127\.0\.0\.1:/);
assert.match(process.env.FIREBASE_AUTH_EMULATOR_HOST||'',/^127\.0\.0\.1:/);
const require=createRequire(import.meta.url),dir=path.resolve('..'),app=initializeApp({projectId:'demo-regent-lab'},'ui-test'),db=getFirestore(app),auth=getAuth(app);
let browser,apiServer,siteServer;
try{
  await fetch('http://'+process.env.FIRESTORE_EMULATOR_HOST+'/emulator/v1/projects/demo-regent-lab/databases/(default)/documents',{method:'DELETE'});
  const source=await fs.readFile(path.join(dir,'index.html'),'utf8');
  const expression=source.match(/const DEFAULT_STATE = ([\s\S]+?);\n\n        function loadLocalState/)[1];
  const state=vm.runInNewContext('('+expression+')');
  const clean=value=>Array.isArray(value)?value.map(clean):value&&typeof value==='object'?Object.fromEntries(Object.entries(value).filter(([key])=>!/password|secret|credential/i.test(key)).map(([key,val])=>[key,clean(val)])):value;
  state.settings=clean(state.settings);delete state.settings.teachers;
  await db.doc('regent_v2_settings/main').set({...state.settings,version:1});
  for(const kind of ['inventory','cabinets','logs'])for(const row of state[kind])await db.doc('regent_v2_'+kind+'/'+row.id).set({...row,version:1,...(kind==='inventory'?{qty:10}:{})});
  for(const account of [{uid:'ui_admin',name:'admin',role:'admin'},{uid:'ui_teacher',name:'Teacher One',role:'teacher'}]){
    const login=account.uid+'@demo.invalid';try{await auth.deleteUser(account.uid);}catch{}
    await auth.createUser({uid:account.uid,email:login,password:'Local-ui-fixture-only-2026'});await auth.setCustomUserClaims(account.uid,{sessionVersion:1});
    await db.doc('regent_v2_accounts/'+account.uid).set({...account,login,disabled:false,sessionVersion:1,validAfter:0});
    await db.doc('regent_v2_directory/'+account.uid).set({...account,login,disabled:false});
  }
  await build({entryPoints:[path.join(dir,'secure-client.mjs')],outfile:path.join(dir,'ui-client.bundle.js'),format:'iife',globalName:'RegentSecureReview',bundle:true,platform:'browser',plugins:[{name:'local-firebase-sdk',setup(builder){builder.onResolve({filter:/^https:\/\/www\.gstatic\.com\/firebasejs\/.*\/firebase-(app|auth|firestore)\.js$/},args=>({path:require.resolve('firebase/'+args.path.match(/firebase-(app|auth|firestore)\.js$/)[1])}));}}]});
  let html=source.replace('import {createSecureClient} from "./secure-client.mjs";','const {createSecureClient}=window.RegentSecureReview;').replace('const SECURE_BACKEND_URL = "";','const SECURE_BACKEND_URL = "http://127.0.0.1:8787";').replace('testEmulators: false','testEmulators: true').replace(/regent-lab\.firebaseapp\.com/g,'demo-regent-lab.firebaseapp.com').replace('projectId: "regent-lab"','projectId: "demo-regent-lab"');
  html=html.replace('<script type="module">','<script src="/ui-client.bundle.js"></script><script type="module">');
  html=html.replace(/<script\b[^>]*src=["']https:\/\/cdn.tailwindcss.com["'][^>]*><\/script>/,()=>'<script>'+require('node:fs').readFileSync(path.join(dir,'tailwind.js'),'utf8')+'</script>').replace(/<script\b[^>]*src=["'][^"']*qrcode.min.js["'][^>]*><\/script>/,()=>'<script>'+require('node:fs').readFileSync(path.join(dir,'qrcode.js'),'utf8')+'</script>');
  html=html.replace('</head>','<style>*,*::before,*::after{animation:none!important;transition:none!important}</style></head>');
  await fs.writeFile(path.join(dir,'ui-emulator-preview.html'),html);
  apiServer=createServer(createHandler({repo:new FirestoreRepository(db),auth,allowedOrigin:'http://127.0.0.1:4173',allowLocalDevelopment:true}));await new Promise(r=>apiServer.listen(8787,'127.0.0.1',r));
  siteServer=createServer(async(req,res)=>{let file=req.url.startsWith('/ui-client.bundle.js')?'ui-client.bundle.js':req.url.startsWith('/assets/')?req.url.slice(1).split('?')[0]:'ui-emulator-preview.html';if(!/^[a-zA-Z0-9_./-]+$/.test(file)||file.includes('..')){res.statusCode=404;return res.end();}res.setHeader('Content-Type',file.endsWith('.js')?'application/javascript':file.endsWith('.css')?'text/css':file.endsWith('.woff2')?'font/woff2':'text/html');try{res.end(await fs.readFile(path.join(dir,file)));}catch{res.statusCode=404;res.end();}});await new Promise(r=>siteServer.listen(4173,'127.0.0.1',r));
  browser=await chromium.launch({executablePath:'/usr/bin/google-chrome',headless:true,args:['--no-sandbox']});
  const context=await browser.newContext({viewport:{width:1440,height:1000}});
  await context.route('**/*',route=>new URL(route.request().url()).hostname==='127.0.0.1'?route.continue():route.abort());
  const teacher=await context.newPage();const errors=[];teacher.on('pageerror',err=>errors.push(err.message));
  await teacher.goto('http://127.0.0.1:4173/?mode=teacher');
  await teacher.locator('#tp-login-teacher-select').selectOption('Teacher One',{timeout:15000});await teacher.locator('#tp-login-password').fill('Local-ui-fixture-only-2026');await teacher.locator('#tp-login-password').press('Enter');
  await teacher.locator('#tp-main-content').waitFor({state:'visible',timeout:20000});
  await teacher.locator('#tp-experiment').fill('UI round-trip microscopy');
  for(const selector of ['#tp-subject','#tp-grade','#tp-period','#tp-lab']){const value=await teacher.locator(selector+' option').evaluateAll(options=>options.find(o=>o.value)?.value);await teacher.locator(selector).selectOption(value);}
  await teacher.locator('#tp-date').fill('2026-11-22');
  const itemId=await teacher.locator('#tp-item-select option').evaluateAll(options=>options.find(o=>o.value)?.value);await teacher.locator('#tp-item-select').selectOption(itemId);await teacher.locator('#tp-item-qty').fill('3');await teacher.getByRole('button',{name:/Add Item/}).click();
  console.log('FORM CHECK',await teacher.locator('#teacher-portal-form').evaluate(form=>({valid:form.checkValidity(),invalid:[...form.querySelectorAll(':invalid')].map(e=>({id:e.id,message:e.validationMessage}))})));
  teacher.on('response',async response=>{if(response.url().startsWith('http://127.0.0.1:8787/')&&response.status()>=400)console.log('API failure',response.status(),await response.text());});
  await teacher.locator('#teacher-portal-form').evaluate(form=>form.requestSubmit());
  console.log('SUBMIT TOAST',await teacher.locator('#toast-container').innerText());
  try{await teacher.locator('#teacher-submit-success').waitFor({state:'visible',timeout:12000});}catch(err){console.log('PAGE ERRORS',errors);console.log('VISIBLE TEXT',(await teacher.locator('body').innerText()).slice(-2500));await teacher.screenshot({path:path.join(dir,'ui-test-failure.png')});throw err;}
  const requests=await db.collection('regent_v2_requests').get();assert.equal(requests.size,1);assert.equal(requests.docs[0].data().teacherUid,'ui_teacher');
  const adminPage=await context.newPage();adminPage.on('pageerror',err=>errors.push(err.message));await adminPage.goto('http://127.0.0.1:4173/');await adminPage.locator('#admin-login-user').fill('admin');await adminPage.locator('#admin-login-pass').fill('Local-ui-fixture-only-2026');await adminPage.locator('#admin-login-pass').press('Enter');
  await adminPage.locator('#admin-login-gate').waitFor({state:'hidden',timeout:20000});await adminPage.evaluate(()=>window.switchTab('requests'));await adminPage.getByRole('button',{name:/Approve & Fulfill/}).click();
  await teacher.getByText('Approved by Lab',{exact:false}).waitFor({state:'visible',timeout:20000});
  assert.equal((await db.doc('regent_v2_inventory/'+itemId).get()).data().qty,7);
  await adminPage.evaluate(()=>document.fonts.ready);await teacher.evaluate(()=>document.fonts.ready);
  await adminPage.screenshot({path:path.join(dir,'ui-auth-admin-desktop.png'),fullPage:false});
  await teacher.setViewportSize({width:390,height:844});await teacher.screenshot({path:path.join(dir,'ui-auth-teacher-mobile.png'),fullPage:false});
  assert.deepEqual(errors,[]);console.log('PASS: actual teacher dropdown/password login, request submission, admin login/approval, stock 10 -> 7, teacher receives approval through live listener. Desktop/mobile screenshots captured. No external network allowed.');
}finally{if(browser)await browser.close();if(apiServer)await new Promise(r=>apiServer.close(r));if(siteServer)await new Promise(r=>siteServer.close(r));await deleteApp(app);}
