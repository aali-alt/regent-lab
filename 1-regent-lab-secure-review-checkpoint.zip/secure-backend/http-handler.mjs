import {AppError,assertActor,createRequisition,decideRequisition,applyAdminChanges,issueManualLoan,returnLoan,recordLoss,id,text} from './domain.mjs';
import {createHash} from 'node:crypto';
const error=(status,code,message)=>{throw new AppError(status,code,message);};
export function createHandler({repo,auth,allowedOrigin,allowLocalDevelopment=false}) {
  if(!allowedOrigin||!(/^https:\/\//.test(allowedOrigin)||(allowLocalDevelopment&&auth.app.options.projectId.startsWith('demo-')&&/^http:\/\/(127\.0\.0\.1|localhost):\d+$/.test(allowedOrigin))))throw new Error('An explicit HTTPS ALLOWED_ORIGIN is required');
  const publicProfile=account=>({uid:account.uid,name:account.name,login:account.login,role:account.role});
  async function actorFor(token){
    if(!token)error(401,'UNAUTHENTICATED','Sign in first');
    let decoded;
    try{decoded=await auth.verifyIdToken(token,true);}catch{error(401,'UNAUTHENTICATED','Sign in again');}
    const snap=await repo.collection('accounts').doc(decoded.uid).get(),profile=snap.data();
    if(!snap.exists||profile.disabled||!['teacher','admin'].includes(profile.role))error(403,'ACCOUNT_DISABLED','Account is not enabled');
    if(decoded.sessionVersion!==profile.sessionVersion||(decoded.auth_time||0)<(profile.validAfter||0))error(401,'SESSION_EXPIRED','Sign in again');
    return {...profile,uid:decoded.uid,authTime:decoded.auth_time};
  }
  return async function handler(request,response){
    const origin=request.headers.origin;
    response.setHeader('Cache-Control','no-store');response.setHeader('Content-Type','application/json; charset=utf-8');
    response.setHeader('X-Content-Type-Options','nosniff');response.setHeader('Vary','Origin');
    const send=(status,body)=>{response.statusCode=status;response.end(JSON.stringify(body));};
    try{
      // Bearer-token authentication is still required. CORS is not authorization.
      if(origin&&origin!==allowedOrigin)error(403,'ORIGIN_DENIED','This origin is not allowed');
      if(origin===allowedOrigin)response.setHeader('Access-Control-Allow-Origin',allowedOrigin);
      response.setHeader('Access-Control-Allow-Headers','Authorization, Content-Type, X-Command-ID');
      response.setHeader('Access-Control-Allow-Methods','GET, POST, OPTIONS');
      if(request.method==='OPTIONS'){response.statusCode=204;return response.end();}
      const url=new URL(request.url,'https://backend.invalid');
      if(request.method==='GET'&&url.pathname==='/health')return send(200,{status:'ok'});
      if(request.method==='GET'&&url.pathname==='/directory'){
        const docs=await repo.collection('directory').where('disabled','==',false).get();
        return send(200,{accounts:docs.docs.map(d=>publicProfile(d.data())).sort((a,b)=>a.name.localeCompare(b.name))});
      }
      const token=/^Bearer ([^ ]+)$/.exec(request.headers.authorization||'')?.[1];
      const actor=await actorFor(token);
      if(request.method==='GET'&&url.pathname==='/me')return send(200,{account:publicProfile(actor)});
      if(request.method!=='POST')error(404,'NOT_FOUND','Action not found');
      if(!/^application\/json(?:;|$)/i.test(request.headers['content-type']||''))error(415,'JSON_REQUIRED','Use JSON');
      let raw='',size=0;
      for await(const chunk of request){size+=chunk.length;if(size>512*1024)error(413,'TOO_LARGE','Request is too large');raw+=chunk;}
      let body;try{body=JSON.parse(raw);}catch{error(400,'INVALID_JSON','Invalid JSON');}
      const commandId=id(request.headers['x-command-id']||'');
      if(url.pathname==='/requests')return send(200,await createRequisition(repo,actor,body,commandId));
      if(url.pathname==='/requests/decide')return send(200,await decideRequisition(repo,actor,body,commandId));
      if(url.pathname==='/admin/changes')return send(200,await applyAdminChanges(repo,actor,body,commandId));
      if(url.pathname==='/loans/issue')return send(200,await issueManualLoan(repo,actor,body,commandId));
      if(url.pathname==='/losses')return send(200,await recordLoss(repo,actor,body,commandId));
      if(url.pathname==='/loans/return')return send(200,await returnLoan(repo,actor,body,commandId));
      if(url.pathname==='/admin/self'){
        assertActor(actor,'admin');
        if(Date.now()/1000-(actor.authTime||0)>300)error(401,'RECENT_LOGIN_REQUIRED','Sign out and sign in again before changing administrator credentials');
        const name=text(body.name,120),password=body.password;
        if(password&&(typeof password!=='string'||password.length<12||password.length>128))error(400,'PASSWORD_POLICY','Use a password of 12 to 128 characters');
        await auth.updateUser(actor.uid,{displayName:name,...(password?{password}:{})});
        const ref=repo.collection('accounts').doc(actor.uid);
        if(password){
          await auth.revokeRefreshTokens(actor.uid);
          const user=await auth.getUser(actor.uid),sessionVersion=(actor.sessionVersion||0)+1;
          await auth.setCustomUserClaims(actor.uid,{...user.customClaims,sessionVersion});
          await ref.update({name,sessionVersion,validAfter:Math.floor(Date.now()/1000)});
        }else await ref.update({name});
        await repo.collection('directory').doc(actor.uid).update({name});
        return send(200,{name,signInAgain:!!password});
      }
      if(url.pathname.startsWith('/admin/accounts')){
        assertActor(actor,'admin');
        if(url.pathname==='/admin/accounts/create'){
          const name=text(body.name,120),role=body.role||'teacher';
          // Additional admins require an explicit future workflow, never a dropdown accident.
          if(role!=='teacher')error(400,'TEACHERS_ONLY','This action creates teacher accounts only');
          if(typeof body.password!=='string'||body.password.length<12||body.password.length>128)error(400,'PASSWORD_POLICY','Use a password of 12 to 128 characters');
          const uid='teacher_'+createHash('sha256').update(actor.uid+':'+commandId).digest('hex').slice(0,32),login=uid+'@'+auth.app.options.projectId+'.invalid';
          const previous=await repo.collection('accounts').doc(uid).get();
          if(previous.exists){
            const existing=previous.data();
            if(existing.name!==name||existing.createdBy!==actor.uid)error(409,'IDEMPOTENCY_CONFLICT','Account operation has different content');
            const user=await auth.getUser(uid);
            if(user.disabled||existing.disabled)error(409,'PROVISIONING_INCOMPLETE','A disabled partial account needs administrator review');
            return send(200,{account:publicProfile(existing),alreadyApplied:true});
          }
          await auth.createUser({uid,email:login,password:body.password,displayName:name,disabled:true});
          const profile={uid,name,login,role,disabled:false,validAfter:0,sessionVersion:1,createdBy:actor.uid,createdAt:repo.now(),version:1};
          // A partially provisioned Auth user remains disabled; no administrator authority is granted.
          try{
            const batch=repo.db.batch();batch.set(repo.collection('accounts').doc(uid),profile);
            batch.set(repo.collection('directory').doc(uid),{...publicProfile(profile),disabled:false});await batch.commit();
            await auth.setCustomUserClaims(uid,{sessionVersion:1});
            await auth.updateUser(uid,{disabled:false});
          }catch{error(503,'PROVISIONING_INCOMPLETE','Teacher account setup did not complete. Do not retry blindly; review the disabled account.');}
          return send(201,{account:publicProfile(profile)});
        }
        const uid=id(body.uid||''),ref=repo.collection('accounts').doc(uid),snap=await ref.get(),account=snap.data();
        if(!snap.exists||account.role!=='teacher')error(404,'TEACHER_NOT_FOUND','Teacher account not found');
        if(url.pathname==='/admin/accounts/password'){
          if(typeof body.password!=='string'||body.password.length<12||body.password.length>128)error(400,'PASSWORD_POLICY','Use a password of 12 to 128 characters');
          // Gate the account first, then revoke. A partial failure is safely disabled, not silently usable.
          await ref.update({disabled:true});await auth.updateUser(uid,{disabled:true});
          await auth.updateUser(uid,{password:body.password});await auth.revokeRefreshTokens(uid);
          const validAfter=Math.floor(Date.now()/1000),sessionVersion=(account.sessionVersion||0)+1;
          const currentUser=await auth.getUser(uid);
          await auth.setCustomUserClaims(uid,{...currentUser.customClaims,sessionVersion});
          await ref.update({validAfter,sessionVersion,disabled:false});await auth.updateUser(uid,{disabled:false});
          return send(200,{account:publicProfile(account),sessionsRevoked:true});
        }
        if(url.pathname==='/admin/accounts/disable'){
          await ref.update({disabled:true});await auth.updateUser(uid,{disabled:true});await auth.revokeRefreshTokens(uid);
          await repo.collection('directory').doc(uid).update({disabled:true});return send(200,{disabled:true,uid});
        }
      }
      error(404,'NOT_FOUND','Action not found');
    }catch(err){
      const known=err instanceof AppError;
      // Never log request bodies, passwords, tokens, or raw provider errors.
      send(known?err.status:503,{error:{code:known?err.code:'SERVICE_UNAVAILABLE',message:known?err.message:'The service could not complete this action. Nothing is confirmed saved.'}});
    }
  };
}
