import { digest } from './domain.mjs';
export class FirestoreRepository {
  constructor(db,{prefix='regent_v2_'}={}) {this.db=db;this.prefix=prefix;}
  now(){return new Date().toISOString();}
  collection(kind){return this.db.collection(this.prefix+kind);}
  async transaction(fn){
    return this.db.runTransaction(async transaction=>{
      const queued=[];
      const tx={
        get:async(kind,id)=>{const snap=await transaction.get(this.collection(kind).doc(id));return snap.exists?snap.data():null;},
        list:async kind=>(await transaction.get(this.collection(kind))).docs.map(doc=>doc.data()),
        set:(kind,id,value)=>queued.push({kind,id,value}),
        delete:(kind,id)=>queued.push({kind,id,delete:true}),
        findActiveBooking:async slot=>{
          const lockRef=this.collection('meta').doc('scheduleLock');
          const lock=await transaction.get(lockRef);
          // A shared lock makes request/recurring-slot conflicts serializable even when their IDs differ.
          queued.push({kind:'meta',id:'scheduleLock',value:{version:(lock.data()?.version||0)+1}});
          const booking=await transaction.get(this.collection('bookings').doc(digest(slot)));
          if(booking.exists)return booking.data();
          const day=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][new Date(slot.date+'T12:00:00Z').getUTCDay()];
          const schedules=await transaction.get(this.collection('scheduleSlots').where('lab','==',slot.lab));
          return schedules.docs.map(d=>d.data()).find(s=>s.day===day&&s.period===slot.period&&!(s.skippedDates||s.excludedDates||[]).includes(slot.date)&&(s.recurrence==='weekly'||s.weekDate===slot.date))||null;
        }
      };
      const result=await fn(tx);
      for(const w of queued){const ref=this.collection(w.kind).doc(w.id);if(w.delete)transaction.delete(ref);else transaction.set(ref,w.value);}
      return result;
    });
  }
}
