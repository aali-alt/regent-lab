import {initializeApp} from 'https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js';
import {getAuth,signInWithEmailAndPassword,signOut,onAuthStateChanged,setPersistence,browserSessionPersistence,connectAuthEmulator} from 'https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js';
import {getFirestore,collection,doc,query,where,onSnapshot,getDoc,connectFirestoreEmulator} from 'https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js';
const kinds=['inventory','cabinets','requests','scheduleSlots','loans','lossRecords','logs'];
const strip=value=>{
  if(Array.isArray(value))return value.map(strip);
  if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).filter(([k])=>!/password|credential|secret|private.?key|auth.?token/i.test(k)&&!['__proto__','constructor','prototype'].includes(k)).map(([k,v])=>[k,strip(v)]));
  return value;
};
const comparable=value=>JSON.stringify(strip(value), (key,val)=>['updatedAt','version','teachers','adminUsername'].includes(key)?undefined:val);
export function createSecureClient({firebaseConfig,backendUrl,onState,onAccount,onDirectory,onStatus,testEmulators}){
  const app=initializeApp(firebaseConfig),auth=getAuth(app),db=getFirestore(app);
  if(testEmulators){
    if(!firebaseConfig.projectId.startsWith('demo-')||!['127.0.0.1','localhost'].includes(location.hostname))throw Error('Emulators are local-only');
    connectAuthEmulator(auth,'http://127.0.0.1:9099',{disableWarnings:true});connectFirestoreEmulator(db,'127.0.0.1',8081);
  }
  let resolveDirectory;const directoryLoaded=new Promise(resolve=>{resolveDirectory=resolve;});
  let account=null,directory=[],unsubscribers=[],snapshot=null,ready=false,paused=0,loginWaiters=[];
  const endpoint=backendUrl?new URL(backendUrl):null;
  if(endpoint&&endpoint.protocol!=='https:'&&!(testEmulators&&endpoint.hostname==='127.0.0.1'))throw Error('Secure backend requires HTTPS');
  async function call(path,value,commandId=crypto.randomUUID()){
    if(!endpoint)throw Error('Secure service setup is incomplete. This review build cannot save to the cloud yet.');
    const token=auth.currentUser?await auth.currentUser.getIdToken():'';
    const response=await fetch(new URL(path,endpoint),{method:value===undefined?'GET':'POST',headers:{...(token?{Authorization:'Bearer '+token}:{}),...(value===undefined?{}:{'Content-Type':'application/json','X-Command-ID':commandId})},...(value===undefined?{}:{body:JSON.stringify(value)}),signal:AbortSignal.timeout(20000)});
    const result=await response.json();if(!response.ok){const err=new Error(result.error?.message||'Could not confirm this action');err.code=result.error?.code;throw err;}return result;
  }
  const withDirectory=state=>({...state,settings:{...state.settings,adminUsername:account?.role==='admin'?account.name:'admin',teachers:directory.filter(a=>a.role==='teacher')}});
  const publish=()=>{if(ready&&!paused)onState(withDirectory(structuredClone(snapshot)));};
  const unsubscribe=()=>{unsubscribers.forEach(fn=>fn());unsubscribers=[];ready=false;snapshot=null;};
  const rejectLogin=err=>{for(const waiter of loginWaiters)waiter.reject(err);loginWaiters=[];};
  function watchSession(profile){
    unsubscribe();account=profile;onAccount(profile);
    const watched=profile.role==='admin'?kinds:['inventory','cabinets','requests','scheduleSlots','loans'];
    const pending=new Set([...watched,'settings']);snapshot=Object.fromEntries(kinds.map(k=>[k,[]]));snapshot.settings={};snapshot.meta={};
    const receive=kind=>snap=>{
      if(kind==='settings'){
        if(!snap.exists()){ready=false;onStatus('Secure setup incomplete: settings have not been imported');return;}
        snapshot.settings=strip(snap.data());
      }else snapshot[kind]=snap.docs.map(doc=>strip(doc.data())).sort((a,b)=>String(b.updatedAt||b.submittedAt||b.issuedAt||'').localeCompare(String(a.updatedAt||a.submittedAt||a.issuedAt||'')));
      pending.delete(kind);
      if(pending.size===0){ready=true;publish();onStatus('Secure live sync active');for(const waiter of loginWaiters)waiter.resolve(profile);loginWaiters=[];}
    };
    const failed=err=>{ready=false;onStatus('Cloud read failed. Changes are not confirmed.');rejectLogin(err);};
    for(const kind of watched){
      let ref=collection(db,'regent_v2_'+kind);
      if(profile.role!=='admin'&&['requests','loans'].includes(kind))ref=query(ref,where('teacherUid','==',profile.uid));
      unsubscribers.push(onSnapshot(ref,receive(kind),failed));
    }
    unsubscribers.push(onSnapshot(doc(db,'regent_v2_settings','main'),receive('settings'),failed));
  }
  const directoryStop=onSnapshot(query(collection(db,'regent_v2_directory'),where('disabled','==',false)),snap=>{
    directory=snap.docs.map(d=>strip(d.data()));resolveDirectory();onDirectory(directory);publish();
  },()=>onStatus('Secure sign-in setup required'));
  const authStop=onAuthStateChanged(auth,async user=>{
    unsubscribe();account=null;onAccount(null);
    if(!user){onStatus('Sign in for secure cloud access');return;}
    try{const {account:profile}=await call('/me');watchSession(profile);}catch(err){onStatus(err.message);rejectLogin(err);await signOut(auth);}
  });
  return {
    get account(){return account;},get ready(){return ready;},get directory(){return structuredClone(directory);},get snapshot(){return snapshot?withDirectory(structuredClone(snapshot)):null;},
    async login(name,password,role){
      if(!endpoint)throw Error('Secure sign-in is not configured on this review build yet.');
      await Promise.race([directoryLoaded,new Promise((_,reject)=>setTimeout(()=>reject(Error('Account list is not available yet. Please retry.')),10000))]);
      const entry=directory.find(a=>a.role===role&&(a.name===name||a.login.toLowerCase()===name.toLowerCase()));
      if(!entry)throw Error('Choose an enabled account and check the password.');
      await setPersistence(auth,browserSessionPersistence);
      const completion=new Promise((resolve,reject)=>{const waiter={resolve,reject};loginWaiters.push(waiter);setTimeout(()=>{const index=loginWaiters.indexOf(waiter);if(index>=0){loginWaiters.splice(index,1);reject(Error('Cloud sign-in setup did not finish. Please retry.'));}},25000);});
      try{await signInWithEmailAndPassword(auth,entry.login,password);}catch(err){rejectLogin(Error('Sign-in failed. Check the account and password.'));}
      return completion;
    },
    async logout(){unsubscribe();account=null;onAccount(null);await signOut(auth);},
    async refresh(){if(!auth.currentUser||!account)return false;const {account:profile}=await call('/me');watchSession(profile);return true;},
    async save(desired){
      if(!ready||account?.role!=='admin')throw Error('An active administrator session is required to save.');
      const base=structuredClone(snapshot),changes=[];
      for(const kind of kinds){
        if(['requests','loans'].includes(kind))continue;
        const before=new Map((base[kind]||[]).map(row=>[row.id,row])),after=new Map((desired[kind]||[]).map(row=>[row.id,row]));
        for(const [id,value]of after){const old=before.get(id);if(!old||comparable(old)!==comparable(value))changes.push({kind,id,expectedVersion:old?.version||0,value:strip(value)});}
        for(const [id,value]of before){if(!after.has(id)&&kind!=='logs')changes.push({kind,id,expectedVersion:value.version||0,delete:true});}
      }
      if(comparable(base.settings)!==comparable(desired.settings)){
        const settings=strip(desired.settings);delete settings.teachers;delete settings.adminUsername;
        changes.push({kind:'settings',id:'main',expectedVersion:base.settings.version||0,value:settings});
      }
      if(changes.length===0)return;
      paused++;
      try{const result=await call('/admin/changes',{changes});
        // Merge the authoritative transaction result immediately; do not wait for a stale listener event.
        for(const change of result.changes){if(change.kind==='settings')snapshot.settings=change.value;else{const rows=snapshot[change.kind];const index=rows.findIndex(r=>r.id===change.key);if(change.delete){if(index>=0)rows.splice(index,1);}else if(index>=0)rows[index]=change.value;else rows.unshift(change.value);}}
      }finally{paused--;publish();}
    },
    async submitRequest(value,commandId){if(!ready||!account)throw Error('Sign in and wait for cloud sync first');return call('/requests',value,commandId);},
    async decideRequest(requestId,decision){return call('/requests/decide',{requestId,decision});},
    async issueLoan(value){return call('/loans/issue',value);},async returnLoan(loanId){return call('/loans/return',{loanId});},
    async recordLoss(value){return call('/losses',value);},
    async updateAdmin(name,password){const result=await call('/admin/self',{name,password});if(result.signInAgain)await signOut(auth);return result;},
    async createTeacher(name,password){return call('/admin/accounts/create',{name,password});},
    async resetTeacher(uid,password){return call('/admin/accounts/password',{uid,password});},
    async disableTeacher(uid){return call('/admin/accounts/disable',{uid});},
    dispose(){unsubscribe();directoryStop();authStop();}
  };
}
