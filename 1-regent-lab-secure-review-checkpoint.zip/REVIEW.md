# Regent Lab secure-sync review, 22 November 2026

This is an unfinished review build. Do not merge or deploy it yet.

## Implemented and tested
- Preserved current application layout and teacher name/password selection.
- Removed external whole-state backup requests.
- Firebase-authenticated account sessions, administrator-controlled teacher passwords, account disable and session revocation.
- Server-enforced roles, teacher-owned requests, read-only browser database rules.
- Per-record version checks and atomic request decisions, stock deductions, manual loans, returns and loss handling.
- Shared booking lock protects recurring schedules against simultaneous teacher requests.
- Password fields are not stored in synchronized settings, and password inputs do not display existing passwords.
- Local-calendar timetable dates and QR default correction from the first review milestone.
- Self-hosted symbol fallback font fixes missing navigation/status icons without changing their labels or meaning.

## Validation completed
- 21 domain tests pass.
- 10 Firebase/Auth emulator integration tests pass.
- Actual UI round-trip passes with synthetic data: teacher login, request, administrator approval, stock 10 to 7, live teacher status update.
- Desktop and phone layouts inspected after adding the symbol font.
- The REST-based backend builds successfully as a Cloudflare Worker in dry-run mode. Nothing was deployed.

## Still required before deployment
- Broader UI regression for inventory editing, loss and partial returns, schedule exceptions, exports/imports and printing.
- Administrator self-credential update route is implemented but still needs its own regression tests.
- Review large imports, password-reset partial failure recovery, save retries and stale-listener behavior.
- Verify hosting operational limits and obtain approval for any new infrastructure.
- Configure production host secrets and restricted service-account permissions through a secure secret store. No keys are included here.
- Approve and execute a separately reviewed data migration, account bootstrap and production rollout. Existing legacy documents must not be overwritten automatically.
- Match school branding from https://ris-newmansoura.com/ after functional work. Only inspection has happened so far, not a visual redesign.

The backend URL is intentionally empty. The app cannot save against the new service until approved setup is completed. The proposed rules are for review only; production client rules remain temporarily deny-all. Existing production data has not been changed by these tests.

## Local tests
Run from secure-backend after installing dependencies:

    npm ci
    npm test
    npm run test:emulator
    npm run test:ui

The emulator tests use a demo project and loopback hosts only. UI tests block all non-local network. Test-only passwords belong solely to disposable emulator accounts and are not school credentials.
