# Regent Lab school production checkpoint

Checkpoint date: 2026-11-22.

This package is the deployed school app, not the isolated pilot.

- Administrator app: https://aali-alt.github.io/regent-lab/
- Teacher QR destination: https://aali-alt.github.io/regent-lab/?mode=teacher&sync=ris-regent-lab-sync-2026
- School backend health: https://regent-lab-backend.pages.dev/health
- Frontend cutover: https://github.com/aali-alt/regent-lab/commit/6d34da6b9daa48ae69f1ccfd228c6707f42f4417

## Contents

`index.html` is the exact HTML downloaded from the published original URL. GitHub Pages serves it with CRLF line endings and a final newline. Removing only those transport line-ending differences matches the committed editor buffer.

`secure-client.mjs` is byte-identical to the client served by the school backend. `secure-backend/` contains the readable server source, Firebase rules, dependency lock and emulator tests. `school-public-config.json` is the public Firebase web configuration, not a service-account credential.

`deployment/` contains the complete school backend upload folder, including the exact compiled `_worker.js`, client, fonts, styles and scripts. `school-backend-deployed.zip` is the exact backend ZIP deployed after its encrypted secret was set. `build-school.mjs` rebuilds that folder. Its output was compared byte-for-byte with the deployed worker.

`verification/` contains test logs, dependency audit captures, and selected screenshots. It contains only verification fixtures and the labeled deployment test, not real teacher records.

No live passwords, private keys, production database exports or bootstrap account-creation scripts are included. Local-only fixture passwords appear in emulator tests and must never be used for school accounts.

## Sign-in and teacher accounts

The school administrator username is `admin`. Its password is supplied separately through secure storage and is not recoverable from these files.

Teachers select their name and enter their individual password. Add teachers in System Settings, below School Branding. An existing teacher's password field is write-only; enter a new password and press Save password to change it. Disabling a teacher keeps their historical requests.

The deployment-verification teacher has been disabled. Its labeled test request remains in history. Its one-unit stock deduction was compensated by a separate +1 audit entry, preserving the original approval record.

## Reproduce the tests

Requirements: Node 22 or later, Java 21 or later, and Chrome. The UI test defaults to `/usr/bin/google-chrome`; adjust the path for another installation.

```sh
cd secure-backend
npm ci
npm test
npm run test:emulator
npm run test:ui
```

All test writes target local `demo-regent-lab` emulators. The UI suite reads the packaged production `index.html`, replaces only its endpoints and asset delivery for local testing, bundles the same client, and blocks all external browser traffic. Never point the test suite at a school project.

Fresh checkpoint results: 41 unit/security/crypto/restore tests passed, 12 Firestore/Auth integration tests passed, and the actual Chrome UI suite passed. The UI suite includes teacher creation and password reset, old-password rejection, fresh teacher login and booking, admin approval with live teacher updates, inventory changes, loans and returns, loss handling, recurring schedules, backup export, repeated restore, stale-write rejection, QR settings and print-stage rendering. Expected guard rejections appear in its log as 409 responses.

Separately, live school checks passed for fresh administrator login at the exact original URL, teacher dropdown/password login, request submission, separate-session admin approval, live teacher approval status, the generated QR destination, and verification-account disable/stock compensation.

This is not a claim that every feature, physical printer, browser or device has been tested. Production restore was not exercised against the school database. Restore was exercised in isolated emulators, including repeat restores, already-open sessions, later saves, tampered/incomplete backups and preservation of accounts/audit history.

## Build and host

After `npm ci` in `secure-backend/`, run from this package's root:

```sh
node build-school.mjs
```

The worker is guarded to Firebase project `regent-lab` and frontend origin `https://aali-alt.github.io`. It requires `FIREBASE_SERVICE_ACCOUNT` as an encrypted host secret containing the intended school service-account JSON. Never commit that value or put it into browser code. Do not substitute the pilot project or pilot accounts.

See `OPERATIONS.md` for backups, limits, cache behavior and rollback. `MANIFEST.sha256` records the packaged file hashes.
