# Regent visual identity

Reference supplied by the application owner: https://ris-newmansoura.com/

Official logo observed on that site:
https://ris-newmansoura.com/wp-content/uploads/2025/12/Regent-International-School-Riyadh-Logo-02-1-1024x311.png

The site's displayed logo says New Mansoura. The source filename contains a different place name, so the displayed mark, not that filename, was used as the identity evidence. regent-crest.png is the crest-only crop of the original transparent logo, with its proportions preserved. The original is retained alongside it.

Site fonts observed: Inter and DM Sans. Local copies are used, with their licenses included. The red accent was taken from the site's rendered styles (#EC1C25). Existing application layout and navy navigation structure are preserved.

The Noto Emoji fallback font makes the existing interface symbols display without relying on device-installed emoji fonts. Its license is in FONT-LICENSE.txt.
