# Operations and recovery

## Current deployment

The frontend is published on the original GitHub Pages path. The backend runs in the separate `regent-lab-backend` Cloudflare Pages project and uses Firebase project `regent-lab`. The build does not configure billing, upgrades or provider-managed backups. Review the hosting and database plans before increasing capacity.

The legacy application document was retained unchanged. The secure app uses separate `regent_v2_` collections. Protected authentication accounts are not stored in ordinary application exports.

## Cache behavior

GitHub Pages serves the HTML with a ten-minute cache lifetime. A browser that opened the old page immediately before rollout may briefly retain it. Refresh the page; a cache-busting release query also works. Both a fresh password login on the exact bare original URL and the generated teacher QR URL were verified after rollout.

## Backup and restore

Use Official Reports & Exports to save an application JSON backup before important changes. This is a manual export, not a scheduled or provider-managed database backup. No ongoing monitoring or automatic-backup service is configured by these files.

The JSON contains the application datasets, not administrator or teacher passwords. Restore preserves protected accounts and existing audit history, validates the backup structure, rejects stale or incomplete inputs, and records its operation. It is a replacement of application datasets, so review the backup and take a fresh export first. Repeated restores, live-session refresh and a subsequent save were tested locally. Do not test destructive restoration on the live school merely to repeat those checks.

## Limits and capacity

The code accepts up to 100 distinct requisition items and 150 changes in an ordinary admin patch. Ordinary bodies are limited to 512 KiB; complete restore bodies are limited to 4 MiB. These are validation limits, not a guarantee that every body of that size will complete within the hosting platform's CPU or usage limits.

The app listens to permitted collections in real time. Large histories and many open sessions consume more reads and requests. Review the vendors' current quotas before expanding use or retaining a large history. This checkpoint is not an unlimited-capacity or outage-free promise.

Login attempts are rate limited. The public directory deliberately exposes only teacher display names and opaque selectors, preserving name-dropdown login. Password checks and private login-address lookups happen on the backend. Disabled teachers cannot sign in and are removed from the active public selector list.

## Rollback

This package preserves a matched frontend, backend, client, rules and dependency lock. Use the complete matched checkpoint to recover from a later code regression. The pre-cutover frontend remains in Git history, but it is not a safe shortcut for restoring client-side passwords or legacy open database access.

Before changing the live backend or rules, save an application export and record the existing revision. Do not overwrite another person's concurrent changes, delete protected accounts or assume a code rollback should also roll back their data.

## Dependency audit capture

The included audit captures report zero production advisories and zero high/critical advisories overall. Fourteen moderate advisories remain in development-only Firebase CLI dependencies. This describes the captured audit, not a guarantee about future advisories.

## Security administration

Service-account credentials belong only in the host's encrypted secret store. Rotate or revoke a key only after identifying its exact ID and confirming it is not the active deployment credential. This source package contains no service-account JSON and performs no key deletion or API enablement automatically.
