import {restPlatform} from './rest-platform.mjs';
import {FirestoreRepository} from './firebase-repository.mjs';
import {createHandler} from './http-handler.mjs';
import config from '../school-public-config.json';
const PROJECT='regent-lab',ORIGIN='https://aali-alt.github.io';
let cached;
export default {async fetch(request,env){
 const path=new URL(request.url).pathname;
 if(path==='/health')return new Response(JSON.stringify({ready:!!env.FIREBASE_SERVICE_ACCOUNT,project:PROJECT}),{headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
 if(path.startsWith('/assets/')||path.startsWith('/client/')||['/tailwind.js','/qrcode.js'].includes(path)){const asset=await env.ASSETS.fetch(request),headers=new Headers(asset.headers);headers.set('Access-Control-Allow-Origin',ORIGIN);headers.set('X-Content-Type-Options','nosniff');return new Response(asset.body,{status:asset.status,headers});}
 try{
  if(!cached){
   const credential=JSON.parse(env.FIREBASE_SERVICE_ACCOUNT||'null');
   if(credential?.project_id!==PROJECT||!credential.client_email?.endsWith('@'+PROJECT+'.iam.gserviceaccount.com')||config.projectId!==PROJECT)throw Error('School target refused');
   const platform=restPlatform({projectId:PROJECT,apiKey:config.apiKey,serviceAccount:credential});
   cached=createHandler({repo:new FirestoreRepository(platform.db),auth:platform.auth,allowedOrigin:ORIGIN});
  }
  let status=200,body='';const headers={};
  const response={setHeader:(key,value)=>{headers[key]=value;},set statusCode(value){status=value;},get statusCode(){return status;},end:value=>{body=value||'';}};
  if(Number(request.headers.get('content-length')||0)>(path==='/admin/restore'?4*1024*1024:512*1024))return new Response(JSON.stringify({error:{code:'TOO_LARGE'}}),{status:413,headers:{'Content-Type':'application/json'}});
  const adapted={method:request.method,url:request.url,headers:Object.fromEntries(request.headers),async *[Symbol.asyncIterator](){if(!request.body)return;const reader=request.body.getReader();try{while(true){const {done,value}=await reader.read();if(done)break;yield value;}}finally{reader.releaseLock();}}};
  await cached(adapted,response);return new Response(status===204?null:body,{status,headers});
 }catch{return new Response(JSON.stringify({error:{code:'BACKEND_UNAVAILABLE',message:'The school service is not ready. Please try again shortly.'}}),{status:503,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});}
}};
