// node_modules/@noble/hashes/_u64.js
var fromNumH = (n) => n / 2 ** 32 | 0;
var fromNumL = (n) => n >>> 0;
function setU64FromNum(view, byteOffset, n, isLE) {
  const h = fromNumH(n);
  const l = fromNumL(n);
  view.setUint32(byteOffset, isLE ? l : h, isLE);
  view.setUint32(byteOffset + 4, isLE ? h : l, isLE);
}

// node_modules/@noble/hashes/utils.js
function isBytes(a) {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in a && a.BYTES_PER_ELEMENT === 1;
}
var atitle = (title) => title ? `"${title}" ` : "";
function anumber(n, title = "") {
  if (typeof n !== "number")
    throw new TypeError(atitle(title) + "expected number, got " + typeof n);
  if (!Number.isSafeInteger(n) || n < 0)
    throw new RangeError(atitle(title) + "expected integer >= 0, got " + n);
  return n;
}
function abytes(value, length, title = "") {
  if (isBytes(value) && (length === void 0 || value.length === length))
    return value;
  if (length !== void 0)
    anumber(length, "length");
  const bytes = isBytes(value);
  const ofLen = length !== void 0 ? ` of length ${length}` : "";
  const got = bytes ? `length=${value.length}` : `type=${typeof value}`;
  const message = atitle(title) + "expected Uint8Array" + ofLen + ", got " + got;
  if (!bytes)
    throw new TypeError(message);
  throw new RangeError(message);
}
var aobject = (value, label) => {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    throw new TypeError((label === "object" ? "" : `"${label}" `) + "expected object, got type=" + typeof value);
};
var aopts = (value, label) => {
  aobject(value, label);
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null)
    throw new TypeError(`"${label}" expected plain object`);
  if (Object.hasOwn(value, "__proto__"))
    throw new TypeError(`"${label}.__proto__" is not allowed`);
};
function aexists(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("hash was destroyed");
  if (checkFinished && instance.finished)
    throw new Error("digest() was already called");
}
function aoutput(out, instance) {
  abytes(out, void 0, "output");
  const min = instance.outputLen;
  if (!(out.length >= min)) {
    throw new RangeError('"output" expected length >= ' + min);
  }
}
function clean(...arrays) {
  for (let i = 0; i < arrays.length; i++) {
    arrays[i].fill(0);
  }
}
function createView(arr) {
  return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
function rotr(word, shift) {
  return word << 32 - shift | word >>> shift;
}
var hasHexBuiltin = /* @__PURE__ */ (() => (
  // @ts-ignore
  typeof Uint8Array.from([]).toHex === "function" && typeof Uint8Array.fromHex === "function"
))();
var hexes = /* @__PURE__ */ Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, "0"));
function bytesToHex(bytes) {
  abytes(bytes);
  if (hasHexBuiltin)
    return bytes.toHex();
  let hex = "";
  for (let i = 0; i < bytes.length; i++) {
    hex += hexes[bytes[i]];
  }
  return hex;
}
function checkOpts(defaults, opts, title = "opts") {
  aopts(defaults, "defaults");
  if (opts !== void 0)
    aopts(opts, title);
  const merged = Object.assign(/* @__PURE__ */ Object.create(null), defaults, opts);
  return merged;
}
function createHasher(hashCons, info = {}) {
  if (typeof hashCons !== "function")
    throw new TypeError('"hashCons" expected function, got type=' + typeof hashCons);
  info = checkOpts({}, info, "info");
  const hashC = (msg, opts) => hashCons(opts).update(msg).digest();
  const tmp = hashCons(void 0);
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.canXOF = tmp.canXOF;
  hashC.create = (opts) => hashCons(opts);
  Object.assign(hashC, info);
  return Object.freeze(hashC);
}
var oidNist = (suffix) => ({
  // Current NIST hashAlgs suffixes used here fit in one DER subidentifier octet.
  // Larger suffix values would need base-128 OID encoding and a different length byte.
  oid: Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2, suffix])
});

// node_modules/@noble/hashes/_md.js
function Chi(a, b, c) {
  return a & b ^ ~a & c;
}
function Maj(a, b, c) {
  return a & b ^ a & c ^ b & c;
}
var HashMD = class {
  blockLen;
  outputLen;
  canXOF = false;
  padOffset;
  isLE;
  // For partial updates less than block size
  buffer;
  view;
  finished = false;
  length = 0;
  pos = 0;
  destroyed = false;
  constructor(blockLen, outputLen, padOffset, isLE) {
    this.blockLen = blockLen;
    this.outputLen = outputLen;
    this.padOffset = padOffset;
    this.isLE = isLE;
    this.buffer = new Uint8Array(blockLen);
    this.view = createView(this.buffer);
  }
  update(data) {
    aexists(this);
    abytes(data);
    const { view, buffer, blockLen } = this;
    const len = data.length;
    let processed = false;
    for (let pos = 0; pos < len; ) {
      const take = Math.min(blockLen - this.pos, len - pos);
      if (take === blockLen) {
        const dataView = createView(data);
        for (; blockLen <= len - pos; pos += blockLen)
          this.process(dataView, pos);
        processed = true;
        continue;
      }
      buffer.set(pos === 0 && take === len ? data : data.subarray(pos, pos + take), this.pos);
      this.pos += take;
      pos += take;
      if (this.pos === blockLen) {
        this.process(view, 0);
        this.pos = 0;
        processed = true;
      }
    }
    this.length += data.length;
    if (processed)
      this.roundClean();
    return this;
  }
  digestInto(out) {
    aexists(this);
    aoutput(out, this);
    this.finished = true;
    const { buffer, view, blockLen, isLE } = this;
    let { pos } = this;
    buffer[pos++] = 128;
    buffer.fill(0, pos);
    if (this.padOffset > blockLen - pos) {
      this.process(view, 0);
      buffer.fill(0);
    }
    setU64FromNum(view, blockLen - 8, this.length * 8, isLE);
    this.process(view, 0);
    this.roundClean();
    const oview = out === buffer ? view : createView(out);
    const len = this.outputLen;
    const outLen = len / 4;
    const state = this.get();
    if (len % 4 || outLen > state.length)
      throw new Error("invalid outputLen");
    for (let i = 0; i < outLen; i++)
      oview.setUint32(4 * i, state[i], isLE);
  }
  digest() {
    const { buffer, outputLen } = this;
    this.digestInto(buffer);
    const res = buffer.slice(0, outputLen);
    this.destroy();
    return res;
  }
  _cloneIntoMeta(to) {
    const { buffer, length, finished, destroyed, pos } = this;
    to.destroyed = destroyed;
    to.finished = finished;
    to.length = length;
    to.pos = pos;
    if (pos)
      to.buffer.set(buffer);
    return to;
  }
  clone() {
    return this._cloneInto();
  }
};
var SHA256_IV = /* @__PURE__ */ Uint32Array.from([
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
]);

// node_modules/@noble/hashes/sha2.js
var SHA256_K = /* @__PURE__ */ Uint32Array.from([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var SHA256_W = /* @__PURE__ */ new Uint32Array(64);
var SHA2_32B = class extends HashMD {
  // We cannot use array here since array allows indexing by variable
  // which means optimizer/compiler cannot use registers.
  // Numeric initializers matter: starting the fields as `undefined` changes
  // V8's field representation and makes sha256 3x slower (measured).
  A = 0;
  B = 0;
  C = 0;
  D = 0;
  E = 0;
  F = 0;
  G = 0;
  H = 0;
  constructor(outputLen, IV) {
    super(64, outputLen, 8, false);
    this.A = IV[0] | 0;
    this.B = IV[1] | 0;
    this.C = IV[2] | 0;
    this.D = IV[3] | 0;
    this.E = IV[4] | 0;
    this.F = IV[5] | 0;
    this.G = IV[6] | 0;
    this.H = IV[7] | 0;
  }
  get() {
    const { A, B, C, D, E, F, G, H } = this;
    return [A, B, C, D, E, F, G, H];
  }
  // prettier-ignore
  set(A, B, C, D, E, F, G, H) {
    this.A = A | 0;
    this.B = B | 0;
    this.C = C | 0;
    this.D = D | 0;
    this.E = E | 0;
    this.F = F | 0;
    this.G = G | 0;
    this.H = H | 0;
  }
  _cloneInto(to) {
    (to ||= new this.constructor()).set(...this.get());
    return this._cloneIntoMeta(to);
  }
  process(view, offset) {
    for (let i = 0; i < 16; i++, offset += 4)
      SHA256_W[i] = view.getUint32(offset, false);
    for (let i = 16; i < 64; i++) {
      const W15 = SHA256_W[i - 15];
      const W2 = SHA256_W[i - 2];
      const s0 = rotr(W15, 7) ^ rotr(W15, 18) ^ W15 >>> 3;
      const s1 = rotr(W2, 17) ^ rotr(W2, 19) ^ W2 >>> 10;
      SHA256_W[i] = s1 + SHA256_W[i - 7] + s0 + SHA256_W[i - 16] | 0;
    }
    let { A, B, C, D, E, F, G, H } = this;
    for (let i = 0; i < 64; i++) {
      const sigma1 = rotr(E, 6) ^ rotr(E, 11) ^ rotr(E, 25);
      const T1 = H + sigma1 + Chi(E, F, G) + SHA256_K[i] + SHA256_W[i] | 0;
      const sigma0 = rotr(A, 2) ^ rotr(A, 13) ^ rotr(A, 22);
      const T2 = sigma0 + Maj(A, B, C) | 0;
      H = G;
      G = F;
      F = E;
      E = D + T1 | 0;
      D = C;
      C = B;
      B = A;
      A = T1 + T2 | 0;
    }
    A = A + this.A | 0;
    B = B + this.B | 0;
    C = C + this.C | 0;
    D = D + this.D | 0;
    E = E + this.E | 0;
    F = F + this.F | 0;
    G = G + this.G | 0;
    H = H + this.H | 0;
    this.set(A, B, C, D, E, F, G, H);
  }
  roundClean() {
    clean(SHA256_W);
  }
  destroy() {
    this.destroyed = true;
    this.set(0, 0, 0, 0, 0, 0, 0, 0);
    clean(this.buffer);
  }
};
var _SHA256 = class extends SHA2_32B {
  constructor() {
    super(32, SHA256_IV);
  }
};
var sha256 = /* @__PURE__ */ createHasher(
  () => new _SHA256(),
  /* @__PURE__ */ oidNist(1)
);

// portable-crypto.mjs
var encoder = new TextEncoder();
var sha256Hex = (value) => bytesToHex(sha256(typeof value === "string" ? encoder.encode(value) : value));
var randomUUID = () => globalThis.crypto.randomUUID();
function base64Url(value) {
  const bytes = typeof value === "string" ? encoder.encode(value) : new Uint8Array(value);
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}
function decodeBase64UrlText(value) {
  const base64 = value.replace(/-/g, "+").replace(/_/g, "/");
  return new TextDecoder("utf-8", { fatal: true }).decode(Uint8Array.from(atob(base64.padEnd(Math.ceil(base64.length / 4) * 4, "=")), (c) => c.charCodeAt(0)));
}
async function signRs256(unsigned, pem) {
  if (typeof pem !== "string" || !pem.startsWith("-----BEGIN PRIVATE KEY-----")) throw new Error("A PKCS8 service credential is required");
  const binary = atob(pem.replace(/-----BEGIN PRIVATE KEY-----|-----END PRIVATE KEY-----|\s/g, ""));
  const key = await globalThis.crypto.subtle.importKey("pkcs8", Uint8Array.from(binary, (c) => c.charCodeAt(0)), { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
  return base64Url(await globalThis.crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, encoder.encode(unsigned)));
}

// domain.mjs
var AppError = class extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
};
var fail = (status, code, message) => {
  throw new AppError(status, code, message);
};
var clone = (value) => structuredClone(value);
var entityKinds = /* @__PURE__ */ new Set(["inventory", "cabinets", "requests", "scheduleSlots", "loans", "lossRecords", "logs"]);
var forbiddenSettings = /password|credential|firebase|private.?key|auth.?token|secret/i;
function cleanSettings(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) fail(400, "INVALID_SETTINGS", "Settings must be an object");
  const scan = (obj) => {
    if (Array.isArray(obj)) return obj.map(scan);
    if (obj && typeof obj === "object") return Object.fromEntries(Object.entries(obj).filter(([key]) => !forbiddenSettings.test(key) && !["__proto__", "constructor", "prototype"].includes(key)).map(([key, val]) => [key, scan(val)]));
    return obj;
  };
  return scan(value);
}
function id(value) {
  if (typeof value !== "string" || value.startsWith("__") || !/^[a-zA-Z0-9_-]{1,120}$/.test(value)) fail(400, "INVALID_ID", "Invalid record identifier");
  return value;
}
function positive(value) {
  if (typeof value !== "number" || !Number.isFinite(value) || value <= 0 || value > 1e9) fail(400, "INVALID_QUANTITY", "Quantity must be positive");
  return value;
}
function text(value, max = 300) {
  if (typeof value !== "string" || value.trim().length === 0 || value.length > max) fail(400, "INVALID_TEXT", "A required text field is empty or too long");
  if (/[<>\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value)) fail(400, "INVALID_TEXT", "Markup and control characters are not allowed");
  return value.trim();
}
function dateOnly(value) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) fail(400, "INVALID_DATE", "Use a calendar date");
  const parsed = /* @__PURE__ */ new Date(value + "T12:00:00Z");
  if (Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== value) fail(400, "INVALID_DATE", "Invalid calendar date");
  return value;
}
function assertActor(actor, role) {
  if (!actor?.uid || actor.disabled) fail(401, "UNAUTHENTICATED", "Sign in again");
  if (role && actor.role !== role) fail(403, "FORBIDDEN", "This action is for the lab administrator");
}
function canonical(value) {
  if (Array.isArray(value)) return "[" + value.map(canonical).join(",") + "]";
  if (value && typeof value === "object") return "{" + Object.keys(value).sort().map((k) => JSON.stringify(k) + ":" + canonical(value[k])).join(",") + "}";
  return JSON.stringify(value);
}
var digest = (value) => sha256Hex(canonical(value));
function normalizeBatches(value) {
  if (value === void 0 || value === null) return void 0;
  if (!Array.isArray(value)) fail(400, "INVALID_BATCHES", "Stock batches must be a list");
  if (value.length > 100) fail(400, "INVALID_BATCHES", "Too many stock batches");
  const seen = /* @__PURE__ */ new Set();
  return value.map((entry) => {
    if (!entry || typeof entry !== "object" || Array.isArray(entry)) fail(400, "INVALID_BATCHES", "A stock batch is invalid");
    const batchId = entry.id ? id(entry.id) : "batch_" + randomUUID();
    if (seen.has(batchId)) fail(400, "INVALID_BATCHES", "A stock batch identifier is repeated");
    seen.add(batchId);
    return { id: batchId, qty: positive(entry.qty), expiry: entry.expiry ? dateOnly(entry.expiry) : "" };
  });
}
var batchTotal = (batches) => batches.reduce((sum, batch) => sum + Number(batch.qty), 0);
var NO_EXPIRY = "9999-12-31";
var UNALLOCATED_BATCH = "batch_unallocated";
function deductItemStock(item, qty) {
  if (qty > Number(item.qty)) fail(409, "INSUFFICIENT_STOCK", "Not enough stock");
  const allocations = [];
  if (Array.isArray(item.batches) && item.batches.length) {
    const ordered = [...item.batches].sort((a, b) => (a.expiry || NO_EXPIRY).localeCompare(b.expiry || NO_EXPIRY));
    let remaining = qty;
    for (const batch of ordered) {
      const take = Math.min(Number(batch.qty), remaining);
      batch.qty = Number(batch.qty) - take;
      remaining -= take;
      if (take > 0) allocations.push({ batchId: batch.id, qty: take, expiry: batch.expiry || "" });
    }
    item.batches = ordered.filter((batch) => batch.qty > 0);
    item.qty = batchTotal(item.batches);
  } else item.qty = Number(item.qty) - qty;
  return allocations;
}
function restockFromAllocations(item, allocations) {
  if (Array.isArray(item.batches)) {
    for (const allocation of allocations || []) {
      let batch = item.batches.find((b) => b.id === allocation.batchId);
      if (!batch) {
        batch = { id: allocation.batchId, qty: 0, expiry: allocation.expiry || "" };
        item.batches.push(batch);
      }
      batch.qty = Number(batch.qty) + Number(allocation.qty);
    }
    item.qty = batchTotal(item.batches);
  } else item.qty = Number(item.qty) + (allocations || []).reduce((sum, a) => sum + Number(a.qty), 0);
}
function restockUnallocated(item, qty) {
  if (Array.isArray(item.batches)) {
    let batch = item.batches.find((b) => b.id === UNALLOCATED_BATCH);
    if (!batch) {
      batch = { id: UNALLOCATED_BATCH, qty: 0, expiry: "" };
      item.batches.push(batch);
    }
    batch.qty = Number(batch.qty) + qty;
    item.qty = batchTotal(item.batches);
  } else item.qty = Number(item.qty) + qty;
}
async function createRequisition(repo, actor, input, commandId) {
  assertActor(actor);
  const cmd = id(commandId);
  const payloadHash = digest(input);
  return repo.transaction(async (tx) => {
    const prior = await tx.get("commands", actor.uid + "_" + cmd);
    if (prior) {
      if (prior.hash !== payloadHash) fail(409, "IDEMPOTENCY_CONFLICT", "Retry has different content");
      return prior.result;
    }
    const settings = await tx.get("settings", "main") || {};
    const reqId = id(input.id || "req_" + randomUUID());
    if (await tx.get("requests", reqId)) fail(409, "ALREADY_EXISTS", "Request identifier already exists");
    const usageMode = input.usageMode;
    if (!["in-lab", "outside-lab"].includes(usageMode)) fail(400, "INVALID_MODE", "Choose lab use or classroom loan");
    const date = dateOnly(input.date), period = text(input.period), lab = usageMode === "in-lab" ? text(input.lab) : "Classroom Loan";
    if (!(settings.periods || []).includes(period)) fail(400, "INVALID_PERIOD", "Period is not configured");
    if (usageMode === "in-lab" && !(settings.labs || []).includes(lab)) fail(400, "INVALID_LAB", "Laboratory is not configured");
    const weekday = (/* @__PURE__ */ new Date(date + "T12:00:00Z")).getUTCDay();
    if (Array.isArray(settings.allowedWeekdays) && !settings.allowedWeekdays.includes(weekday)) fail(409, "CLOSED_DAY", "This school day is not bookable");
    const experiment = text(input.experiment, 500), grade = text(input.grade), subject = text(input.subject);
    if (!Array.isArray(input.items) || input.items.length === 0 || input.items.length > 100) fail(400, "EMPTY_REQUEST", "Choose one or more items");
    await tx.preload(input.items.map((entry) => ["inventory", id(entry.itemId)]));
    const seen = /* @__PURE__ */ new Set(), items = [];
    for (const entry of input.items) {
      const itemId = id(entry.itemId);
      if (seen.has(itemId)) fail(400, "DUPLICATE_ITEM", "Combine repeated items");
      seen.add(itemId);
      const item = await tx.get("inventory", itemId);
      if (!item) fail(409, "MISSING_ITEM", "An item is no longer available");
      const qty = positive(entry.qty);
      if (qty > Number(item.qty)) fail(409, "INSUFFICIENT_STOCK", "Not enough stock for this request");
      items.push({ itemId, qty, nameEn: item.nameEn || "", unit: item.unit || "" });
    }
    const returnDate = usageMode === "outside-lab" ? dateOnly(input.returnDate || date) : "";
    if (returnDate && returnDate < date) fail(400, "INVALID_RETURN", "Return cannot precede issue date");
    const row = {
      id: reqId,
      teacherUid: actor.uid,
      teacherName: actor.name,
      subject,
      grade,
      experiment,
      usageMode,
      date,
      period,
      lab,
      groups: Number.isInteger(input.groups) && input.groups > 0 ? Math.min(input.groups, 100) : 1,
      returnDate,
      returnPeriod: usageMode === "outside-lab" ? text(input.returnPeriod || period) : "",
      items,
      notes: input.notes ? text(input.notes, 2e3) : "",
      status: "pending",
      submittedAt: repo.now(),
      version: 1
    };
    if (usageMode === "in-lab") {
      const conflict = await tx.findActiveBooking({ date, period, lab });
      if (conflict) fail(409, "BOOKING_CONFLICT", "This laboratory period is already booked");
      tx.set("bookings", digest({ date, period, lab }), { date, period, lab, requestId: reqId, status: "pending" });
    }
    tx.set("requests", reqId, row);
    const result = { request: row };
    tx.set("commands", actor.uid + "_" + cmd, { hash: payloadHash, result, createdAt: repo.now() });
    return result;
  });
}
async function decideRequisition(repo, actor, { requestId, decision }, commandId) {
  assertActor(actor, "admin");
  id(requestId);
  id(commandId);
  if (!["approved", "rejected"].includes(decision)) fail(400, "INVALID_DECISION", "Unknown decision");
  const payloadHash = digest({ requestId, decision });
  return repo.transaction(async (tx) => {
    const cmd = actor.uid + "_" + commandId, prior = await tx.get("commands", cmd);
    if (prior) {
      if (prior.hash !== payloadHash) fail(409, "IDEMPOTENCY_CONFLICT", "Retry has different content");
      return prior.result;
    }
    const req = await tx.get("requests", requestId);
    if (!req) fail(404, "NOT_FOUND", "Request not found");
    if (req.status === decision) return { request: req, alreadyApplied: true };
    if (req.status !== "pending") fail(409, "ALREADY_DECIDED", "Request already processed");
    const inventory = [], loans = [], batchAllocations = [];
    if (decision === "approved") {
      await tx.preload(req.items.map((entry) => ["inventory", id(entry.itemId)]));
      for (const entry of req.items) {
        const item = await tx.get("inventory", entry.itemId);
        if (!item) fail(409, "MISSING_ITEM", "Item no longer exists");
        const qty = positive(entry.qty);
        if (Number(item.qty) < qty) fail(409, "INSUFFICIENT_STOCK", "Stock changed; approval was not saved");
        const next = { ...item };
        const allocations = deductItemStock(next, qty);
        next.version = (item.version || 0) + 1;
        next.updatedAt = repo.now();
        inventory.push(next);
        if (allocations.length) batchAllocations.push(...allocations.map((a) => ({ itemId: item.id, ...a })));
        if (req.usageMode === "outside-lab") loans.push({
          id: "loan_" + randomUUID(),
          requestId,
          teacherUid: req.teacherUid,
          teacherName: req.teacherName,
          itemId: item.id,
          itemName: item.nameEn,
          qty,
          unit: item.unit || "",
          classRoom: req.grade,
          dueDate: req.returnDate,
          duePeriod: req.returnPeriod,
          status: "active",
          issuedAt: repo.now(),
          version: 1,
          ...allocations.length ? { batchAllocations: allocations } : {}
        });
      }
    }
    const updated = { ...req, status: decision, version: (req.version || 0) + 1, updatedAt: repo.now(), decidedBy: actor.uid };
    if (batchAllocations.length) updated.batchAllocations = batchAllocations;
    for (const item of inventory) tx.set("inventory", item.id, item);
    for (const loan of loans) tx.set("loans", loan.id, loan);
    tx.set("requests", requestId, updated);
    if (req.usageMode === "in-lab") {
      const key = digest({ date: req.date, period: req.period, lab: req.lab });
      if (decision === "rejected") tx.delete("bookings", key);
      else tx.set("bookings", key, { date: req.date, period: req.period, lab: req.lab, requestId, status: decision });
    }
    const audit = { id: "log_" + randomUUID(), item: req.experiment, delta: decision === "approved" ? "-" + req.items.reduce((sum, item) => sum + item.qty, 0) : "0", note: "Requisition " + decision + " for " + req.teacherName, time: repo.now(), type: "requisition_" + decision, requestId, actorUid: actor.uid, at: repo.now() };
    tx.set("logs", audit.id, audit);
    const result = { request: updated, inventory, loans };
    tx.set("commands", cmd, { hash: payloadHash, result, createdAt: repo.now() });
    return result;
  });
}
async function reverseRequisition(repo, actor, { requestId, reason }, commandId) {
  assertActor(actor, "admin");
  id(requestId);
  id(commandId);
  const note = text(reason, 500);
  const payloadHash = digest({ requestId, reason: note });
  return repo.transaction(async (tx) => {
    const cmd = actor.uid + "_" + commandId, prior = await tx.get("commands", cmd);
    if (prior) {
      if (prior.hash !== payloadHash) fail(409, "IDEMPOTENCY_CONFLICT", "Retry has different content");
      return prior.result;
    }
    const req = await tx.get("requests", requestId);
    if (!req) fail(404, "NOT_FOUND", "Request not found");
    if (req.reversed) return { request: req, alreadyApplied: true };
    if (req.status !== "approved") fail(409, "NOT_APPROVED", "Only an approved request can be reversed");
    const linkedLoans = (await tx.list("loans")).filter((loan) => loan.requestId === requestId);
    const restoredByItem = /* @__PURE__ */ new Map();
    for (const loan of linkedLoans.filter((loan2) => loan2.status === "returned")) restoredByItem.set(loan.itemId, (restoredByItem.get(loan.itemId) || 0) + Number(loan.qty));
    await tx.preload(req.items.map((entry) => ["inventory", id(entry.itemId)]));
    const inventory = [], loans = [];
    let restoredTotal = 0;
    for (const entry of req.items) {
      const restoreQty = Math.max(0, Number(entry.qty) - (restoredByItem.get(entry.itemId) || 0));
      if (restoreQty > 0) {
        const item = await tx.get("inventory", entry.itemId);
        if (!item) fail(409, "MISSING_ITEM", "Restore the item before reversing this request");
        const next = { ...item };
        const sourced = (req.batchAllocations || []).filter((a) => a.itemId === entry.itemId);
        if (sourced.length) {
          const recorded = sourced.reduce((sum, a) => sum + Number(a.qty), 0);
          const scale = recorded > 0 ? restoreQty / recorded : 0;
          restockFromAllocations(next, sourced.map((a) => ({ ...a, qty: a.qty * scale })));
        } else if (Array.isArray(next.batches) && next.batches.length) restockUnallocated(next, restoreQty);
        else next.qty = Number(next.qty) + restoreQty;
        next.version = (item.version || 0) + 1;
        next.updatedAt = repo.now();
        inventory.push(next);
        restoredTotal += restoreQty;
      }
    }
    for (const loan of linkedLoans.filter((loan2) => loan2.status === "active"))
      loans.push({ ...loan, status: "returned", reversed: true, returnedAt: repo.now(), returnedBy: actor.uid, version: (loan.version || 0) + 1 });
    const updated = { ...req, reversed: true, reversalReason: note, reversedAt: repo.now(), reversedBy: actor.uid, version: (req.version || 0) + 1, updatedAt: repo.now() };
    for (const item of inventory) tx.set("inventory", item.id, item);
    for (const loan of loans) tx.set("loans", loan.id, loan);
    tx.set("requests", requestId, updated);
    if (req.usageMode === "in-lab") tx.delete("bookings", digest({ date: req.date, period: req.period, lab: req.lab }));
    const audit = { id: "log_" + randomUUID(), item: req.experiment, delta: "+" + restoredTotal, note: "Approved requisition reversed for " + req.teacherName + ": " + note, time: repo.now(), type: "requisition_reversed", requestId, actorUid: actor.uid, at: repo.now() };
    tx.set("logs", audit.id, audit);
    const result = { request: updated, inventory, loans };
    tx.set("commands", cmd, { hash: payloadHash, result, createdAt: repo.now() });
    return result;
  });
}
var snapshotKinds = ["inventory", "cabinets", "requests", "scheduleSlots", "loans", "lossRecords", "logs"];
var SNAPSHOT_KEEP = 30;
async function createSnapshot(repo, actor, commandId) {
  assertActor(actor, "admin");
  id(commandId);
  return repo.transaction(async (tx) => {
    const data = {};
    for (const kind of snapshotKinds) data[kind] = (await tx.list(kind)).filter((row) => !row._meta).map((row) => {
      const clean2 = { ...row };
      delete clean2._revision;
      return clean2;
    });
    data.settings = { ...await tx.get("settings", "main") || {} };
    delete data.settings._revision;
    const snapshot = {
      id: "snap_" + randomUUID(),
      createdAt: repo.now(),
      createdBy: actor.uid,
      counts: Object.fromEntries(snapshotKinds.map((kind) => [kind, data[kind].length])),
      data
    };
    if (JSON.stringify(snapshot).length > 900 * 1024) fail(413, "SNAPSHOT_TOO_LARGE", "The dataset is too large for a server snapshot; use a JSON export instead");
    tx.set("snapshots", snapshot.id, snapshot);
    const existing = (await tx.list("snapshots")).filter((row) => row.id !== snapshot.id).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    for (const old of existing.slice(SNAPSHOT_KEEP - 1)) tx.delete("snapshots", old.id);
    return { snapshot: { id: snapshot.id, createdAt: snapshot.createdAt, counts: snapshot.counts } };
  });
}
async function runScheduledSnapshot(repo, scheduledTime) {
  const at = new Date(scheduledTime || Date.now());
  const stamp = at.toISOString().replace(/[-:T]/g, "").slice(0, 12);
  try {
    return await createSnapshot(repo, { uid: "system-scheduler", role: "admin" }, "cron_" + stamp);
  } catch (error2) {
    const code = error2 && error2.code || "UNKNOWN";
    try {
      await repo.transaction(async (tx) => {
        const entry = { id: "log_" + randomUUID(), item: "\u0627\u0644\u0646\u0633\u062E \u0627\u0644\u0627\u062D\u062A\u064A\u0627\u0637\u064A \u0627\u0644\u0645\u062C\u062F\u0648\u0644", delta: "", note: "\u0641\u0634\u0644 \u0625\u0646\u0634\u0627\u0621 \u0627\u0644\u0646\u0633\u062E\u0629 \u0627\u0644\u0627\u062D\u062A\u064A\u0627\u0637\u064A\u0629 \u0627\u0644\u0645\u062C\u062F\u0648\u0644\u0629: " + code, time: repo.now(), type: "snapshot_failed", actorUid: "system-scheduler", at: repo.now() };
        tx.set("logs", entry.id, entry);
      });
    } catch (logError) {
    }
    throw error2;
  }
}
async function listSnapshots(repo, actor) {
  assertActor(actor, "admin");
  return repo.transaction(async (tx) => ({ snapshots: (await tx.list("snapshots")).map((row) => ({ id: row.id, createdAt: row.createdAt, createdBy: row.createdBy, counts: row.counts })).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))) }));
}
async function loadSnapshot(repo, actor, snapshotId) {
  assertActor(actor, "admin");
  id(snapshotId);
  return repo.transaction(async (tx) => {
    const row = await tx.get("snapshots", snapshotId);
    if (!row) fail(404, "NOT_FOUND", "Snapshot not found");
    return row;
  });
}
async function applyAdminChanges(repo, actor, input, commandId) {
  assertActor(actor, "admin");
  id(commandId);
  if (!Array.isArray(input.changes) || input.changes.length === 0 || input.changes.length > 150) fail(400, "INVALID_PATCH", "Invalid changes");
  const hash = digest(input);
  return repo.transaction(async (tx) => {
    const cmd = actor.uid + "_" + commandId, prior = await tx.get("commands", cmd);
    if (prior) {
      if (prior.hash !== hash) fail(409, "IDEMPOTENCY_CONFLICT", "Retry has different content");
      return prior.result;
    }
    const writes = [], keys = /* @__PURE__ */ new Set();
    for (const change of input.changes) {
      if (!entityKinds.has(change.kind) && change.kind !== "settings") fail(400, "INVALID_KIND", "Unsupported record type");
      id(change.id);
    }
    await tx.preload(input.changes.map((change) => [change.kind, change.id]));
    for (const change of input.changes) {
      const kind = change.kind, key = id(change.id);
      if (!entityKinds.has(kind) && kind !== "settings") fail(400, "INVALID_KIND", "Unsupported record type");
      if (kind === "requests") fail(400, "USE_REQUEST_API", "Use request submission and approval actions");
      if (kind === "loans") fail(400, "USE_LOAN_API", "Use the issue and return loan actions");
      const fullKey = kind + "/" + key;
      if (keys.has(fullKey)) fail(400, "DUPLICATE_CHANGE", "Record changed twice");
      keys.add(fullKey);
      const current = await tx.get(kind, key);
      if (kind === "logs" && (current || change.delete)) fail(400, "AUDIT_READ_ONLY", "Existing audit entries cannot be edited");
      if ((current?.version || 0) !== change.expectedVersion) fail(409, "STALE_WRITE", "Another device changed this record. Refresh and retry.");
      if (change.delete) {
        writes.push({ kind, key, delete: true });
        continue;
      }
      const value = cleanSettings(change.value);
      if (value && typeof value === "object") {
        delete value._meta;
        delete value._revision;
      }
      if (!value || typeof value !== "object" || Array.isArray(value)) fail(400, "INVALID_RECORD", "Record must be an object");
      if (kind === "inventory") {
        const batches = normalizeBatches(value.batches);
        if (batches !== void 0) {
          if (batches.length) {
            value.batches = batches;
            value.qty = batchTotal(batches);
          } else delete value.batches;
        }
        if (!Number.isFinite(value.qty) || value.qty < 0) fail(409, "NEGATIVE_STOCK", "Inventory cannot be negative");
      }
      if (kind === "loans" && value.status === "active") positive(value.qty);
      if (value.id && value.id !== key) fail(400, "INVALID_ID", "Record ID does not match");
      writes.push({ kind, key, value: { ...value, ...kind === "settings" ? {} : { id: key }, version: (current?.version || 0) + 1, updatedAt: repo.now() } });
    }
    if (writes.some((w) => w.kind === "scheduleSlots")) {
      const lock = await tx.get("meta", "scheduleLock") || { version: 0 };
      const existing = await tx.list("scheduleSlots"), bookings = await tx.list("bookings");
      const map = new Map(existing.map((s) => [s.id, s]));
      for (const w of writes.filter((w2) => w2.kind === "scheduleSlots")) {
        if (w.delete) map.delete(w.key);
        else map.set(w.key, w.value);
      }
      const slots = [...map.values()];
      const overlaps = (a, b) => a.lab === b.lab && a.day === b.day && a.period === b.period && (a.recurrence === "weekly" || b.recurrence === "weekly" || a.weekDate === b.weekDate);
      for (const w of writes.filter((w2) => w2.kind === "scheduleSlots" && !w2.delete)) {
        const slot = w.value;
        text(slot.lab);
        text(slot.period);
        dateOnly(slot.weekDate);
        const day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][(/* @__PURE__ */ new Date(slot.weekDate + "T12:00:00Z")).getUTCDay()];
        if (slot.day !== day) fail(400, "INVALID_WEEKDAY", "Schedule weekday does not match its calendar date");
        if (!["weekly", "single"].includes(slot.recurrence)) fail(400, "INVALID_RECURRENCE", "Choose weekly or single");
        for (const other of slots) {
          if (other.id === slot.id || !overlaps(slot, other)) continue;
          const occurrence = slot.recurrence === "weekly" ? other.weekDate : slot.weekDate;
          if (slot.recurrence === "weekly" && other.recurrence === "weekly") fail(409, "BOOKING_CONFLICT", "Weekly laboratory periods overlap");
          if (!(slot.skippedDates || []).includes(occurrence) && !(other.skippedDates || []).includes(occurrence)) fail(409, "BOOKING_CONFLICT", "Laboratory period is already booked");
        }
        for (const booking of bookings) {
          const bookingDay = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][(/* @__PURE__ */ new Date(booking.date + "T12:00:00Z")).getUTCDay()];
          if (booking.lab === slot.lab && booking.period === slot.period && bookingDay === slot.day && !(slot.skippedDates || []).includes(booking.date) && (slot.recurrence === "weekly" || slot.weekDate === booking.date)) fail(409, "BOOKING_CONFLICT", "A requisition already holds this laboratory period");
        }
      }
      tx.set("meta", "scheduleLock", { version: lock.version + 1 });
    }
    for (const w of writes) {
      if (w.delete) tx.delete(w.kind, w.key);
      else tx.set(w.kind, w.key, w.value);
    }
    const result = { changes: writes };
    tx.set("commands", cmd, { hash, result, createdAt: repo.now() });
    return result;
  });
}
async function returnLoan(repo, actor, { loanId }, commandId) {
  assertActor(actor, "admin");
  id(loanId);
  id(commandId);
  return repo.transaction(async (tx) => {
    const loan = await tx.get("loans", loanId);
    if (!loan) fail(404, "NOT_FOUND", "Loan not found");
    if (loan.status === "returned") return { loan, alreadyApplied: true };
    if (loan.status !== "active") fail(409, "INVALID_LOAN_STATUS", "Loan cannot be returned");
    const item = await tx.get("inventory", loan.itemId);
    if (!item) fail(409, "MISSING_ITEM", "Restore the item before returning this loan");
    const qty = positive(loan.qty), updatedItem = { ...item };
    if (Array.isArray(loan.batchAllocations) && loan.batchAllocations.length) restockFromAllocations(updatedItem, loan.batchAllocations);
    else if (Array.isArray(updatedItem.batches) && updatedItem.batches.length) restockUnallocated(updatedItem, qty);
    else updatedItem.qty = Number(updatedItem.qty) + qty;
    updatedItem.version = (item.version || 0) + 1;
    updatedItem.updatedAt = repo.now();
    if (!Number.isFinite(updatedItem.qty)) fail(409, "INVALID_STOCK", "Inventory quantity needs correction");
    const updatedLoan = { ...loan, status: "returned", version: (loan.version || 0) + 1, returnedAt: repo.now(), returnedBy: actor.uid };
    tx.set("inventory", item.id, updatedItem);
    tx.set("loans", loanId, updatedLoan);
    const logId = "log_" + randomUUID();
    tx.set("logs", logId, { id: logId, item: item.nameEn, delta: "+" + qty, note: "Returned by " + loan.teacherName, time: repo.now(), type: "loan_returned", loanId, itemId: item.id, qty, at: repo.now(), actorUid: actor.uid });
    return { loan: updatedLoan, item: updatedItem };
  });
}
async function issueManualLoan(repo, actor, input, commandId) {
  assertActor(actor, "admin");
  id(commandId);
  const hash = digest(input);
  return repo.transaction(async (tx) => {
    const cmd = actor.uid + "_" + commandId, prior = await tx.get("commands", cmd);
    if (prior) {
      if (prior.hash !== hash) fail(409, "IDEMPOTENCY_CONFLICT", "Retry has different content");
      return prior.result;
    }
    const itemId = id(input.itemId), item = await tx.get("inventory", itemId);
    if (!item) fail(404, "NOT_FOUND", "Item not found");
    const qty = positive(input.qty);
    if (qty > Number(item.qty)) fail(409, "INSUFFICIENT_STOCK", "Not enough stock");
    const loanId = "loan_" + randomUUID(), loan = {
      id: loanId,
      itemId,
      itemName: item.nameEn,
      unit: item.unit || "",
      qty,
      teacherName: text(input.teacherName),
      classRoom: text(input.classRoom),
      dueDate: dateOnly(input.dueDate),
      duePeriod: text(input.duePeriod || "End of Day"),
      status: "active",
      version: 1,
      issuedAt: repo.now(),
      issuedBy: actor.uid
    };
    const updated = { ...item };
    const allocations = deductItemStock(updated, qty);
    updated.version = (item.version || 0) + 1;
    updated.updatedAt = repo.now();
    if (allocations.length) loan.batchAllocations = allocations;
    tx.set("inventory", itemId, updated);
    tx.set("loans", loanId, loan);
    const logId = "log_" + randomUUID();
    tx.set("logs", logId, { id: logId, item: item.nameEn, delta: "-" + qty, note: "Manual loan to " + loan.teacherName, time: repo.now(), type: "loan_issued", loanId, itemId, qty, at: repo.now(), actorUid: actor.uid });
    const result = { loan, item: updated };
    tx.set("commands", cmd, { hash, result, createdAt: repo.now() });
    return result;
  });
}
async function recordLoss(repo, actor, input, commandId) {
  assertActor(actor, "admin");
  id(commandId);
  const hash = digest(input);
  return repo.transaction(async (tx) => {
    const cmd = actor.uid + "_" + commandId, prior = await tx.get("commands", cmd);
    if (prior) {
      if (prior.hash !== hash) fail(409, "IDEMPOTENCY_CONFLICT", "Retry has different content");
      return prior.result;
    }
    const itemId = id(input.itemId), item = await tx.get("inventory", itemId);
    if (!item) fail(404, "NOT_FOUND", "Item not found");
    const qty = positive(input.qty), reason = text(input.reason), person = input.person ? text(input.person) : actor.name, notes = input.notes ? text(input.notes, 2e3) : "";
    let loan = null, returnedGood = 0;
    if (input.linkedLoanId) {
      loan = await tx.get("loans", id(input.linkedLoanId));
      if (!loan || loan.itemId !== itemId || loan.status !== "active") fail(409, "INVALID_LOAN", "Active matching loan not found");
      if (qty > Number(loan.qty)) fail(409, "INVALID_LOSS", "Loss exceeds the amount loaned");
      returnedGood = Number(loan.qty) - qty;
    } else if (qty > Number(item.qty)) fail(409, "INSUFFICIENT_STOCK", "Loss exceeds current stock");
    const lossId = "loss_" + randomUUID(), loss = { id: lossId, itemId, itemCode: item.code || "", itemName: item.nameEn, qty, unit: item.unit || "", reason, person, notes, date: input.date ? dateOnly(input.date) : repo.now().slice(0, 10), time: repo.now(), updatedAt: repo.now(), version: 1, ...loan ? { linkedLoanId: loan.id } : {} };
    const updatedItem = { ...item };
    if (loan) {
      if (Array.isArray(loan.batchAllocations) && loan.batchAllocations.length) {
        let lostRemaining = qty;
        const returned = [];
        for (const a of [...loan.batchAllocations].sort((x, y) => (x.expiry || NO_EXPIRY).localeCompare(y.expiry || NO_EXPIRY))) {
          const lost = Math.min(Number(a.qty), lostRemaining);
          lostRemaining -= lost;
          if (Number(a.qty) - lost > 0) returned.push({ ...a, qty: Number(a.qty) - lost });
        }
        if (returned.length) restockFromAllocations(updatedItem, returned);
      } else if (returnedGood > 0) {
        if (Array.isArray(updatedItem.batches) && updatedItem.batches.length) restockUnallocated(updatedItem, returnedGood);
        else updatedItem.qty = Number(updatedItem.qty) + returnedGood;
      }
    } else deductItemStock(updatedItem, qty);
    updatedItem.version = (item.version || 0) + 1;
    updatedItem.updatedAt = repo.now();
    tx.set("inventory", itemId, updatedItem);
    tx.set("lossRecords", lossId, loss);
    if (loan) tx.set("loans", loan.id, { ...loan, status: "returned", lostQty: qty, returnedGood, version: (loan.version || 0) + 1, returnedAt: repo.now() });
    const logId = "log_" + randomUUID();
    tx.set("logs", logId, { id: logId, item: item.nameEn, delta: loan ? "+" + returnedGood + " / -" + qty + " lost" : "-" + qty, note: reason + " (" + person + ")", time: repo.now(), actorUid: actor.uid });
    const result = { loss, item: updatedItem };
    tx.set("commands", cmd, { hash, result, createdAt: repo.now() });
    return result;
  });
}

// auth-broker.mjs
var deny = () => {
  throw new AppError(401, "SIGN_IN_FAILED", "Sign-in failed. Check the account and password.");
};
var publicDirectoryEntry = (profile) => ({ name: profile.name, selector: profile.uid, disabled: profile.role !== "teacher" || !!profile.disabled });
function createPasswordVerifier({ apiKey, projectId, emulatorHost }) {
  if (!apiKey) throw Error("FIREBASE_WEB_API_KEY is required for private sign-in");
  if (emulatorHost && (!projectId?.startsWith("demo-") || !/^127\.0\.0\.1:\d+$/.test(emulatorHost))) throw Error("Auth emulator is local-only");
  const root = emulatorHost ? "http://" + emulatorHost + "/identitytoolkit.googleapis.com/v1" : "https://identitytoolkit.googleapis.com/v1";
  return async (email, password) => {
    const result = await fetch(root + "/accounts:signInWithPassword?key=" + encodeURIComponent(apiKey), { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, password, returnSecureToken: true }), signal: AbortSignal.timeout(15e3) });
    if (!result.ok) {
      if (result.status === 429 || result.status >= 500) throw new AppError(503, "AUTH_UNAVAILABLE", "Sign-in service is busy. Try again later.");
      deny();
    }
    const value = await result.json();
    if (!value.localId) deny();
    return value.localId;
  };
}
function createSignInBroker({ repo, auth, passwordVerifier }) {
  let localWindow = 0, localAttempts = 0;
  return async (input) => {
    const now = Date.now(), window = Math.floor(now / 3e5);
    if (localWindow !== window) {
      localWindow = window;
      localAttempts = 0;
    }
    if (++localAttempts > 100) throw new AppError(429, "SIGN_IN_LIMIT", "Too many sign-in attempts. Try again in five minutes.");
    const role = input.role, name = input.name, selector = input.selector, password = input.password;
    if (!["teacher", "admin"].includes(role) || typeof password !== "string" || password.length < 1 || password.length > 128 || typeof name !== "string" || name.length > (role === "admin" ? 254 : 120) || role === "teacher" && (typeof selector !== "string" || !/^[-a-zA-Z0-9_]{1,128}$/.test(selector))) deny();
    if (!passwordVerifier || !auth.createCustomToken) throw new AppError(503, "SIGN_IN_SETUP_REQUIRED", "Private sign-in is not configured.");
    let profile;
    if (role === "teacher") profile = (await repo.collection("accounts").doc(selector).get()).data();
    else {
      const byName = await repo.collection("accounts").where("name", "==", name).get();
      const byLogin = await repo.collection("accounts").where("login", "==", name.toLowerCase()).get();
      const enabled = [...new Map([...byName.docs, ...byLogin.docs].map((doc) => {
        const account = doc.data();
        return [account.uid, account];
      })).values()].filter((account) => account.role === "admin" && !account.disabled);
      if (enabled.length === 1) profile = enabled[0];
    }
    if (!profile || profile.disabled || profile.role !== role || role === "teacher" && profile.name !== name) deny();
    const throttle = repo.collection("authThrottle").doc(sha256Hex(profile.uid));
    await repo.db.runTransaction(async (tx) => {
      const previous = (await tx.get(throttle)).data();
      const attempts = previous?.window === window ? previous.attempts : 0;
      if (attempts >= 10) throw new AppError(429, "SIGN_IN_LIMIT", "Too many sign-in attempts for this account. Try again in five minutes.");
      tx.set(throttle, { window, attempts: attempts + 1, expiresAt: new Date((window + 2) * 3e5).toISOString() });
    });
    let verifiedUid;
    try {
      verifiedUid = await passwordVerifier(profile.login, password);
    } catch (error2) {
      if (error2 instanceof AppError) throw error2;
      throw new AppError(503, "AUTH_UNAVAILABLE", "Sign-in service could not confirm the password. Try again later.");
    }
    if (verifiedUid !== profile.uid) deny();
    const latest = (await repo.collection("accounts").doc(profile.uid).get()).data(), user = await auth.getUser(profile.uid);
    if (!latest || latest.disabled || user.disabled || latest.role !== role || latest.login !== profile.login || latest.sessionVersion !== profile.sessionVersion) deny();
    return { token: await auth.createCustomToken(profile.uid, { sessionVersion: latest.sessionVersion }) };
  };
}

// rest-platform.mjs
function restPlatform({ projectId, apiKey, serviceAccount, emulatorFirestore, emulatorAuth }) {
  const emulated = !!(emulatorFirestore || emulatorAuth);
  if (emulated && (!projectId.startsWith("demo-") || ![emulatorFirestore, emulatorAuth].filter(Boolean).every((h) => /^(127\.0\.0\.1|localhost):\d+$/.test(h)))) throw Error("Emulator mode is restricted to local demo projects");
  const root = emulatorFirestore ? "http://" + emulatorFirestore : "https://firestore.googleapis.com";
  const database = "projects/" + projectId + "/databases/(default)";
  const documents = database + "/documents";
  const authRoot = emulatorAuth ? "http://" + emulatorAuth + "/identitytoolkit.googleapis.com/v1" : "https://identitytoolkit.googleapis.com/v1";
  let oauthCache;
  const base64 = base64Url;
  async function accessToken() {
    if (emulated) return "owner";
    if (oauthCache && oauthCache.expires > Date.now() + 6e4) return oauthCache.value;
    if (!serviceAccount?.client_email || !serviceAccount?.private_key || serviceAccount.project_id !== projectId) throw Error("A matching server credential is required");
    const now = Math.floor(Date.now() / 1e3);
    const unsigned = base64(JSON.stringify({ alg: "RS256", typ: "JWT" })) + "." + base64(JSON.stringify({ iss: serviceAccount.client_email, scope: "https://www.googleapis.com/auth/cloud-platform", aud: "https://oauth2.googleapis.com/token", iat: now, exp: now + 3600 }));
    const assertion = unsigned + "." + await signRs256(unsigned, serviceAccount.private_key);
    const response = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion }) });
    const data = await response.json();
    if (!response.ok || !data.access_token) throw Error("Server authentication failed");
    oauthCache = { value: data.access_token, expires: Date.now() + Number(data.expires_in || 3600) * 1e3 };
    return oauthCache.value;
  }
  async function call(url, { method = "POST", body, publicCall = false, missing = false } = {}) {
    const headers = { "Content-Type": "application/json" };
    if (!publicCall) headers.Authorization = "Bearer " + await accessToken();
    const response = await fetch(url, { method, headers, signal: AbortSignal.timeout(15e3), ...body === void 0 ? {} : { body: JSON.stringify(body) } });
    if (missing && response.status === 404) return null;
    const data = await response.json();
    if (!response.ok) {
      const err = new Error("Firebase operation failed");
      err.code = data.error?.status || "UNKNOWN";
      err.status = response.status;
      throw err;
    }
    return data;
  }
  const encode = (value) => {
    if (value === null) return { nullValue: null };
    if (typeof value === "boolean") return { booleanValue: value };
    if (typeof value === "number") {
      if (!Number.isFinite(value)) throw Error("Non-finite number");
      return Number.isInteger(value) ? { integerValue: String(value) } : { doubleValue: value };
    }
    if (typeof value === "string") return { stringValue: value };
    if (Array.isArray(value)) return { arrayValue: { values: value.map(encode) } };
    if (value && typeof value === "object") return { mapValue: { fields: fields(value) } };
    throw Error("Unsupported document value");
  };
  const fields = (value) => Object.fromEntries(Object.entries(value).map(([key, val]) => [key, encode(val)]));
  const decode = (value) => {
    if ("nullValue" in value) return null;
    if ("booleanValue" in value) return value.booleanValue;
    if ("integerValue" in value) return Number(value.integerValue);
    if ("doubleValue" in value) return value.doubleValue;
    if ("stringValue" in value) return value.stringValue;
    if ("timestampValue" in value) return value.timestampValue;
    if ("arrayValue" in value) return (value.arrayValue.values || []).map(decode);
    if ("mapValue" in value) return unfields(value.mapValue.fields || {});
    throw Error("Unsupported stored document type");
  };
  const unfields = (value) => Object.fromEntries(Object.entries(value).map(([key, val]) => [key, decode(val)]));
  const snapshot = (data) => ({ exists: !!data, id: data?.name?.split("/").pop(), data: () => data ? unfields(data.fields || {}) : void 0 });
  async function read(ref, transaction) {
    if (ref.query) {
      const structuredQuery = { from: [{ collectionId: ref.kind }] };
      if (ref.filters.length) structuredQuery.where = { compositeFilter: { op: "AND", filters: ref.filters.map((f) => ({ fieldFilter: { field: { fieldPath: f.field }, op: "EQUAL", value: encode(f.value) } })) } };
      const rows = await call(root + "/v1/" + documents + ":runQuery", { body: { structuredQuery, ...transaction ? { transaction } : {} } });
      return { docs: rows.filter((row) => row.document).map((row) => snapshot(row.document)) };
    }
    if (transaction) {
      const rows = await call(root + "/v1/" + documents + ":batchGet", { body: { documents: [ref.name], transaction } });
      return snapshot(rows.find((row) => row.found)?.found || null);
    }
    const data = await call(root + "/v1/" + ref.name, { method: "GET", missing: true });
    return snapshot(data);
  }
  async function readAll(refs, transaction) {
    const rows = await call(root + "/v1/" + documents + ":batchGet", { body: { documents: refs.map((ref) => ref.name), ...transaction ? { transaction } : {} } });
    const map = new Map(rows.map((row) => [row.found?.name || row.missing, snapshot(row.found || null)]));
    return refs.map((ref) => map.get(ref.name) || snapshot(null));
  }
  const write = (ref, value, merge = false) => ({ update: { name: ref.name, fields: fields(value) }, ...merge ? { updateMask: { fieldPaths: Object.keys(value) } } : {} });
  const commit = async (writes) => call(root + "/v1/" + documents + ":commit", { body: { writes } });
  const docRef = (kind, key) => ({ name: documents + "/" + kind + "/" + key, get() {
    return read(this);
  }, set(value) {
    return commit([write(this, value)]);
  }, update(value) {
    return commit([{ ...write(this, value, true), currentDocument: { exists: true } }]);
  } });
  const collectionRef = (kind, filters = []) => ({ query: true, kind, filters, doc: (key) => docRef(kind, key), get() {
    return read(this);
  }, where: (field, op, value) => {
    if (op !== "==") throw Error("Only equality filters are supported");
    return collectionRef(kind, [...filters, { field, value }]);
  } });
  const db = {
    collection: (kind) => collectionRef(kind),
    batch() {
      const writes = [];
      return { set: (ref, value) => writes.push(write(ref, value)), commit: () => commit(writes) };
    },
    async runTransaction(fn, { maxAttempts = 5 } = {}) {
      for (let attempt = 0; attempt < maxAttempts; attempt++) {
        const { transaction } = await call(root + "/v1/" + documents + ":beginTransaction", { body: { options: { readWrite: {} } } }), writes = [];
        try {
          const out = await fn({ get: (ref) => read(ref, transaction), getAll: (...refs) => readAll(refs, transaction), set: (ref, value) => writes.push(write(ref, value)), delete: (ref) => writes.push({ delete: ref.name }) });
          await call(root + "/v1/" + documents + ":commit", { body: { transaction, writes } });
          return out;
        } catch (err) {
          try {
            await call(root + "/v1/" + documents + ":rollback", { body: { transaction } });
          } catch {
          }
          if (err.code === "ABORTED" && attempt < maxAttempts - 1) {
            await new Promise((resolve) => setTimeout(resolve, 30 * (attempt + 1)));
            continue;
          }
          throw err;
        }
      }
    }
  };
  const providerUser = (user) => ({ uid: user.localId, disabled: !!user.disabled, customClaims: JSON.parse(user.customAttributes || "{}") });
  const adminAuth = (path, body) => call(authRoot + "/projects/" + projectId + path + "?key=" + encodeURIComponent(apiKey), { body });
  const auth = {
    app: { options: { projectId } },
    async verifyIdToken(token, checkRevoked) {
      const result = await call(authRoot + "/accounts:lookup?key=" + encodeURIComponent(apiKey), { body: { idToken: token }, publicCall: true });
      const user = result.users?.[0];
      if (!user || user.disabled) throw Error("Invalid or disabled user");
      let claims;
      try {
        claims = JSON.parse(decodeBase64UrlText(token.split(".")[1]));
      } catch {
        throw Error("Malformed token");
      }
      const now = Math.floor(Date.now() / 1e3);
      if (claims.aud !== projectId || claims.iss !== "https://securetoken.google.com/" + projectId || claims.sub !== user.localId || claims.exp <= now || claims.iat > now + 30 || checkRevoked && Number(claims.auth_time) < Number(user.validSince || 0)) throw Error("Invalid token claims");
      return { ...claims, uid: user.localId };
    },
    async getUser(uid) {
      const data = await adminAuth("/accounts:lookup", { localId: [uid] });
      if (!data.users?.[0]) throw Error("User not found");
      return providerUser(data.users[0]);
    },
    passwordSignIn: createPasswordVerifier({ apiKey, projectId, emulatorHost: emulatorAuth }),
    async createCustomToken(uid, claims = {}) {
      const now = Math.floor(Date.now() / 1e3), header = { alg: emulated ? "none" : "RS256", typ: "JWT" }, issuer = emulated ? "emulator@" + projectId + ".iam.gserviceaccount.com" : serviceAccount.client_email;
      const unsigned = base64Url(JSON.stringify(header)) + "." + base64Url(JSON.stringify({ iss: issuer, sub: issuer, aud: "https://identitytoolkit.googleapis.com/google.identity.identitytoolkit.v1.IdentityToolkit", iat: now, exp: now + 300, uid, claims }));
      return unsigned + "." + (emulated ? "" : await signRs256(unsigned, serviceAccount.private_key));
    },
    async createUser({ uid, ...value }) {
      const out = await adminAuth("/accounts", { localId: uid, ...value });
      return { uid: out.localId };
    },
    async updateUser(uid, value) {
      const { disabled, ...rest } = value;
      return adminAuth("/accounts:update", { localId: uid, ...rest, ...disabled === void 0 ? {} : { disableUser: disabled } });
    },
    async setCustomUserClaims(uid, value) {
      return adminAuth("/accounts:update", { localId: uid, customAttributes: JSON.stringify(value) });
    },
    async revokeRefreshTokens(uid) {
      return adminAuth("/accounts:update", { localId: uid, validSince: String(Math.floor(Date.now() / 1e3)) });
    }
  };
  return { db, auth };
}

// firebase-repository.mjs
var FirestoreRepository = class _FirestoreRepository {
  constructor(db, { prefix = "regent_v2_", expectedEpoch } = {}) {
    this.db = db;
    this.prefix = prefix;
    this.expectedEpoch = expectedEpoch;
  }
  now() {
    return (/* @__PURE__ */ new Date()).toISOString();
  }
  collection(kind) {
    return this.db.collection(this.prefix + kind);
  }
  withEpoch(epoch = 0) {
    return new _FirestoreRepository(this.db, { prefix: this.prefix, expectedEpoch: epoch });
  }
  async transaction(fn, options = {}) {
    return this.db.runTransaction(async (transaction) => {
      const queued = [], cache = /* @__PURE__ */ new Map(), touched = /* @__PURE__ */ new Map();
      const clockRef = this.collection("meta").doc("mutationClock"), clock = await transaction.get(clockRef), revision = (clock.data()?.version || 0) + 1;
      if (this.expectedEpoch !== void 0) {
        const settings = await transaction.get(this.collection("settings").doc("main"));
        if ((settings.data()?.restoreEpoch || 0) !== this.expectedEpoch) throw new AppError(409, "STALE_DATASET", "The dataset was restored. Reopen the form before saving.");
      }
      const cacheKey = (kind, id2) => kind + "/" + id2;
      const mark = (kind, value) => {
        if (entityKinds.has(kind) || kind === "settings") {
          if (value) value._revision = revision;
          const uids = touched.get(kind) || /* @__PURE__ */ new Set();
          if (value?.teacherUid) uids.add(value.teacherUid);
          touched.set(kind, uids);
        }
      };
      const tx = {
        get: async (kind, id2) => {
          const key = cacheKey(kind, id2);
          if (cache.has(key)) return cache.get(key);
          const snap = await transaction.get(this.collection(kind).doc(id2)), value = snap.exists ? snap.data() : null;
          cache.set(key, value);
          return value;
        },
        preload: async (pairs) => {
          const unique = [...new Map(pairs.map(([kind, id2]) => [cacheKey(kind, id2), [kind, id2]])).values()].filter(([kind, id2]) => !cache.has(cacheKey(kind, id2)));
          if (!unique.length) return;
          const snaps = await transaction.getAll(...unique.map(([kind, id2]) => this.collection(kind).doc(id2)));
          snaps.forEach((snap, index) => cache.set(cacheKey(...unique[index]), snap.exists ? snap.data() : null));
        },
        list: async (kind) => (await transaction.get(this.collection(kind))).docs.map((doc) => doc.data()).filter((row) => !row._meta),
        set: (kind, id2, value) => {
          mark(kind, value);
          queued.push({ kind, id: id2, value });
        },
        delete: (kind, id2) => {
          mark(kind, cache.get(cacheKey(kind, id2)));
          queued.push({ kind, id: id2, delete: true });
        },
        findActiveBooking: async (slot) => {
          const lock = await transaction.get(this.collection("meta").doc("scheduleLock"));
          queued.push({ kind: "meta", id: "scheduleLock", value: { version: (lock.data()?.version || 0) + 1 } });
          const booking = await transaction.get(this.collection("bookings").doc(digest(slot)));
          if (booking.exists) return booking.data();
          const day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][(/* @__PURE__ */ new Date(slot.date + "T12:00:00Z")).getUTCDay()];
          const schedules = await transaction.get(this.collection("scheduleSlots").where("lab", "==", slot.lab));
          return schedules.docs.map((doc) => doc.data()).find((row) => !row._meta && row.day === day && row.period === slot.period && !(row.skippedDates || row.excludedDates || []).includes(slot.date) && (row.recurrence === "weekly" || row.weekDate === slot.date)) || null;
        }
      };
      const result = await fn(tx);
      if (queued.length) {
        transaction.set(clockRef, { version: revision });
        if (result && typeof result === "object") result.revision = revision;
        for (const [kind, uids] of touched) {
          if (kind === "settings") continue;
          queued.push({ kind, id: "__regent_head", value: { _meta: true, _revision: revision } });
          for (const uid of uids) queued.push({ kind, id: "__regent_head_" + uid, value: { _meta: true, _revision: revision, teacherUid: uid } });
        }
      }
      for (const write of queued) {
        const ref = this.collection(write.kind).doc(write.id);
        if (write.delete) transaction.delete(ref);
        else transaction.set(ref, write.value);
      }
      return result;
    }, options);
  }
};

// ../restore-contract.mjs
var datasetKinds = ["inventory", "cabinets", "requests", "scheduleSlots", "loans", "lossRecords", "logs"];
function datasetStamp(state) {
  return JSON.stringify({ epoch: state.settings?.restoreEpoch || 0, settings: state.settings?.version || 0, rows: datasetKinds.map((kind) => [kind, (state[kind] || []).filter((row) => !row._meta).map((row) => [String(row.id), row.version || 0, row._revision || 0]).sort((a, b) => a[0].localeCompare(b[0]))]) });
}

// restore.mjs
var fail2 = (code, message) => {
  throw new AppError(409, code, message);
};
var normalize = (value) => String(value || "").trim().normalize("NFKC").toLocaleLowerCase("en");
var weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var dayFor = (date) => weekdays[(/* @__PURE__ */ new Date(date + "T12:00:00Z")).getUTCDay()];
async function restoreDataset(repo, actor, input, commandId) {
  assertActor(actor, "admin");
  id(commandId);
  if (!input?.data || typeof input.expectedStamp !== "string") fail2("INVALID_RESTORE", "Choose a complete backup after cloud sync is ready");
  const data = cleanSettings(clone(input.data));
  if (!data.settings || datasetKinds.some((kind) => !Array.isArray(data[kind]))) fail2("INCOMPLETE_BACKUP", "The backup must include settings and every dataset, including requests and loans");
  const hash = digest({ data, expectedStamp: input.expectedStamp }), command = actor.uid + "_" + commandId;
  return repo.transaction(async (tx) => {
    const prior = await tx.get("commands", command);
    if (prior) {
      if (prior.hash !== hash) fail2("IDEMPOTENCY_CONFLICT", "Restore retry has different content");
      return prior.result;
    }
    const current = {};
    for (const kind of datasetKinds) current[kind] = await tx.list(kind);
    current.settings = await tx.get("settings", "main") || {};
    const accounts = await tx.list("accounts"), oldBookings = await tx.list("bookings");
    if (datasetStamp(current) !== input.expectedStamp) fail2("STALE_RESTORE", "Cloud data changed after this restore was opened. Reopen the backup and review it again.");
    const maps = {};
    for (const kind of datasetKinds) {
      maps[kind] = /* @__PURE__ */ new Map();
      for (const row of data[kind]) {
        if (!row || typeof row !== "object" || Array.isArray(row)) fail2("INVALID_RESTORE", "A backup record is invalid");
        id(row.id);
        if (maps[kind].has(row.id)) fail2("DUPLICATE_ID", "The backup contains a repeated " + kind + " identifier");
        delete row._revision;
        delete row._meta;
        maps[kind].set(row.id, row);
      }
    }
    const teachers = accounts.filter((row) => row.role === "teacher" && !row.disabled);
    const mapTeacher = (row, { required = false } = {}) => {
      if (row.teacherUid) {
        const account = teachers.find((a) => a.uid === row.teacherUid);
        if (!account || row.teacherName && normalize(account.name) !== normalize(row.teacherName)) fail2("TEACHER_MAPPING", "A backed-up teacher identity does not match an existing protected account");
        row.teacherName = account.name;
        return;
      }
      const found = teachers.filter((a) => normalize(a.name) === normalize(row.teacherName));
      if (found.length > 1 || required && found.length !== 1) fail2("TEACHER_MAPPING", "Create the missing teacher account or give duplicate teacher names distinct names before restoring");
      if (found.length === 1) {
        row.teacherUid = found[0].uid;
        row.teacherName = found[0].name;
      }
    };
    for (const row of data.inventory) {
      if (typeof row.qty !== "number" || !Number.isFinite(row.qty) || row.qty < 0 || row.qty > 1e9) fail2("INVALID_STOCK", "The backup contains invalid inventory stock");
      const batches = normalizeBatches(row.batches);
      if (batches !== void 0) {
        if (batches.length && batchTotal(batches) !== row.qty) fail2("INVALID_STOCK", "Backed-up stock batches do not add up to the recorded quantity");
        row.batches = batches.length ? batches : void 0;
        if (!batches.length) delete row.batches;
      }
    }
    for (const row of data.requests) {
      if (!["pending", "approved", "rejected"].includes(row.status) || !["in-lab", "outside-lab"].includes(row.usageMode)) fail2("INVALID_REQUEST", "A backed-up request has an invalid status or use mode");
      dateOnly(row.date);
      mapTeacher(row, { required: true });
      if (!Array.isArray(row.items) || !row.items.length) fail2("INVALID_REQUEST", "A backed-up request has no items");
      const seen = /* @__PURE__ */ new Set();
      for (const item of row.items) {
        id(item.itemId);
        positive(item.qty);
        if (seen.has(item.itemId)) fail2("INVALID_REQUEST", "A backed-up request repeats an item");
        seen.add(item.itemId);
        if (row.status === "pending" && !maps.inventory.has(item.itemId)) fail2("MISSING_ITEM", "A pending request refers to missing inventory");
      }
    }
    for (const row of data.loans) {
      if (!["active", "returned"].includes(row.status)) fail2("INVALID_LOAN", "A backed-up loan has an invalid status");
      positive(row.qty);
      id(row.itemId);
      mapTeacher(row);
      if (row.status === "active" && !maps.inventory.has(row.itemId)) fail2("MISSING_ITEM", "An active loan refers to missing inventory");
      if (row.requestId && !maps.requests.has(row.requestId)) fail2("MISSING_REQUEST", "A request-linked loan refers to a missing request");
      if (row.dueDate) dateOnly(row.dueDate);
    }
    for (const row of data.lossRecords) {
      positive(row.qty);
      if (row.linkedLoanId && !maps.loans.has(row.linkedLoanId)) fail2("MISSING_LOAN", "A loss record refers to a missing loan");
    }
    for (const row of data.scheduleSlots) {
      dateOnly(row.weekDate);
      if (row.day !== dayFor(row.weekDate) || !["weekly", "single"].includes(row.recurrence)) fail2("INVALID_SCHEDULE", "A backed-up schedule has an invalid weekday or recurrence");
      if (!row.lab || !row.period) fail2("INVALID_SCHEDULE", "A schedule is missing its laboratory or period");
      if (row.skippedDates && !Array.isArray(row.skippedDates)) fail2("INVALID_SCHEDULE", "Schedule skipped dates must be a list");
      for (const date of row.skippedDates || []) dateOnly(date);
    }
    const activeRequests = data.requests.filter((row) => row.usageMode === "in-lab" && row.status !== "rejected"), bookings = /* @__PURE__ */ new Map();
    for (const row of activeRequests) {
      const slot = { date: row.date, period: row.period, lab: row.lab }, key = digest(slot);
      if (bookings.has(key)) fail2("BOOKING_CONFLICT", "Two backed-up requests hold the same laboratory period");
      bookings.set(key, { ...slot, requestId: row.id, status: row.status });
      for (const manual of data.scheduleSlots) if (manual.lab === row.lab && manual.period === row.period && manual.day === dayFor(row.date) && !(manual.skippedDates || []).includes(row.date) && (manual.recurrence === "weekly" || manual.weekDate === row.date)) fail2("BOOKING_CONFLICT", "A backed-up request overlaps a recurring schedule");
    }
    for (let i = 0; i < data.scheduleSlots.length; i++) for (let j = i + 1; j < data.scheduleSlots.length; j++) {
      const a = data.scheduleSlots[i], b = data.scheduleSlots[j];
      if (a.lab !== b.lab || a.day !== b.day || a.period !== b.period) continue;
      if (a.recurrence === "weekly" && b.recurrence === "weekly") fail2("BOOKING_CONFLICT", "Two weekly schedule entries overlap");
      const date = a.recurrence === "weekly" ? b.weekDate : a.weekDate;
      if ((a.recurrence === "weekly" || b.recurrence === "weekly" || a.weekDate === b.weekDate) && !(a.skippedDates || []).includes(date) && !(b.skippedDates || []).includes(date)) fail2("BOOKING_CONFLICT", "Two schedule entries overlap");
    }
    const now = repo.now(), epoch = (current.settings.restoreEpoch || 0) + 1;
    const nextSettings = { ...data.settings, restoreEpoch: epoch, version: (current.settings.version || 0) + 1, updatedAt: now };
    delete nextSettings.teachers;
    delete nextSettings.adminUsername;
    const existingLogs = new Map(current.logs.map((row) => [row.id, row]));
    let importedLogs = 0;
    for (const row of data.logs) {
      const old = existingLogs.get(row.id);
      if (old && digest(cleanSettings(old)) === digest(cleanSettings(row))) continue;
      if (old) row.id = "import_" + digest(row).slice(0, 48);
      if (existingLogs.has(row.id)) continue;
      row.imported = true;
      row.restoredBy = actor.uid;
      row.restoredAt = now;
      existingLogs.set(row.id, row);
      importedLogs++;
    }
    data.logs = [...existingLogs.values()];
    const audit = { id: "restore_" + commandId, type: "dataset_restored", item: "System backup", delta: "0", note: "Full dataset restored; protected accounts and prior audit history kept", time: now, actorUid: actor.uid, restoreEpoch: epoch, version: 1 };
    data.logs.push(audit);
    for (const kind of datasetKinds) {
      const before = new Map(current[kind].map((row) => [row.id, row])), after = new Set(data[kind].map((row) => row.id));
      if (kind !== "logs") {
        for (const row of current[kind]) if (!after.has(row.id)) tx.delete(kind, row.id);
      }
      for (const row of data[kind]) {
        if (kind === "logs" && before.has(row.id)) continue;
        const next = { ...row, version: Math.max(Number(before.get(row.id)?.version) || 0, Number(row.version) || 0) + 1, updatedAt: now };
        tx.set(kind, row.id, next);
      }
    }
    for (const row of oldBookings) tx.delete("bookings", digest({ date: row.date, period: row.period, lab: row.lab }));
    for (const [key, value] of bookings) tx.set("bookings", key, value);
    tx.set("settings", "main", nextSettings);
    const result = { restored: true, restoreEpoch: epoch, counts: Object.fromEntries(datasetKinds.map((kind) => [kind, data[kind].length])), importedLogs, accountsPreserved: true, priorAuditPreserved: true };
    tx.set("commands", command, { hash, result, createdAt: now });
    return result;
  }, { maxAttempts: 2 });
}

// http-handler.mjs
var error = (status, code, message) => {
  throw new AppError(status, code, message);
};
function createHandler({ repo, auth, allowedOrigin, allowLocalDevelopment = false, passwordVerifier = auth.passwordSignIn?.bind(auth) }) {
  if (!allowedOrigin || !(/^https:\/\//.test(allowedOrigin) || allowLocalDevelopment && auth.app.options.projectId.startsWith("demo-") && /^http:\/\/(127\.0\.0\.1|localhost):\d+$/.test(allowedOrigin))) throw new Error("An explicit HTTPS ALLOWED_ORIGIN is required");
  const broker = createSignInBroker({ repo, auth, passwordVerifier });
  const publicProfile = (account) => ({ uid: account.uid, name: account.name, login: account.login, role: account.role });
  async function actorFor(token) {
    if (!token) error(401, "UNAUTHENTICATED", "Sign in first");
    let decoded;
    try {
      decoded = await auth.verifyIdToken(token, true);
    } catch {
      error(401, "UNAUTHENTICATED", "Sign in again");
    }
    const snap = await repo.collection("accounts").doc(decoded.uid).get(), profile = snap.data();
    if (!snap.exists || profile.disabled || !["teacher", "admin"].includes(profile.role)) error(403, "ACCOUNT_DISABLED", "Account is not enabled");
    if (!Number.isInteger(decoded.sessionVersion) || ![profile.sessionVersion, profile.pendingSessionVersion].includes(decoded.sessionVersion) || (decoded.auth_time || 0) < (profile.validAfter || 0)) error(401, "SESSION_EXPIRED", "Sign in again");
    return { ...profile, uid: decoded.uid, authTime: decoded.auth_time };
  }
  return async function handler(request, response) {
    const origin = request.headers.origin;
    response.setHeader("Cache-Control", "no-store");
    response.setHeader("Content-Type", "application/json; charset=utf-8");
    response.setHeader("X-Content-Type-Options", "nosniff");
    response.setHeader("Vary", "Origin");
    const send = (status, body) => {
      response.statusCode = status;
      response.end(JSON.stringify(body));
    };
    try {
      if (origin && origin !== allowedOrigin) error(403, "ORIGIN_DENIED", "This origin is not allowed");
      if (origin === allowedOrigin) response.setHeader("Access-Control-Allow-Origin", allowedOrigin);
      response.setHeader("Access-Control-Allow-Headers", "Authorization, Content-Type, X-Command-ID");
      response.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
      if (request.method === "OPTIONS") {
        response.statusCode = 204;
        return response.end();
      }
      const url = new URL(request.url, "https://backend.invalid");
      if (request.method === "GET" && url.pathname === "/info") return send(200, { projectId: auth.app.options.projectId });
      if (request.method === "GET" && url.pathname === "/health") return send(200, { status: "ok" });
      if (request.method === "GET" && url.pathname === "/directory") {
        const docs = await repo.collection("directory").where("disabled", "==", false).get();
        return send(200, { accounts: docs.docs.map((d) => ({ name: d.data().name, selector: d.id || d.data().selector || d.data().uid })).sort((a, b) => a.name.localeCompare(b.name)) });
      }
      if (request.method === "POST" && url.pathname === "/auth/login") {
        if (origin !== allowedOrigin) error(403, "ORIGIN_DENIED", "Use the application sign-in page");
        if (!/^application\/json(?:;|$)/i.test(request.headers["content-type"] || "")) error(415, "JSON_REQUIRED", "Use JSON");
        let raw2 = "", size2 = 0;
        const decoder2 = new TextDecoder();
        for await (const chunk of request) {
          const bytes = typeof chunk === "string" ? new TextEncoder().encode(chunk) : chunk;
          size2 += bytes.byteLength;
          if (size2 > 4096) error(413, "TOO_LARGE", "Sign-in request is too large");
          raw2 += decoder2.decode(bytes, { stream: true });
        }
        raw2 += decoder2.decode();
        let input;
        try {
          input = JSON.parse(raw2);
        } catch {
          error(400, "INVALID_JSON", "Invalid JSON");
        }
        if (!input || typeof input !== "object" || Array.isArray(input)) error(400, "INVALID_JSON", "Use a sign-in object");
        return send(200, await broker(input));
      }
      const token = /^Bearer ([^ ]+)$/.exec(request.headers.authorization || "")?.[1];
      const actor = await actorFor(token);
      if (request.method === "GET" && url.pathname === "/admin/directory") {
        assertActor(actor, "admin");
        const docs = await repo.collection("accounts").where("disabled", "==", false).get();
        return send(200, { accounts: docs.docs.map((d) => publicProfile(d.data())).sort((a, b) => a.name.localeCompare(b.name)) });
      }
      if (request.method === "GET" && url.pathname === "/me") return send(200, { account: publicProfile(actor) });
      if (request.method === "GET" && url.pathname === "/admin/snapshots") return send(200, await listSnapshots(repo, actor));
      if (request.method !== "POST") error(404, "NOT_FOUND", "Action not found");
      if (!/^application\/json(?:;|$)/i.test(request.headers["content-type"] || "")) error(415, "JSON_REQUIRED", "Use JSON");
      let raw = "", size = 0;
      const decoder = new TextDecoder();
      for await (const chunk of request) {
        const bytes = typeof chunk === "string" ? new TextEncoder().encode(chunk) : chunk;
        size += bytes.byteLength;
        if (size > (url.pathname === "/admin/restore" ? 4 * 1024 * 1024 : 512 * 1024)) error(413, "TOO_LARGE", "Request is too large");
        raw += decoder.decode(bytes, { stream: true });
      }
      raw += decoder.decode();
      let body;
      try {
        body = JSON.parse(raw);
      } catch {
        error(400, "INVALID_JSON", "Invalid JSON");
      }
      const commandId = id(request.headers["x-command-id"] || "");
      const requestRepo = repo.withEpoch ? repo.withEpoch(body.epoch || 0) : repo;
      if (url.pathname === "/admin/restore") return send(200, await restoreDataset(repo, actor, body, commandId));
      if (url.pathname === "/admin/snapshots/create") return send(200, await createSnapshot(repo, actor, commandId));
      if (url.pathname === "/admin/snapshots/restore") {
        const snap = await loadSnapshot(repo, actor, body?.snapshotId);
        return send(200, await restoreDataset(repo, actor, { data: snap.data, expectedStamp: body?.expectedStamp }, commandId));
      }
      if (url.pathname === "/requests") return send(200, await createRequisition(requestRepo, actor, body, commandId));
      if (url.pathname === "/requests/decide") return send(200, await decideRequisition(requestRepo, actor, body, commandId));
      if (url.pathname === "/requests/reverse") return send(200, await reverseRequisition(requestRepo, actor, body, commandId));
      if (url.pathname === "/admin/changes") return send(200, await applyAdminChanges(requestRepo, actor, body, commandId));
      if (url.pathname === "/loans/issue") return send(200, await issueManualLoan(requestRepo, actor, body, commandId));
      if (url.pathname === "/losses") return send(200, await recordLoss(requestRepo, actor, body, commandId));
      if (url.pathname === "/loans/return") return send(200, await returnLoan(requestRepo, actor, body, commandId));
      if (url.pathname === "/admin/directory/minimize") {
        assertActor(actor, "admin");
        const count = await repo.db.runTransaction(async (tx) => {
          const accounts = await tx.get(repo.collection("accounts")), existing = await tx.get(repo.collection("directory"));
          const rows = new Map(existing.docs.map((doc) => [doc.id || doc.data().uid, { name: doc.data().name, selector: doc.id || doc.data().uid, disabled: true }]));
          for (const doc of accounts.docs) {
            const profile = doc.data();
            rows.set(profile.uid, publicDirectoryEntry(profile));
          }
          if (rows.size > 300) error(413, "DIRECTORY_TOO_LARGE", "More than 300 directory records need a staged administrator procedure");
          for (const [uid, row] of rows) tx.set(repo.collection("directory").doc(uid), row);
          return rows.size;
        });
        return send(200, { minimized: true, records: count, accountsUnchanged: true });
      }
      if (url.pathname === "/admin/self") {
        assertActor(actor, "admin");
        if (Date.now() / 1e3 - (actor.authTime || 0) > 300) error(401, "RECENT_LOGIN_REQUIRED", "Sign out and sign in again before changing administrator credentials");
        const name = text(body.name, 120), password = body.password;
        if (password && (typeof password !== "string" || password.length < 12 || password.length > 128)) error(400, "PASSWORD_POLICY", "Use a password of 12 to 128 characters");
        const ref = repo.collection("accounts").doc(actor.uid);
        const sessionVersion = actor.pendingSessionVersion || (actor.sessionVersion || 0) + 1;
        if (password) await ref.update({ pendingSessionVersion: sessionVersion, validAfter: Math.floor(Date.now() / 1e3) });
        await auth.updateUser(actor.uid, { displayName: name, ...password ? { password } : {} });
        if (password) {
          const user = await auth.getUser(actor.uid);
          await auth.setCustomUserClaims(actor.uid, { ...user.customClaims, sessionVersion });
          await auth.revokeRefreshTokens(actor.uid);
          await ref.update({ name, sessionVersion, pendingSessionVersion: null, validAfter: Math.floor(Date.now() / 1e3) });
        } else await ref.update({ name });
        await repo.collection("directory").doc(actor.uid).update({ name });
        return send(200, { name, signInAgain: !!password });
      }
      if (url.pathname.startsWith("/admin/accounts")) {
        assertActor(actor, "admin");
        if (url.pathname === "/admin/accounts/create") {
          const name = text(body.name, 120), role = body.role || "teacher";
          if (role !== "teacher") error(400, "TEACHERS_ONLY", "This action creates teacher accounts only");
          if (typeof body.password !== "string" || body.password.length < 12 || body.password.length > 128) error(400, "PASSWORD_POLICY", "Use a password of 12 to 128 characters");
          const uid2 = "teacher_" + sha256Hex(actor.uid + ":" + commandId).slice(0, 32), login = uid2 + "@" + auth.app.options.projectId + ".invalid";
          const previous = await repo.collection("accounts").doc(uid2).get();
          if (previous.exists) {
            const existing = previous.data();
            if (existing.name !== name || existing.createdBy !== actor.uid) error(409, "IDEMPOTENCY_CONFLICT", "Account operation has different content");
            const user = await auth.getUser(uid2);
            if (user.disabled || existing.disabled) error(409, "PROVISIONING_INCOMPLETE", "A disabled partial account needs administrator review");
            return send(200, { account: publicProfile(existing), alreadyApplied: true });
          }
          const normalizedName = name.normalize("NFKC").toLocaleLowerCase("en");
          const nameRef = repo.collection("accountNames").doc(sha256Hex(normalizedName));
          await repo.db.runTransaction(async (transaction) => {
            const reserved = await transaction.get(nameRef), directory = await transaction.get(repo.collection("directory"));
            if (reserved.exists && reserved.data().uid !== uid2) error(409, "DUPLICATE_NAME", "This teacher name already has an account. Use a distinct display name or manage the existing account.");
            if (directory.docs.some((doc) => (doc.id || doc.data().selector || doc.data().uid) !== uid2 && doc.data().name.normalize("NFKC").toLocaleLowerCase("en") === normalizedName)) error(409, "DUPLICATE_NAME", "This display name already has an account.");
            transaction.set(nameRef, { uid: uid2, createdBy: actor.uid });
          });
          await auth.createUser({ uid: uid2, email: login, password: body.password, displayName: name, disabled: true });
          const profile = { uid: uid2, name, login, role, disabled: false, validAfter: 0, sessionVersion: 1, createdBy: actor.uid, createdAt: repo.now(), version: 1 };
          try {
            const batch = repo.db.batch();
            batch.set(repo.collection("accounts").doc(uid2), profile);
            batch.set(repo.collection("directory").doc(uid2), publicDirectoryEntry(profile));
            await batch.commit();
            await auth.setCustomUserClaims(uid2, { sessionVersion: 1 });
            await auth.updateUser(uid2, { disabled: false });
          } catch {
            error(503, "PROVISIONING_INCOMPLETE", "Teacher account setup did not complete. Do not retry blindly; review the disabled account.");
          }
          return send(201, { account: publicProfile(profile) });
        }
        const uid = id(body.uid || ""), ref = repo.collection("accounts").doc(uid), snap = await ref.get(), account = snap.data();
        if (!snap.exists || account.role !== "teacher") error(404, "TEACHER_NOT_FOUND", "Teacher account not found");
        if (url.pathname === "/admin/accounts/password") {
          if (typeof body.password !== "string" || body.password.length < 12 || body.password.length > 128) error(400, "PASSWORD_POLICY", "Use a password of 12 to 128 characters");
          const commandRef = repo.collection("accountCommands").doc(actor.uid + "_" + commandId);
          const operation = await repo.db.runTransaction(async (transaction) => {
            const previous = await transaction.get(commandRef), current = await transaction.get(ref);
            if (previous.exists) {
              const value2 = previous.data();
              if (value2.uid !== uid || value2.operation !== "password_reset") error(409, "IDEMPOTENCY_CONFLICT", "This command belongs to another account action");
              return value2;
            }
            const profile = current.data(), value = { uid, operation: "password_reset", status: "pending", wasDisabled: !!profile.disabled, sessionVersion: (profile.sessionVersion || 0) + 1, startedAt: repo.now() };
            transaction.set(commandRef, value);
            transaction.set(ref, { ...profile, disabled: true });
            return value;
          });
          if (operation.status === "done") return send(200, { account: publicProfile(account), sessionsRevoked: true, alreadyApplied: true });
          await auth.updateUser(uid, { disabled: true });
          await auth.updateUser(uid, { password: body.password });
          await auth.revokeRefreshTokens(uid);
          const validAfter = Math.floor(Date.now() / 1e3), currentUser = await auth.getUser(uid);
          await auth.setCustomUserClaims(uid, { ...currentUser.customClaims, sessionVersion: operation.sessionVersion });
          await ref.update({ validAfter, sessionVersion: operation.sessionVersion, disabled: operation.wasDisabled });
          await auth.updateUser(uid, { disabled: operation.wasDisabled });
          await commandRef.update({ status: "done", finishedAt: repo.now() });
          return send(200, { account: publicProfile(account), sessionsRevoked: true, disabled: operation.wasDisabled });
        }
        if (url.pathname === "/admin/accounts/disable") {
          await ref.update({ disabled: true });
          await auth.updateUser(uid, { disabled: true });
          await auth.revokeRefreshTokens(uid);
          await repo.collection("directory").doc(uid).update({ disabled: true });
          return send(200, { disabled: true, uid });
        }
      }
      error(404, "NOT_FOUND", "Action not found");
    } catch (err) {
      const known = err instanceof AppError;
      send(known ? err.status : 503, { error: { code: known ? err.code : "SERVICE_UNAVAILABLE", message: known ? err.message : "The service could not complete this action. Nothing is confirmed saved." } });
    }
  };
}

// ../school-public-config.json
var school_public_config_default = { apiKey: "AIzaSyCHsR2-Iccj5oJGjN9KhHnIT3dDGrB0Wdw", appId: "1:351781323945:web:f92eac84d7bfa2eb8915b8", authDomain: "regent-lab.firebaseapp.com", measurementId: "G-R5H2GEL171", messagingSenderId: "351781323945", projectId: "regent-lab", storageBucket: "regent-lab.firebasestorage.app" };

// school-production-worker.mjs
var PROJECT = "regent-lab";
var ORIGIN = "https://aali-alt.github.io";
var cached;
function schoolPlatform(env) {
  const credential = JSON.parse(env.FIREBASE_SERVICE_ACCOUNT || "null");
  if (credential?.project_id !== PROJECT || !credential.client_email?.endsWith("@" + PROJECT + ".iam.gserviceaccount.com") || school_public_config_default.projectId !== PROJECT) throw Error("School target refused");
  return restPlatform({ projectId: PROJECT, apiKey: school_public_config_default.apiKey, serviceAccount: credential });
}
var school_production_worker_default = {
  async fetch(request, env) {
    const path = new URL(request.url).pathname;
    if (path === "/health") return new Response(JSON.stringify({ ready: !!env.FIREBASE_SERVICE_ACCOUNT, project: PROJECT }), { headers: { "Content-Type": "application/json", "Cache-Control": "no-store" } });
    if (path.startsWith("/assets/") || path.startsWith("/client/") || ["/tailwind.js", "/qrcode.js"].includes(path)) {
      const asset = await env.ASSETS.fetch(request), headers = new Headers(asset.headers);
      headers.set("Access-Control-Allow-Origin", ORIGIN);
      headers.set("X-Content-Type-Options", "nosniff");
      return new Response(asset.body, { status: asset.status, headers });
    }
    try {
      if (!cached) {
        const credential = JSON.parse(env.FIREBASE_SERVICE_ACCOUNT || "null");
        if (credential?.project_id !== PROJECT || !credential.client_email?.endsWith("@" + PROJECT + ".iam.gserviceaccount.com") || school_public_config_default.projectId !== PROJECT) throw Error("School target refused");
        const platform = restPlatform({ projectId: PROJECT, apiKey: school_public_config_default.apiKey, serviceAccount: credential });
        cached = createHandler({ repo: new FirestoreRepository(platform.db), auth: platform.auth, allowedOrigin: ORIGIN });
      }
      let status = 200, body = "";
      const headers = {};
      const response = { setHeader: (key, value) => {
        headers[key] = value;
      }, set statusCode(value) {
        status = value;
      }, get statusCode() {
        return status;
      }, end: (value) => {
        body = value || "";
      } };
      if (Number(request.headers.get("content-length") || 0) > (path === "/admin/restore" ? 4 * 1024 * 1024 : 512 * 1024)) return new Response(JSON.stringify({ error: { code: "TOO_LARGE" } }), { status: 413, headers: { "Content-Type": "application/json" } });
      const adapted = { method: request.method, url: request.url, headers: Object.fromEntries(request.headers), async *[Symbol.asyncIterator]() {
        if (!request.body) return;
        const reader = request.body.getReader();
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            yield value;
          }
        } finally {
          reader.releaseLock();
        }
      } };
      await cached(adapted, response);
      return new Response(status === 204 ? null : body, { status, headers });
    } catch {
      return new Response(JSON.stringify({ error: { code: "BACKEND_UNAVAILABLE", message: "The school service is not ready. Please try again shortly." } }), { status: 503, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" } });
    }
  },
  // Unattended scheduled backup: one server-side recovery snapshot per run, labeled
  // system-scheduler in the snapshot list. Same-database checkpoint, not an
  // independent offsite backup. Failures are audited in-app and rethrown.
  async scheduled(controller, env, ctx) {
    ctx.waitUntil((async () => {
      const repo = new FirestoreRepository(schoolPlatform(env).db);
      const result = await runScheduledSnapshot(repo, controller.scheduledTime);
      console.log("Scheduled snapshot created", result.snapshot.id);
    })());
  }
};
export {
  school_production_worker_default as default
};
